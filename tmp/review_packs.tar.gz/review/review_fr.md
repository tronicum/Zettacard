# Zettacard translation review — Français (`fr`)

Please check the **Français** against the German. You do not need German — judge whether the Français reads naturally
and whether the marked correct answer is genuinely the right one.

**What we most need to know:**

1. Does it read like a real person wrote it, or like a machine?
2. Is the ✅ answer actually correct, and are the other three clearly wrong?
3. German words are kept on purpose (`Zeichen 136`, `Vorfahrt`) because they appear on real road signs — is that helpful or confusing?
4. Anything that would confuse or mislead a learner.

---

## vorfahrt-01

**Deutsch:** An einer Kreuzung ohne Verkehrszeichen und ohne Ampel nähern sich zwei Fahrzeuge gleichzeitig. Wer hat Vorfahrt?

**Français:** À une intersection sans panneaux de signalisation ni feux, deux véhicules arrivent en même temps. Qui a la priorité ?

| | Deutsch | Français |
|---|---|---|
| **a** | Wer zuerst an der Kreuzung ankommt | Le véhicule le plus rapide |
| **b** ✅ | Das Fahrzeug von rechts | Le véhicule venant de la droite |
| **c** | Das Fahrzeug von links | Le véhicule le plus grand |
| **d** | Beide fahren gleichzeitig weiter, ohne sich abzustimmen | Celui qui klaxonne en premier |

**Erklärung (DE):** Ohne abweichende Beschilderung gilt die Grundregel 'rechts vor links'.

**Erklärung (Français):** En l'absence de signalisation différente, la règle de base « priorité à droite » s'applique.

**Reviewer notes:** 

---

## zeichen-04

**Deutsch:** Ein dreieckiges Warnschild mit spielenden Kindern (Zeichen 136) weist auf was hin?

**Français:** Un panneau de danger triangulaire représentant des enfants en train de jouer (Zeichen 136) signale quoi ?

| | Deutsch | Français |
|---|---|---|
| **a** | Eine Schule ohne besondere Vorsicht nötig | Une école où aucune prudence particulière n'est nécessaire |
| **b** ✅ | Dass Kinder plötzlich auf die Straße laufen können | La possible apparition soudaine d'enfants sur la chaussée |
| **c** | Ein Spielplatzverbot | Une interdiction d'aire de jeux |
| **d** | Ein Tempolimit von 30 km/h zwingend | Une limitation de vitesse obligatoire à 30 km/h |

**Erklärung (DE):** Das Schild warnt vor Kindern in der Nähe der Fahrbahn, z. B. bei Schulen oder Spielplätzen; erhöhte Vorsicht und Bremsbereitschaft sind geboten.

**Erklärung (Français):** Ce panneau avertit de la présence d'enfants à proximité de la chaussée, par exemple près d'écoles ou d'aires de jeux ; une prudence accrue et une disposition à freiner sont nécessaires.

**Reviewer notes:** 

---

## zeichen-118

**Deutsch:** Was bedeutet dieses gelbe Ortsschild mit dem Namen der Ortschaft?

**Français:** Que signifie ce panneau d'agglomération jaune portant le nom de la localité ?

| | Deutsch | Français |
|---|---|---|
| **a** ✅ | Ab hier beginnt eine geschlossene Ortschaft; innerorts gilt grundsätzlich Tempo 50. | À partir d'ici commence une agglomération ; en agglomération, la vitesse est en principe limitée à 50 km/h. |
| **b** | Ab hier endet die geschlossene Ortschaft. | L'agglomération se termine à partir d'ici. |
| **c** | Es zeigt zugleich das Ende einer Kraftfahrstraße an. | Il indique en même temps la fin d'une voie express |
| **d** | Ab hier gilt eine Geschwindigkeitsbegrenzung von 30 km/h. | Une limitation de vitesse de 30 km/h s'applique à partir d'ici. |

**Erklärung (DE):** Zeichen 310 (Ortstafel, Vorderseite) markiert den Beginn einer geschlossenen Ortschaft; ohne andere Beschilderung gilt ab hier Tempo 50.

**Erklärung (Français):** Le Zeichen 310 (panneau d'agglomération, face avant) marque le début d'une agglomération ; sauf signalisation contraire, la vitesse de 50 km/h s'applique à partir de ce point.

**Reviewer notes:** 

---

## zeichen-132

**Deutsch:** Unter einem Verkehrszeichen befindet sich ein weißes Zusatzzeichen mit der Aufschrift „Fußgänger“. Was bedeutet das?

**Français:** Un panonceau blanc portant la mention « Piétons » se trouve sous un panneau de signalisation. Que signifie-t-il ?

| | Deutsch | Français |
|---|---|---|
| **a** ✅ | Das Zusatzzeichen weist darauf hin, dass sich das Hauptzeichen (auch) auf Fußgänger bezieht. | Le panonceau indique que le panneau principal s'applique (aussi) aux piétons. |
| **b** | Fußgänger sind von jeder Regelung durch das Hauptzeichen grundsätzlich ausgenommen. | Les piétons sont par principe exemptés de toute règle imposée par le panneau principal. |
| **c** | Es handelt sich um einen Hinweis auf eine Fußgängerzone. | Il s'agit d'une indication signalant une zone piétonne. |
| **d** | Das Zusatzzeichen gilt nur für Rollstuhlfahrer, nicht für andere Fußgänger. | Le panonceau ne s'applique qu'aux utilisateurs de fauteuil roulant, et non aux autres piétons. |

**Erklärung (DE):** Das Zusatzzeichen 1010-53 „Fußgänger“ präzisiert den Geltungsbereich des darüber angebrachten Hauptzeichens: es macht deutlich, dass die Regelung auch Fußgänger einschließt, statt sich (wie ohne Zusatzzeichen oft angenommen) nur auf Fahrzeuge zu beziehen.

**Erklärung (Français):** Le panonceau 1010-53 « Piétons » précise le champ d'application du panneau principal placé au-dessus : il indique clairement que la règle concerne aussi les piétons, et non uniquement les véhicules, comme on pourrait le supposer en l'absence de ce panonceau.

**Reviewer notes:** 

---

## gefahr-06

**Deutsch:** Was bedeutet die Faustregel 'halber Tacho' für den Sicherheitsabstand auf der Autobahn?

**Français:** Que signifie la règle empirique du « compteur divisé par deux » pour la distance de sécurité sur l'autoroute ?

| | Deutsch | Français |
|---|---|---|
| **a** ✅ | Der Abstand in Metern soll mindestens der halben Geschwindigkeit in km/h entsprechen | La distance en mètres doit correspondre au moins à la moitié de la vitesse en km/h |
| **b** | Man soll nur halb so schnell fahren wie erlaubt | Il faut rouler seulement à moitié de la vitesse autorisée |
| **c** | Der Abstand darf höchstens die halbe Fahrzeuglänge betragen | La distance ne doit pas dépasser la moitié de la longueur du véhicule |
| **d** | Man soll nach der Hälfte der Strecke eine Pause machen | Il faut faire une pause après la moitié du trajet |

**Erklärung (DE):** Bei 100 km/h wären das mindestens 50 Meter Abstand. Diese Faustregel ist einfach zu merken, ersetzt aber keine genauere Berechnung bei schlechten Bedingungen.

**Erklärung (Français):** À 100 km/h, cela correspondrait à au moins 50 mètres de distance. Cette règle empirique est facile à retenir, mais ne remplace pas un calcul plus précis en cas de mauvaises conditions.

**Reviewer notes:** 

---

## verhalten-09

**Deutsch:** Wer im Auto muss laut Gesetz während der Fahrt angeschnallt sein?

**Français:** Qui, dans une voiture, doit selon la loi être attaché pendant la conduite ?

| | Deutsch | Français |
|---|---|---|
| **a** | Nur der Fahrer | Seul le conducteur |
| **b** | Nur die Personen auf den Vordersitzen | Seules les personnes aux places avant |
| **c** ✅ | Alle Insassen auf allen Sitzplätzen mit Sicherheitsgurt | Tous les occupants, à toutes les places équipées d'une ceinture de sécurité |
| **d** | Nur Kinder unter zwölf Jahren | Seuls les enfants de moins de douze ans |

**Erklärung (DE):** Die Anschnallpflicht gilt für alle Insassen auf allen Sitzplätzen, die mit einem Sicherheitsgurt ausgestattet sind, also auch für Personen auf der Rückbank.

**Erklärung (Français):** L'obligation du port de la ceinture s'applique à tous les occupants, à toutes les places équipées d'une ceinture de sécurité, donc aussi aux personnes sur la banquette arrière.

**Reviewer notes:** 

---

## parken-01

**Deutsch:** Was unterscheidet 'Halten' von 'Parken'?

**Français:** Quelle est la différence entre « s'arrêter » (Halten) et « stationner » (Parken) ?

| | Deutsch | Français |
|---|---|---|
| **a** | Halten ist grundsätzlich verboten, Parken ist immer erlaubt | S'arrêter est en principe interdit, stationner est toujours autorisé |
| **b** | Parken darf man nur mit eingeschaltetem Warnblinker | On ne peut stationner qu'avec les feux de détresse allumés |
| **c** ✅ | Parken liegt vor, wenn man länger als drei Minuten hält oder das Fahrzeug verlässt | Il y a stationnement lorsqu'on s'arrête plus de trois minutes ou que l'on quitte le véhicule |
| **d** | Halten ist nur nachts erlaubt | S'arrêter n'est autorisé que la nuit |

**Erklärung (DE):** Wer länger als drei Minuten hält oder das Fahrzeug verlässt, parkt im rechtlichen Sinn. Kürzeres Halten, zum Beispiel zum Ein- oder Aussteigen, zählt als Halten.

**Erklärung (Français):** Quiconque s'arrête plus de trois minutes ou quitte le véhicule stationne au sens juridique. Un arrêt plus court, par exemple pour monter ou descendre, compte comme un simple arrêt.

**Reviewer notes:** 

---

## autobahn-07

**Deutsch:** Auf welcher Seite darf auf der Autobahn normalerweise überholt werden?

**Français:** De quel côté est-il normalement autorisé de dépasser sur l'autoroute ?

| | Deutsch | Français |
|---|---|---|
| **a** | Auf der Seite mit dem geringeren Verkehr | Du côté où la circulation est la plus fluide |
| **b** ✅ | Nur auf der linken Seite | Seulement à gauche |
| **c** | Auf beiden Seiten, je nach freier Spur | Des deux côtés, selon la voie libre |
| **d** | Nur auf der rechten Seite | Seulement à droite |

**Erklärung (DE):** Überholt werden darf grundsätzlich nur links. Rechtsüberholen ist auf der Autobahn nur erlaubt, wenn der Verkehr auf allen Fahrstreifen sich staut und langsamer fließt.

**Erklärung (Français):** Le dépassement n'est en principe autorisé qu'à gauche. Le dépassement par la droite n'est autorisé sur l'autoroute que lorsque la circulation est ralentie sur toutes les voies et avance plus lentement.

**Reviewer notes:** 

---

## umwelt-08

**Deutsch:** Woran erkennt man einen echten Winterreifen im Gegensatz zu einem reinen Sommerreifen?

**Français:** Comment reconnaît-on un véritable pneu hiver par rapport à un simple pneu été ?

| | Deutsch | Français |
|---|---|---|
| **a** ✅ | Am Alpine-Symbol (Bergpiktogramm mit Schneeflocke) auf der Reifenflanke | Au symbole Alpine (pictogramme de montagne avec flocon de neige) sur le flanc du pneu |
| **b** | Am M+S-Kürzel allein, unabhängig vom Herstellungsdatum des Reifens | Au seul marquage M+S, indépendamment de la date de fabrication du pneu |
| **c** | An besonders breiten Reifen, breite Reifen sind automatisch Winterreifen | À des pneus particulièrement larges, les pneus larges sont automatiquement des pneus hiver |
| **d** | Daran, dass der Reifen als 'Ganzjahresreifen' verkauft wird | Au fait que le pneu est vendu comme « pneu toutes saisons » |

**Erklärung (DE):** Das Alpine-Symbol zeigt, dass ein Reifen die Anforderungen an Wintertauglichkeit erfüllt. Das ältere M+S-Kürzel allein reicht seit einer Übergangsfrist nicht mehr für alle neu hergestellten Reifen aus.

**Erklärung (Français):** Le symbole Alpine montre qu'un pneu répond aux exigences d'aptitude hivernale. L'ancien marquage M+S seul ne suffit plus, depuis la fin d'une période transitoire, pour tous les pneus nouvellement fabriqués.

**Reviewer notes:** 

---

## erstehilfe-04

**Deutsch:** Was sollten Sie unmittelbar tun, sobald Sie nach einem Unfall Ihr Fahrzeug zum Stehen gebracht haben?

**Français:** Que devriez-vous faire immédiatement dès que vous avez arrêté votre véhicule après un accident ?

| | Deutsch | Français |
|---|---|---|
| **a** ✅ | Warnblinkanlage einschalten | Allumer les feux de détresse |
| **b** | Motor unnötig lange laufen lassen | Laisser tourner le moteur inutilement longtemps |
| **c** | Die Musik lauter stellen | Monter le volume de la musique |
| **d** | Sofort losfahren, um Platz zu machen | Repartir immédiatement pour dégager la place |

**Erklärung (DE):** Der Warnblinker macht andere Verkehrsteilnehmer sofort auf die Gefahrenstelle aufmerksam.

**Erklärung (Français):** Les feux de détresse attirent immédiatement l'attention des autres usagers sur le lieu dangereux.

**Reviewer notes:** 

---

## fahrtuechtigkeit-39

**Deutsch:** Warum ist es riskant, sich bei der Einschätzung der eigenen Fahrtüchtigkeit auf Erfahrungswerte wie 'ich vertrage viel' zu verlassen?

**Français:** Pourquoi est-il risqué de se fier, pour évaluer sa propre aptitude à conduire, à une expérience personnelle du type « je tiens bien l'alcool » ?

| | Deutsch | Français |
|---|---|---|
| **a** ✅ | Eine hohe subjektive Alkoholtoleranz sagt nichts über die tatsächliche Beeinträchtigung von Reaktionsfähigkeit und Wahrnehmung aus | Une forte tolérance subjective à l'alcool ne dit rien sur l'altération réelle de la capacité de réaction et de la perception |
| **b** | Wer viel verträgt, hat rechtlich automatisch höhere Promillegrenzen | Quiconque tient bien l'alcool bénéficie automatiquement de limites légales plus élevées |
| **c** | Erfahrungswerte sind die einzige zuverlässige Methode zur Einschätzung | L'expérience personnelle est la seule méthode fiable d'évaluation |
| **d** | Alkoholtoleranz verhindert jede Art von Fahruntüchtigkeit vollständig | La tolérance à l'alcool empêche totalement toute forme d'inaptitude à conduire |

**Erklärung (DE):** Auch bei subjektiv hoher Alkoholtoleranz bleiben Reaktionsfähigkeit, Wahrnehmung und Urteilsvermögen objektiv beeinträchtigt - die gesetzlichen Grenzwerte gelten unabhängig davon.

**Erklärung (Français):** Même en cas de tolérance subjectivement élevée à l'alcool, la capacité de réaction, la perception et le jugement restent objectivement altérés - les limites légales s'appliquent indépendamment de cela.

**Reviewer notes:** 

---

## gefahr-40

**Deutsch:** Sie fahren mit einem voll beladenen Fahrzeug eine lange, steile Gefällstrecke hinunter. Warum sollten Sie rechtzeitig in einen niedrigeren Gang schalten, statt nur die Bremse zu nutzen?

**Français:** Vous descendez avec un véhicule entièrement chargé une longue pente raide. Pourquoi devriez-vous passer à temps à un rapport inférieur plutôt que de n'utiliser que le frein ?

| | Deutsch | Français |
|---|---|---|
| **a** | Weil ein niedriger Gang den Kraftstoffverbrauch senkt und das der einzige Zweck ist | Parce qu'un rapport bas réduit la consommation de carburant et que c'est le seul but |
| **b** ✅ | Weil dauerhaftes Bremsen bei hoher Last die Bremsen überhitzen und ihre Wirkung nachlassen kann | Parce qu'un freinage prolongé avec une charge élevée peut faire surchauffer les freins et réduire leur efficacité |
| **c** | Weil die Bremsen bei Gefällstrecken laut Vorschrift nicht benutzt werden dürfen | Parce que les freins ne doivent, selon le règlement, pas être utilisés dans les descentes |
| **d** | Weil ein niedriger Gang das Fahrzeug automatisch leichter macht | Parce qu'un rapport bas allège automatiquement le véhicule |

**Erklärung (DE):** Bei langem, hoch belastetem Bremsen kann sich das Bremssystem so stark erhitzen, dass die Bremswirkung nachlässt ('Bremsfading'). Ein niedriger Gang nutzt die Motorbremswirkung und entlastet die Betriebsbremse.

**Erklärung (Français):** Un freinage long et fortement sollicité peut échauffer le système de freinage au point de réduire son efficacité (« fading des freins »). Un rapport bas utilise le frein moteur et soulage le frein de service.

**Reviewer notes:** 

---
