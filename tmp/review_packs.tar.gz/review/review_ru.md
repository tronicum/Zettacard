# Zettacard translation review — Русский (`ru`)

Please check the **Русский** against the German. You do not need German — judge whether the Русский reads naturally
and whether the marked correct answer is genuinely the right one.

**What we most need to know:**

1. Does it read like a real person wrote it, or like a machine?
2. Is the ✅ answer actually correct, and are the other three clearly wrong?
3. German words are kept on purpose (`Zeichen 136`, `Vorfahrt`) because they appear on real road signs — is that helpful or confusing?
4. Anything that would confuse or mislead a learner.

---

## vorfahrt-01

**Deutsch:** An einer Kreuzung ohne Verkehrszeichen und ohne Ampel nähern sich zwei Fahrzeuge gleichzeitig. Wer hat Vorfahrt?

**Русский:** На перекрёстке без дорожных знаков и без светофора одновременно приближаются два транспортных средства. У кого есть преимущество (Vorfahrt)?

| | Deutsch | Русский |
|---|---|---|
| **a** | Wer zuerst an der Kreuzung ankommt | Более быстрое транспортное средство |
| **b** ✅ | Das Fahrzeug von rechts | Транспортное средство, движущееся справа |
| **c** | Das Fahrzeug von links | Более крупное транспортное средство |
| **d** | Beide fahren gleichzeitig weiter, ohne sich abzustimmen | Тот, кто первым посигналит |

**Erklärung (DE):** Ohne abweichende Beschilderung gilt die Grundregel 'rechts vor links'.

**Erklärung (Русский):** Без иных знаков действует основное правило «помеха справа».

**Reviewer notes:** 

---

## zeichen-04

**Deutsch:** Ein dreieckiges Warnschild mit spielenden Kindern (Zeichen 136) weist auf was hin?

**Русский:** На что указывает треугольный предупреждающий знак с играющими детьми (Zeichen 136)?

| | Deutsch | Русский |
|---|---|---|
| **a** | Eine Schule ohne besondere Vorsicht nötig | На школу, где особая осторожность не требуется |
| **b** ✅ | Dass Kinder plötzlich auf die Straße laufen können | На возможное внезапное появление детей на проезжей части |
| **c** | Ein Spielplatzverbot | На запрет игровой площадки |
| **d** | Ein Tempolimit von 30 km/h zwingend | На обязательное ограничение скорости 30 км/ч |

**Erklärung (DE):** Das Schild warnt vor Kindern in der Nähe der Fahrbahn, z. B. bei Schulen oder Spielplätzen; erhöhte Vorsicht und Bremsbereitschaft sind geboten.

**Erklärung (Русский):** Знак предупреждает о детях вблизи проезжей части, например у школ или детских площадок; требуется повышенная осторожность и готовность к торможению.

**Reviewer notes:** 

---

## zeichen-118

**Deutsch:** Was bedeutet dieses gelbe Ortsschild mit dem Namen der Ortschaft?

**Русский:** Что означает этот жёлтый указатель с названием населённого пункта?

| | Deutsch | Русский |
|---|---|---|
| **a** ✅ | Ab hier beginnt eine geschlossene Ortschaft; innerorts gilt grundsätzlich Tempo 50. | С этого места начинается населённый пункт; в населённом пункте, как правило, действует скорость 50 км/ч. |
| **b** | Ab hier endet die geschlossene Ortschaft. | С этого места населённый пункт заканчивается. |
| **c** | Es zeigt zugleich das Ende einer Kraftfahrstraße an. | Он одновременно означает конец автодороги |
| **d** | Ab hier gilt eine Geschwindigkeitsbegrenzung von 30 km/h. | С этого места действует ограничение скорости 30 км/ч. |

**Erklärung (DE):** Zeichen 310 (Ortstafel, Vorderseite) markiert den Beginn einer geschlossenen Ortschaft; ohne andere Beschilderung gilt ab hier Tempo 50.

**Erklärung (Русский):** Знак 310 (указатель населённого пункта, лицевая сторона) обозначает начало населённого пункта; без иного знака с этого места действует скорость 50 км/ч.

**Reviewer notes:** 

---

## zeichen-132

**Deutsch:** Unter einem Verkehrszeichen befindet sich ein weißes Zusatzzeichen mit der Aufschrift „Fußgänger“. Was bedeutet das?

**Русский:** Под дорожным знаком расположена белая дополнительная табличка с надписью «Fußgänger». Что это означает?

| | Deutsch | Русский |
|---|---|---|
| **a** ✅ | Das Zusatzzeichen weist darauf hin, dass sich das Hauptzeichen (auch) auf Fußgänger bezieht. | Дополнительная табличка указывает, что основной знак относится (в том числе) и к пешеходам |
| **b** | Fußgänger sind von jeder Regelung durch das Hauptzeichen grundsätzlich ausgenommen. | Пешеходы в принципе исключены из-под действия любого регулирования основным знаком |
| **c** | Es handelt sich um einen Hinweis auf eine Fußgängerzone. | Речь идёт об указании на пешеходную зону |
| **d** | Das Zusatzzeichen gilt nur für Rollstuhlfahrer, nicht für andere Fußgänger. | Дополнительная табличка действует только для колясочников, но не для остальных пешеходов |

**Erklärung (DE):** Das Zusatzzeichen 1010-53 „Fußgänger“ präzisiert den Geltungsbereich des darüber angebrachten Hauptzeichens: es macht deutlich, dass die Regelung auch Fußgänger einschließt, statt sich (wie ohne Zusatzzeichen oft angenommen) nur auf Fahrzeuge zu beziehen.

**Erklärung (Русский):** Дополнительная табличка 1010-53 «Fußgänger» уточняет зону действия расположенного над ней основного знака: она показывает, что предписание распространяется и на пешеходов, а не только на транспортные средства, как это часто предполагается без такой таблички.

**Reviewer notes:** 

---

## gefahr-06

**Deutsch:** Was bedeutet die Faustregel 'halber Tacho' für den Sicherheitsabstand auf der Autobahn?

**Русский:** Что означает эмпирическое правило «половина спидометра» для дистанции безопасности на автомагистрали?

| | Deutsch | Русский |
|---|---|---|
| **a** ✅ | Der Abstand in Metern soll mindestens der halben Geschwindigkeit in km/h entsprechen | Дистанция в метрах должна составлять как минимум половину скорости в км/ч |
| **b** | Man soll nur halb so schnell fahren wie erlaubt | Нужно ехать только с половиной разрешённой скорости |
| **c** | Der Abstand darf höchstens die halbe Fahrzeuglänge betragen | Дистанция не должна превышать половину длины автомобиля |
| **d** | Man soll nach der Hälfte der Strecke eine Pause machen | Через половину пути нужно сделать остановку |

**Erklärung (DE):** Bei 100 km/h wären das mindestens 50 Meter Abstand. Diese Faustregel ist einfach zu merken, ersetzt aber keine genauere Berechnung bei schlechten Bedingungen.

**Erklärung (Русский):** При 100 км/ч это означало бы минимум 50 метров дистанции. Это эмпирическое правило легко запомнить, но оно не заменяет более точный расчёт при плохих условиях.

**Reviewer notes:** 

---

## verhalten-09

**Deutsch:** Wer im Auto muss laut Gesetz während der Fahrt angeschnallt sein?

**Русский:** Кто в автомобиле по закону обязан пристёгиваться ремнём безопасности во время движения?

| | Deutsch | Русский |
|---|---|---|
| **a** | Nur der Fahrer | Только водитель |
| **b** | Nur die Personen auf den Vordersitzen | Только люди на передних сиденьях |
| **c** ✅ | Alle Insassen auf allen Sitzplätzen mit Sicherheitsgurt | Все пассажиры на всех местах, оборудованных ремнём безопасности |
| **d** | Nur Kinder unter zwölf Jahren | Только дети младше двенадцати лет |

**Erklärung (DE):** Die Anschnallpflicht gilt für alle Insassen auf allen Sitzplätzen, die mit einem Sicherheitsgurt ausgestattet sind, also auch für Personen auf der Rückbank.

**Erklärung (Русский):** Обязанность пристёгиваться ремнём распространяется на всех пассажиров на всех местах, оборудованных ремнём безопасности, в том числе на пассажиров заднего сиденья.

**Reviewer notes:** 

---

## parken-01

**Deutsch:** Was unterscheidet 'Halten' von 'Parken'?

**Русский:** В чём разница между «остановкой» (Halten) и «стоянкой» (Parken)?

| | Deutsch | Русский |
|---|---|---|
| **a** | Halten ist grundsätzlich verboten, Parken ist immer erlaubt | Остановка в принципе запрещена, стоянка всегда разрешена |
| **b** | Parken darf man nur mit eingeschaltetem Warnblinker | Стоять можно только с включённой аварийной сигнализацией |
| **c** ✅ | Parken liegt vor, wenn man länger als drei Minuten hält oder das Fahrzeug verlässt | О стоянке говорят, если водитель стоит дольше трёх минут или покидает транспортное средство |
| **d** | Halten ist nur nachts erlaubt | Остановка разрешена только ночью |

**Erklärung (DE):** Wer länger als drei Minuten hält oder das Fahrzeug verlässt, parkt im rechtlichen Sinn. Kürzeres Halten, zum Beispiel zum Ein- oder Aussteigen, zählt als Halten.

**Erklärung (Русский):** Кто стоит дольше трёх минут или покидает транспортное средство, с юридической точки зрения совершает стоянку. Более короткая остановка, например для посадки или высадки, считается остановкой.

**Reviewer notes:** 

---

## autobahn-07

**Deutsch:** Auf welcher Seite darf auf der Autobahn normalerweise überholt werden?

**Русский:** С какой стороны на автобане обычно разрешён обгон?

| | Deutsch | Русский |
|---|---|---|
| **a** | Auf der Seite mit dem geringeren Verkehr | С той стороны, где меньше движения |
| **b** ✅ | Nur auf der linken Seite | Только слева |
| **c** | Auf beiden Seiten, je nach freier Spur | С обеих сторон, в зависимости от свободной полосы |
| **d** | Nur auf der rechten Seite | Только справа |

**Erklärung (DE):** Überholt werden darf grundsätzlich nur links. Rechtsüberholen ist auf der Autobahn nur erlaubt, wenn der Verkehr auf allen Fahrstreifen sich staut und langsamer fließt.

**Erklärung (Русский):** Обгон в принципе разрешён только слева. Обгон справа на автобане допускается только тогда, когда движение на всех полосах затруднено и идёт медленнее.

**Reviewer notes:** 

---

## umwelt-08

**Deutsch:** Woran erkennt man einen echten Winterreifen im Gegensatz zu einem reinen Sommerreifen?

**Русский:** По какому признаку можно отличить настоящую зимнюю шину от чисто летней?

| | Deutsch | Русский |
|---|---|---|
| **a** ✅ | Am Alpine-Symbol (Bergpiktogramm mit Schneeflocke) auf der Reifenflanke | По альпийскому символу (пиктограмма горы со снежинкой) на боковине шины |
| **b** | Am M+S-Kürzel allein, unabhängig vom Herstellungsdatum des Reifens | Только по маркировке M+S, независимо от даты изготовления шины |
| **c** | An besonders breiten Reifen, breite Reifen sind automatisch Winterreifen | По особенно широким шинам, широкие шины автоматически являются зимними |
| **d** | Daran, dass der Reifen als 'Ganzjahresreifen' verkauft wird | По тому, что шина продаётся как «всесезонная» |

**Erklärung (DE):** Das Alpine-Symbol zeigt, dass ein Reifen die Anforderungen an Wintertauglichkeit erfüllt. Das ältere M+S-Kürzel allein reicht seit einer Übergangsfrist nicht mehr für alle neu hergestellten Reifen aus.

**Erklärung (Русский):** Альпийский символ показывает, что шина соответствует требованиям к зимней пригодности. Устаревшей маркировки M+S одной, после переходного периода, уже недостаточно для всех вновь изготовленных шин.

**Reviewer notes:** 

---

## erstehilfe-04

**Deutsch:** Was sollten Sie unmittelbar tun, sobald Sie nach einem Unfall Ihr Fahrzeug zum Stehen gebracht haben?

**Русский:** Что вам следует сделать немедленно, как только вы остановили своё транспортное средство после ДТП?

| | Deutsch | Русский |
|---|---|---|
| **a** ✅ | Warnblinkanlage einschalten | Включить аварийную сигнализацию |
| **b** | Motor unnötig lange laufen lassen | Оставить двигатель работающим без надобности дольше необходимого |
| **c** | Die Musik lauter stellen | Сделать музыку громче |
| **d** | Sofort losfahren, um Platz zu machen | Сразу же уехать, чтобы освободить место |

**Erklärung (DE):** Der Warnblinker macht andere Verkehrsteilnehmer sofort auf die Gefahrenstelle aufmerksam.

**Erklärung (Русский):** Аварийная сигнализация сразу же обращает внимание других участников движения на опасное место.

**Reviewer notes:** 

---

## fahrtuechtigkeit-39

**Deutsch:** Warum ist es riskant, sich bei der Einschätzung der eigenen Fahrtüchtigkeit auf Erfahrungswerte wie 'ich vertrage viel' zu verlassen?

**Русский:** Почему рискованно полагаться при оценке собственной пригодности к управлению транспортным средством на личный опыт вроде «я много переношу»?

| | Deutsch | Русский |
|---|---|---|
| **a** ✅ | Eine hohe subjektive Alkoholtoleranz sagt nichts über die tatsächliche Beeinträchtigung von Reaktionsfähigkeit und Wahrnehmung aus | Высокая субъективная переносимость алкоголя ничего не говорит о реальном нарушении способности реагировать и восприятия |
| **b** | Wer viel verträgt, hat rechtlich automatisch höhere Promillegrenzen | У тех, кто много переносит, юридически автоматически действуют более высокие предельные концентрации |
| **c** | Erfahrungswerte sind die einzige zuverlässige Methode zur Einschätzung | Личный опыт — единственный надёжный метод оценки |
| **d** | Alkoholtoleranz verhindert jede Art von Fahruntüchtigkeit vollständig | Переносимость алкоголя полностью предотвращает любую форму непригодности к управлению |

**Erklärung (DE):** Auch bei subjektiv hoher Alkoholtoleranz bleiben Reaktionsfähigkeit, Wahrnehmung und Urteilsvermögen objektiv beeinträchtigt - die gesetzlichen Grenzwerte gelten unabhängig davon.

**Erklärung (Русский):** Даже при субъективно высокой переносимости алкоголя способность реагировать, восприятие и суждение объективно остаются нарушенными — установленные законом предельные значения действуют независимо от этого.

**Reviewer notes:** 

---

## gefahr-40

**Deutsch:** Sie fahren mit einem voll beladenen Fahrzeug eine lange, steile Gefällstrecke hinunter. Warum sollten Sie rechtzeitig in einen niedrigeren Gang schalten, statt nur die Bremse zu nutzen?

**Русский:** Вы едете на полностью загруженном автомобиле по длинному крутому спуску. Почему вам следует заранее переключиться на пониженную передачу, а не полагаться только на тормоз?

| | Deutsch | Русский |
|---|---|---|
| **a** | Weil ein niedriger Gang den Kraftstoffverbrauch senkt und das der einzige Zweck ist | Потому что низкая передача снижает расход топлива, и это единственная цель |
| **b** ✅ | Weil dauerhaftes Bremsen bei hoher Last die Bremsen überhitzen und ihre Wirkung nachlassen kann | Потому что длительное торможение при большой нагрузке может перегреть тормоза и снизить их эффективность |
| **c** | Weil die Bremsen bei Gefällstrecken laut Vorschrift nicht benutzt werden dürfen | Потому что на спусках использовать тормоза запрещено по правилам |
| **d** | Weil ein niedriger Gang das Fahrzeug automatisch leichter macht | Потому что низкая передача автоматически делает автомобиль легче |

**Erklärung (DE):** Bei langem, hoch belastetem Bremsen kann sich das Bremssystem so stark erhitzen, dass die Bremswirkung nachlässt ('Bremsfading'). Ein niedriger Gang nutzt die Motorbremswirkung und entlastet die Betriebsbremse.

**Erklärung (Русский):** При длительном торможении под большой нагрузкой тормозная система может настолько сильно перегреться, что эффективность торможения снижается («затухание тормозов»). Низкая передача использует торможение двигателем и разгружает рабочий тормоз.

**Reviewer notes:** 

---
