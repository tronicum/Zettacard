# Zettacard translation review — Italiano (`it`)

Please check the **Italiano** against the German. You do not need German — judge whether the Italiano reads naturally
and whether the marked correct answer is genuinely the right one.

**What we most need to know:**

1. Does it read like a real person wrote it, or like a machine?
2. Is the ✅ answer actually correct, and are the other three clearly wrong?
3. German words are kept on purpose (`Zeichen 136`, `Vorfahrt`) because they appear on real road signs — is that helpful or confusing?
4. Anything that would confuse or mislead a learner.

---

## vorfahrt-01

**Deutsch:** An einer Kreuzung ohne Verkehrszeichen und ohne Ampel nähern sich zwei Fahrzeuge gleichzeitig. Wer hat Vorfahrt?

**Italiano:** A un incrocio senza segnali stradali e senza semaforo si avvicinano contemporaneamente due veicoli. Chi ha la precedenza?

| | Deutsch | Italiano |
|---|---|---|
| **a** | Wer zuerst an der Kreuzung ankommt | Il veicolo più veloce |
| **b** ✅ | Das Fahrzeug von rechts | Il veicolo che proviene da destra |
| **c** | Das Fahrzeug von links | Il veicolo più grande |
| **d** | Beide fahren gleichzeitig weiter, ohne sich abzustimmen | Chi clacsona per primo |

**Erklärung (DE):** Ohne abweichende Beschilderung gilt die Grundregel 'rechts vor links'.

**Erklärung (Italiano):** In assenza di segnaletica diversa vale la regola base 'destra precede sinistra'.

**Reviewer notes:** 

---

## zeichen-04

**Deutsch:** Ein dreieckiges Warnschild mit spielenden Kindern (Zeichen 136) weist auf was hin?

**Italiano:** A cosa si riferisce un cartello di pericolo triangolare con bambini che giocano (Zeichen 136)?

| | Deutsch | Italiano |
|---|---|---|
| **a** | Eine Schule ohne besondere Vorsicht nötig | Una scuola in cui non è necessaria particolare prudenza |
| **b** ✅ | Dass Kinder plötzlich auf die Straße laufen können | Possibile comparsa improvvisa di bambini sulla carreggiata |
| **c** | Ein Spielplatzverbot | Un divieto di area giochi |
| **d** | Ein Tempolimit von 30 km/h zwingend | Un limite di velocità obbligatorio di 30 km/h |

**Erklärung (DE):** Das Schild warnt vor Kindern in der Nähe der Fahrbahn, z. B. bei Schulen oder Spielplätzen; erhöhte Vorsicht und Bremsbereitschaft sind geboten.

**Erklärung (Italiano):** Il cartello avverte della presenza di bambini vicino alla carreggiata, ad esempio nei pressi di scuole o parchi giochi; sono richieste maggiore prudenza e prontezza nella frenata.

**Reviewer notes:** 

---

## zeichen-118

**Deutsch:** Was bedeutet dieses gelbe Ortsschild mit dem Namen der Ortschaft?

**Italiano:** Cosa significa questo cartello giallo di inizio centro abitato con il nome della località?

| | Deutsch | Italiano |
|---|---|---|
| **a** ✅ | Ab hier beginnt eine geschlossene Ortschaft; innerorts gilt grundsätzlich Tempo 50. | Da qui inizia un centro abitato; all'interno vige di norma il limite di 50 km/h. |
| **b** | Ab hier endet die geschlossene Ortschaft. | Da qui termina il centro abitato. |
| **c** | Es zeigt zugleich das Ende einer Kraftfahrstraße an. | Indica al contempo anche la fine di una strada riservata ai veicoli a motore. |
| **d** | Ab hier gilt eine Geschwindigkeitsbegrenzung von 30 km/h. | Da qui vale un limite di velocità di 30 km/h. |

**Erklärung (DE):** Zeichen 310 (Ortstafel, Vorderseite) markiert den Beginn einer geschlossenen Ortschaft; ohne andere Beschilderung gilt ab hier Tempo 50.

**Erklärung (Italiano):** Il segnale 310 (cartello di inizio centro abitato, lato anteriore) segna l'inizio di un centro abitato; in assenza di altra segnaletica, da qui in poi vale il limite di 50 km/h.

**Reviewer notes:** 

---

## zeichen-132

**Deutsch:** Unter einem Verkehrszeichen befindet sich ein weißes Zusatzzeichen mit der Aufschrift „Fußgänger“. Was bedeutet das?

**Italiano:** Sotto un segnale stradale si trova un pannello integrativo bianco con la scritta «Fußgänger» (pedoni). Cosa significa?

| | Deutsch | Italiano |
|---|---|---|
| **a** ✅ | Das Zusatzzeichen weist darauf hin, dass sich das Hauptzeichen (auch) auf Fußgänger bezieht. | Il pannello integrativo indica che il segnale principale si riferisce (anche) ai pedoni. |
| **b** | Fußgänger sind von jeder Regelung durch das Hauptzeichen grundsätzlich ausgenommen. | I pedoni sono in linea di principio esclusi da qualsiasi regolamentazione del segnale principale. |
| **c** | Es handelt sich um einen Hinweis auf eine Fußgängerzone. | Si tratta di un'indicazione di una zona pedonale. |
| **d** | Das Zusatzzeichen gilt nur für Rollstuhlfahrer, nicht für andere Fußgänger. | Il pannello integrativo vale solo per gli utenti di sedia a rotelle, non per gli altri pedoni. |

**Erklärung (DE):** Das Zusatzzeichen 1010-53 „Fußgänger“ präzisiert den Geltungsbereich des darüber angebrachten Hauptzeichens: es macht deutlich, dass die Regelung auch Fußgänger einschließt, statt sich (wie ohne Zusatzzeichen oft angenommen) nur auf Fahrzeuge zu beziehen.

**Erklärung (Italiano):** Il pannello integrativo 1010-53 «Fußgänger» precisa l'ambito di validità del segnale principale sovrastante: chiarisce che la regolamentazione include anche i pedoni, invece di riferirsi soltanto ai veicoli, come spesso si presume in assenza del pannello integrativo.

**Reviewer notes:** 

---

## gefahr-06

**Deutsch:** Was bedeutet die Faustregel 'halber Tacho' für den Sicherheitsabstand auf der Autobahn?

**Italiano:** Cosa significa la regola empirica 'metà del tachimetro' per la distanza di sicurezza in autostrada?

| | Deutsch | Italiano |
|---|---|---|
| **a** ✅ | Der Abstand in Metern soll mindestens der halben Geschwindigkeit in km/h entsprechen | La distanza in metri deve corrispondere almeno alla metà della velocità in km/h |
| **b** | Man soll nur halb so schnell fahren wie erlaubt | Bisogna guidare solo a metà della velocità consentita |
| **c** | Der Abstand darf höchstens die halbe Fahrzeuglänge betragen | La distanza può essere al massimo pari a metà della lunghezza del veicolo |
| **d** | Man soll nach der Hälfte der Strecke eine Pause machen | Bisogna fare una pausa dopo metà del percorso |

**Erklärung (DE):** Bei 100 km/h wären das mindestens 50 Meter Abstand. Diese Faustregel ist einfach zu merken, ersetzt aber keine genauere Berechnung bei schlechten Bedingungen.

**Erklärung (Italiano):** A 100 km/h sarebbero almeno 50 metri di distanza. Questa regola empirica è facile da ricordare, ma non sostituisce un calcolo più preciso in condizioni sfavorevoli.

**Reviewer notes:** 

---

## verhalten-09

**Deutsch:** Wer im Auto muss laut Gesetz während der Fahrt angeschnallt sein?

**Italiano:** Chi in auto deve, per legge, essere allacciato durante la guida?

| | Deutsch | Italiano |
|---|---|---|
| **a** | Nur der Fahrer | Solo il conducente |
| **b** | Nur die Personen auf den Vordersitzen | Solo le persone sui sedili anteriori |
| **c** ✅ | Alle Insassen auf allen Sitzplätzen mit Sicherheitsgurt | Tutti gli occupanti su tutti i posti dotati di cintura di sicurezza |
| **d** | Nur Kinder unter zwölf Jahren | Solo i bambini sotto i dodici anni |

**Erklärung (DE):** Die Anschnallpflicht gilt für alle Insassen auf allen Sitzplätzen, die mit einem Sicherheitsgurt ausgestattet sind, also auch für Personen auf der Rückbank.

**Erklärung (Italiano):** L'obbligo della cintura vale per tutti gli occupanti su tutti i posti dotati di cintura di sicurezza, quindi anche per le persone sul sedile posteriore.

**Reviewer notes:** 

---

## parken-01

**Deutsch:** Was unterscheidet 'Halten' von 'Parken'?

**Italiano:** Cosa distingue 'la sosta breve' (Halten) dal 'parcheggio' (Parken)?

| | Deutsch | Italiano |
|---|---|---|
| **a** | Halten ist grundsätzlich verboten, Parken ist immer erlaubt | La sosta breve è in linea di principio vietata, il parcheggio è sempre consentito |
| **b** | Parken darf man nur mit eingeschaltetem Warnblinker | Si può parcheggiare solo con le luci di emergenza accese |
| **c** ✅ | Parken liegt vor, wenn man länger als drei Minuten hält oder das Fahrzeug verlässt | Si parla di parcheggio quando ci si ferma per più di tre minuti o si abbandona il veicolo |
| **d** | Halten ist nur nachts erlaubt | La sosta breve è consentita solo di notte |

**Erklärung (DE):** Wer länger als drei Minuten hält oder das Fahrzeug verlässt, parkt im rechtlichen Sinn. Kürzeres Halten, zum Beispiel zum Ein- oder Aussteigen, zählt als Halten.

**Erklärung (Italiano):** Chi si ferma per più di tre minuti o abbandona il veicolo, sta parcheggiando in senso giuridico. Una sosta più breve, ad esempio per far salire o scendere qualcuno, conta come sosta breve.

**Reviewer notes:** 

---

## autobahn-07

**Deutsch:** Auf welcher Seite darf auf der Autobahn normalerweise überholt werden?

**Italiano:** Su quale lato è normalmente consentito sorpassare in autostrada?

| | Deutsch | Italiano |
|---|---|---|
| **a** | Auf der Seite mit dem geringeren Verkehr | Sul lato con meno traffico |
| **b** ✅ | Nur auf der linken Seite | Solo sul lato sinistro |
| **c** | Auf beiden Seiten, je nach freier Spur | Su entrambi i lati, a seconda della corsia libera |
| **d** | Nur auf der rechten Seite | Solo sul lato destro |

**Erklärung (DE):** Überholt werden darf grundsätzlich nur links. Rechtsüberholen ist auf der Autobahn nur erlaubt, wenn der Verkehr auf allen Fahrstreifen sich staut und langsamer fließt.

**Erklärung (Italiano):** Il sorpasso è consentito in linea di principio solo a sinistra. Il sorpasso a destra in autostrada è ammesso solo quando il traffico su tutte le corsie è incolonnato e procede più lentamente.

**Reviewer notes:** 

---

## umwelt-08

**Deutsch:** Woran erkennt man einen echten Winterreifen im Gegensatz zu einem reinen Sommerreifen?

**Italiano:** Da cosa si riconosce uno pneumatico invernale autentico rispetto a uno pneumatico puramente estivo?

| | Deutsch | Italiano |
|---|---|---|
| **a** ✅ | Am Alpine-Symbol (Bergpiktogramm mit Schneeflocke) auf der Reifenflanke | Dal simbolo alpino (montagna con fiocco di neve) sul fianco dello pneumatico |
| **b** | Am M+S-Kürzel allein, unabhängig vom Herstellungsdatum des Reifens | Dalla sola sigla M+S, indipendentemente dalla data di produzione dello pneumatico |
| **c** | An besonders breiten Reifen, breite Reifen sind automatisch Winterreifen | Da pneumatici particolarmente larghi, quelli larghi sono automaticamente invernali |
| **d** | Daran, dass der Reifen als 'Ganzjahresreifen' verkauft wird | Dal fatto che venga venduto come 'pneumatico quattro stagioni' |

**Erklärung (DE):** Das Alpine-Symbol zeigt, dass ein Reifen die Anforderungen an Wintertauglichkeit erfüllt. Das ältere M+S-Kürzel allein reicht seit einer Übergangsfrist nicht mehr für alle neu hergestellten Reifen aus.

**Erklärung (Italiano):** Il simbolo alpino mostra che uno pneumatico soddisfa i requisiti di idoneità invernale. La vecchia sigla M+S da sola non è più sufficiente, dopo un periodo transitorio, per tutti gli pneumatici di nuova produzione.

**Reviewer notes:** 

---

## erstehilfe-04

**Deutsch:** Was sollten Sie unmittelbar tun, sobald Sie nach einem Unfall Ihr Fahrzeug zum Stehen gebracht haben?

**Italiano:** Cosa dovreste fare immediatamente non appena avete fermato il vostro veicolo dopo un incidente?

| | Deutsch | Italiano |
|---|---|---|
| **a** ✅ | Warnblinkanlage einschalten | Accendere le luci di emergenza |
| **b** | Motor unnötig lange laufen lassen | Lasciare il motore acceso inutilmente a lungo |
| **c** | Die Musik lauter stellen | Alzare il volume della musica |
| **d** | Sofort losfahren, um Platz zu machen | Ripartire subito per fare spazio |

**Erklärung (DE):** Der Warnblinker macht andere Verkehrsteilnehmer sofort auf die Gefahrenstelle aufmerksam.

**Erklärung (Italiano):** Le luci di emergenza avvisano immediatamente gli altri utenti della strada del punto di pericolo.

**Reviewer notes:** 

---

## fahrtuechtigkeit-39

**Deutsch:** Warum ist es riskant, sich bei der Einschätzung der eigenen Fahrtüchtigkeit auf Erfahrungswerte wie 'ich vertrage viel' zu verlassen?

**Italiano:** Perché è rischioso affidarsi, nel valutare la propria idoneità alla guida, a valori empirici come 'reggo molto l'alcol'?

| | Deutsch | Italiano |
|---|---|---|
| **a** ✅ | Eine hohe subjektive Alkoholtoleranz sagt nichts über die tatsächliche Beeinträchtigung von Reaktionsfähigkeit und Wahrnehmung aus | Un'elevata tolleranza soggettiva all'alcol non dice nulla sulla reale compromissione della capacità di reazione e della percezione |
| **b** | Wer viel verträgt, hat rechtlich automatisch höhere Promillegrenzen | Chi regge molto ha automaticamente limiti alcolemici più alti dal punto di vista giuridico |
| **c** | Erfahrungswerte sind die einzige zuverlässige Methode zur Einschätzung | I valori empirici sono l'unico metodo affidabile di valutazione |
| **d** | Alkoholtoleranz verhindert jede Art von Fahruntüchtigkeit vollständig | La tolleranza all'alcol impedisce completamente qualsiasi forma di incapacità di guida |

**Erklärung (DE):** Auch bei subjektiv hoher Alkoholtoleranz bleiben Reaktionsfähigkeit, Wahrnehmung und Urteilsvermögen objektiv beeinträchtigt - die gesetzlichen Grenzwerte gelten unabhängig davon.

**Erklärung (Italiano):** Anche con un'elevata tolleranza soggettiva all'alcol, capacità di reazione, percezione e capacità di giudizio restano oggettivamente compromesse - i valori limite di legge valgono indipendentemente da ciò.

**Reviewer notes:** 

---

## gefahr-40

**Deutsch:** Sie fahren mit einem voll beladenen Fahrzeug eine lange, steile Gefällstrecke hinunter. Warum sollten Sie rechtzeitig in einen niedrigeren Gang schalten, statt nur die Bremse zu nutzen?

**Italiano:** State scendendo con un veicolo a pieno carico lungo un tratto ripido e lungo in discesa. Perché dovreste scalare per tempo a una marcia più bassa invece di usare solo il freno?

| | Deutsch | Italiano |
|---|---|---|
| **a** | Weil ein niedriger Gang den Kraftstoffverbrauch senkt und das der einzige Zweck ist | Perché una marcia bassa riduce il consumo di carburante ed è questo l'unico scopo |
| **b** ✅ | Weil dauerhaftes Bremsen bei hoher Last die Bremsen überhitzen und ihre Wirkung nachlassen kann | Perché una frenata prolungata sotto carico elevato può surriscaldare i freni e ridurne l'efficacia |
| **c** | Weil die Bremsen bei Gefällstrecken laut Vorschrift nicht benutzt werden dürfen | Perché secondo il regolamento i freni non possono essere usati sui tratti in discesa |
| **d** | Weil ein niedriger Gang das Fahrzeug automatisch leichter macht | Perché una marcia bassa rende automaticamente più leggero il veicolo |

**Erklärung (DE):** Bei langem, hoch belastetem Bremsen kann sich das Bremssystem so stark erhitzen, dass die Bremswirkung nachlässt ('Bremsfading'). Ein niedriger Gang nutzt die Motorbremswirkung und entlastet die Betriebsbremse.

**Erklärung (Italiano):** Con una frenata prolungata e molto sollecitata, l'impianto frenante può surriscaldarsi al punto da ridurre l'efficacia frenante ('fading dei freni'). Una marcia bassa sfrutta il freno motore e alleggerisce il freno di servizio.

**Reviewer notes:** 

---
