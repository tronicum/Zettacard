# Zettacard translation review — Română (`ro`)

Please check the **Română** against the German. You do not need German — judge whether the Română reads naturally
and whether the marked correct answer is genuinely the right one.

**What we most need to know:**

1. Does it read like a real person wrote it, or like a machine?
2. Is the ✅ answer actually correct, and are the other three clearly wrong?
3. German words are kept on purpose (`Zeichen 136`, `Vorfahrt`) because they appear on real road signs — is that helpful or confusing?
4. Anything that would confuse or mislead a learner.

---

## vorfahrt-01

**Deutsch:** An einer Kreuzung ohne Verkehrszeichen und ohne Ampel nähern sich zwei Fahrzeuge gleichzeitig. Wer hat Vorfahrt?

**Română:** La o intersecție fără indicatoare rutiere și fără semafor se apropie simultan două vehicule. Cine are prioritate (Vorfahrt)?

| | Deutsch | Română |
|---|---|---|
| **a** | Wer zuerst an der Kreuzung ankommt | Cel care ajunge primul la intersecție |
| **b** ✅ | Das Fahrzeug von rechts | Vehiculul din dreapta |
| **c** | Das Fahrzeug von links | Vehiculul din stânga |
| **d** | Beide fahren gleichzeitig weiter, ohne sich abzustimmen | Ambele continuă să circule simultan, fără să se înțeleagă între ele |

**Erklärung (DE):** Ohne abweichende Beschilderung gilt die Grundregel 'rechts vor links'.

**Erklärung (Română):** Dacă nu există o semnalizare care să prevadă altfel, se aplică regula de bază „dreapta înaintea stângii”.

**Reviewer notes:** 

---

## zeichen-04

**Deutsch:** Ein dreieckiges Warnschild mit spielenden Kindern (Zeichen 136) weist auf was hin?

**Română:** Un indicator triunghiular de avertizare cu copii care se joacă (Zeichen 136) atrage atenția asupra a ce anume?

| | Deutsch | Română |
|---|---|---|
| **a** | Eine Schule ohne besondere Vorsicht nötig | Asupra unei școli, fără a fi necesară o atenție deosebită |
| **b** ✅ | Dass Kinder plötzlich auf die Straße laufen können | Asupra faptului că pot apărea brusc copii pe carosabil |
| **c** | Ein Spielplatzverbot | Asupra unei interdicții de joacă |
| **d** | Ein Tempolimit von 30 km/h zwingend | Asupra unei limitări obligatorii de viteză la 30 km/h |

**Erklärung (DE):** Das Schild warnt vor Kindern in der Nähe der Fahrbahn, z. B. bei Schulen oder Spielplätzen; erhöhte Vorsicht und Bremsbereitschaft sind geboten.

**Erklärung (Română):** Indicatorul avertizează asupra prezenței copiilor în apropierea carosabilului, de exemplu lângă școli sau locuri de joacă; se impune o atenție sporită și pregătirea de a frâna.

**Reviewer notes:** 

---

## zeichen-118

**Deutsch:** Was bedeutet dieses gelbe Ortsschild mit dem Namen der Ortschaft?

**Română:** Ce înseamnă acest indicator galben (Ortstafel) cu numele localității?

| | Deutsch | Română |
|---|---|---|
| **a** ✅ | Ab hier beginnt eine geschlossene Ortschaft; innerorts gilt grundsätzlich Tempo 50. | De aici începe o localitate; în interiorul localității este valabilă, în principiu, viteza de 50 km/h. |
| **b** | Ab hier endet die geschlossene Ortschaft. | De aici se termină localitatea. |
| **c** | Es zeigt zugleich das Ende einer Kraftfahrstraße an. | Indică totodată sfârșitul unei Kraftfahrstraße. |
| **d** | Ab hier gilt eine Geschwindigkeitsbegrenzung von 30 km/h. | De aici este valabilă o limitare de viteză de 30 km/h. |

**Erklärung (DE):** Zeichen 310 (Ortstafel, Vorderseite) markiert den Beginn einer geschlossenen Ortschaft; ohne andere Beschilderung gilt ab hier Tempo 50.

**Erklärung (Română):** Zeichen 310 (Ortstafel, fața) marchează începutul unei localități; în absența altei semnalizări, de aici este valabilă viteza de 50 km/h.

**Reviewer notes:** 

---

## zeichen-132

**Deutsch:** Unter einem Verkehrszeichen befindet sich ein weißes Zusatzzeichen mit der Aufschrift „Fußgänger“. Was bedeutet das?

**Română:** Sub un semn de circulație se află un panou adițional alb cu inscripția „Fußgänger” (pietoni). Ce înseamnă acest lucru?

| | Deutsch | Română |
|---|---|---|
| **a** ✅ | Das Zusatzzeichen weist darauf hin, dass sich das Hauptzeichen (auch) auf Fußgänger bezieht. | Panoul adițional indică faptul că semnul principal se referă (și) la pietoni. |
| **b** | Fußgänger sind von jeder Regelung durch das Hauptzeichen grundsätzlich ausgenommen. | Pietonii sunt exceptați, în principiu, de la orice reglementare a semnului principal. |
| **c** | Es handelt sich um einen Hinweis auf eine Fußgängerzone. | Este vorba despre o indicație privind o zonă pietonală. |
| **d** | Das Zusatzzeichen gilt nur für Rollstuhlfahrer, nicht für andere Fußgänger. | Panoul adițional este valabil doar pentru persoanele în scaun cu rotile, nu și pentru ceilalți pietoni. |

**Erklärung (DE):** Das Zusatzzeichen 1010-53 „Fußgänger“ präzisiert den Geltungsbereich des darüber angebrachten Hauptzeichens: es macht deutlich, dass die Regelung auch Fußgänger einschließt, statt sich (wie ohne Zusatzzeichen oft angenommen) nur auf Fahrzeuge zu beziehen.

**Erklärung (Română):** Panoul adițional 1010-53 „Fußgänger” precizează domeniul de aplicare al semnului principal montat deasupra: acesta arată clar că reglementarea îi include și pe pietoni, în loc să se refere doar la vehicule (așa cum se presupune adesea în absența panoului adițional).

**Reviewer notes:** 

---

## gefahr-06

**Deutsch:** Was bedeutet die Faustregel 'halber Tacho' für den Sicherheitsabstand auf der Autobahn?

**Română:** Ce înseamnă regula de bază „jumătate din viteza afișată” (halber Tacho) pentru distanța de siguranță pe Autobahn?

| | Deutsch | Română |
|---|---|---|
| **a** ✅ | Der Abstand in Metern soll mindestens der halben Geschwindigkeit in km/h entsprechen | Distanța în metri trebuie să corespundă cel puțin jumătății din viteza în km/h |
| **b** | Man soll nur halb so schnell fahren wie erlaubt | Trebuie să circulați doar cu jumătate din viteza permisă |
| **c** | Der Abstand darf höchstens die halbe Fahrzeuglänge betragen | Distanța poate fi de cel mult jumătate din lungimea vehiculului |
| **d** | Man soll nach der Hälfte der Strecke eine Pause machen | Trebuie făcută o pauză după jumătate din traseu |

**Erklärung (DE):** Bei 100 km/h wären das mindestens 50 Meter Abstand. Diese Faustregel ist einfach zu merken, ersetzt aber keine genauere Berechnung bei schlechten Bedingungen.

**Erklärung (Română):** La 100 km/h, aceasta ar însemna cel puțin 50 de metri distanță. Această regulă de bază este ușor de reținut, dar nu înlocuiește un calcul mai exact în condiții nefavorabile.

**Reviewer notes:** 

---

## verhalten-09

**Deutsch:** Wer im Auto muss laut Gesetz während der Fahrt angeschnallt sein?

**Română:** Cine din mașină trebuie, conform legii, să fie cu centura pusă în timpul deplasării?

| | Deutsch | Română |
|---|---|---|
| **a** | Nur der Fahrer | Doar șoferul |
| **b** | Nur die Personen auf den Vordersitzen | Doar persoanele de pe locurile din față |
| **c** ✅ | Alle Insassen auf allen Sitzplätzen mit Sicherheitsgurt | Toți ocupanții de pe toate locurile prevăzute cu centură de siguranță |
| **d** | Nur Kinder unter zwölf Jahren | Doar copiii sub doisprezece ani |

**Erklärung (DE):** Die Anschnallpflicht gilt für alle Insassen auf allen Sitzplätzen, die mit einem Sicherheitsgurt ausgestattet sind, also auch für Personen auf der Rückbank.

**Erklärung (Română):** Obligația de a purta centura se aplică tuturor ocupanților de pe toate locurile echipate cu centură de siguranță, deci și persoanelor de pe bancheta din spate.

**Reviewer notes:** 

---

## parken-01

**Deutsch:** Was unterscheidet 'Halten' von 'Parken'?

**Română:** Ce deosebește „Halten” (oprire) de „Parken” (parcare)?

| | Deutsch | Română |
|---|---|---|
| **a** | Halten ist grundsätzlich verboten, Parken ist immer erlaubt | Halten este interzis, în principiu, Parken este întotdeauna permis |
| **b** | Parken darf man nur mit eingeschaltetem Warnblinker | Parken este permis doar cu semnalizarea de avarie pornită |
| **c** ✅ | Parken liegt vor, wenn man länger als drei Minuten hält oder das Fahrzeug verlässt | Parken are loc atunci când staționați mai mult de trei minute sau părăsiți vehiculul |
| **d** | Halten ist nur nachts erlaubt | Halten este permis doar noaptea |

**Erklärung (DE):** Wer länger als drei Minuten hält oder das Fahrzeug verlässt, parkt im rechtlichen Sinn. Kürzeres Halten, zum Beispiel zum Ein- oder Aussteigen, zählt als Halten.

**Erklärung (Română):** Cine staționează mai mult de trei minute sau părăsește vehiculul parchează în sensul juridic al termenului. O oprire mai scurtă, de exemplu pentru urcare sau coborâre, este considerată Halten.

**Reviewer notes:** 

---

## autobahn-07

**Deutsch:** Auf welcher Seite darf auf der Autobahn normalerweise überholt werden?

**Română:** Pe ce parte se poate depăși, în mod normal, pe Autobahn?

| | Deutsch | Română |
|---|---|---|
| **a** | Auf der Seite mit dem geringeren Verkehr | Pe partea cu trafic mai redus |
| **b** ✅ | Nur auf der linken Seite | Doar pe partea stângă |
| **c** | Auf beiden Seiten, je nach freier Spur | Pe ambele părți, în funcție de banda liberă |
| **d** | Nur auf der rechten Seite | Doar pe partea dreaptă |

**Erklärung (DE):** Überholt werden darf grundsätzlich nur links. Rechtsüberholen ist auf der Autobahn nur erlaubt, wenn der Verkehr auf allen Fahrstreifen sich staut und langsamer fließt.

**Erklärung (Română):** Depășirea este permisă, în principiu, doar pe stânga. Depășirea pe dreapta este permisă pe Autobahn numai atunci când traficul de pe toate benzile este blocat și circulă mai lent.

**Reviewer notes:** 

---

## umwelt-08

**Deutsch:** Woran erkennt man einen echten Winterreifen im Gegensatz zu einem reinen Sommerreifen?

**Română:** După ce recunoașteți o anvelopă de iarnă adevărată, spre deosebire de o anvelopă pur de vară?

| | Deutsch | Română |
|---|---|---|
| **a** ✅ | Am Alpine-Symbol (Bergpiktogramm mit Schneeflocke) auf der Reifenflanke | După simbolul Alpine (Alpine-Symbol, pictograma cu munte și fulg de zăpadă) de pe flancul anvelopei |
| **b** | Am M+S-Kürzel allein, unabhängig vom Herstellungsdatum des Reifens | Doar după marcajul M+S, indiferent de data fabricării anvelopei |
| **c** | An besonders breiten Reifen, breite Reifen sind automatisch Winterreifen | După anvelope deosebit de late, anvelopele late fiind automat anvelope de iarnă |
| **d** | Daran, dass der Reifen als 'Ganzjahresreifen' verkauft wird | După faptul că anvelopa este vândută drept „anvelopă all-season” |

**Erklärung (DE):** Das Alpine-Symbol zeigt, dass ein Reifen die Anforderungen an Wintertauglichkeit erfüllt. Das ältere M+S-Kürzel allein reicht seit einer Übergangsfrist nicht mehr für alle neu hergestellten Reifen aus.

**Erklärung (Română):** Simbolul Alpine arată că o anvelopă îndeplinește cerințele de adecvare pentru iarnă. Marcajul mai vechi M+S, singur, nu mai este suficient, după o perioadă de tranziție, pentru toate anvelopele nou fabricate.

**Reviewer notes:** 

---

## erstehilfe-04

**Deutsch:** Was sollten Sie unmittelbar tun, sobald Sie nach einem Unfall Ihr Fahrzeug zum Stehen gebracht haben?

**Română:** Ce ar trebui să faceți imediat, de îndată ce ați oprit vehiculul după un accident?

| | Deutsch | Română |
|---|---|---|
| **a** ✅ | Warnblinkanlage einschalten | Porniți semnalizarea de avarie (Warnblinkanlage) |
| **b** | Motor unnötig lange laufen lassen | Lăsați motorul să meargă inutil de mult timp |
| **c** | Die Musik lauter stellen | Dați muzica mai tare |
| **d** | Sofort losfahren, um Platz zu machen | Plecați imediat, pentru a face loc |

**Erklärung (DE):** Der Warnblinker macht andere Verkehrsteilnehmer sofort auf die Gefahrenstelle aufmerksam.

**Erklärung (Română):** Semnalizarea de avarie atrage imediat atenția celorlalți participanți la trafic asupra locului periculos.

**Reviewer notes:** 

---

## fahrtuechtigkeit-39

**Deutsch:** Warum ist es riskant, sich bei der Einschätzung der eigenen Fahrtüchtigkeit auf Erfahrungswerte wie 'ich vertrage viel' zu verlassen?

**Română:** De ce este riscant să vă bazați, în aprecierea propriei capacități de a conduce, pe experiențe de tipul „eu suport mult”?

| | Deutsch | Română |
|---|---|---|
| **a** ✅ | Eine hohe subjektive Alkoholtoleranz sagt nichts über die tatsächliche Beeinträchtigung von Reaktionsfähigkeit und Wahrnehmung aus | O toleranță subiectivă ridicată la alcool nu spune nimic despre afectarea reală a capacității de reacție și a percepției |
| **b** | Wer viel verträgt, hat rechtlich automatisch höhere Promillegrenzen | Cine suportă mult are automat, din punct de vedere juridic, limite de alcoolemie mai ridicate |
| **c** | Erfahrungswerte sind die einzige zuverlässige Methode zur Einschätzung | Experiențele personale sunt singura metodă fiabilă de apreciere |
| **d** | Alkoholtoleranz verhindert jede Art von Fahruntüchtigkeit vollständig | Toleranța la alcool previne complet orice formă de incapacitate de a conduce |

**Erklärung (DE):** Auch bei subjektiv hoher Alkoholtoleranz bleiben Reaktionsfähigkeit, Wahrnehmung und Urteilsvermögen objektiv beeinträchtigt - die gesetzlichen Grenzwerte gelten unabhängig davon.

**Erklärung (Română):** Chiar și în cazul unei toleranțe subiectiv ridicate la alcool, capacitatea de reacție, percepția și capacitatea de judecată rămân afectate în mod obiectiv - limitele legale se aplică indiferent de aceasta.

**Reviewer notes:** 

---

## gefahr-40

**Deutsch:** Sie fahren mit einem voll beladenen Fahrzeug eine lange, steile Gefällstrecke hinunter. Warum sollten Sie rechtzeitig in einen niedrigeren Gang schalten, statt nur die Bremse zu nutzen?

**Română:** Coborâți cu un vehicul complet încărcat o pantă lungă și abruptă. De ce ar trebui să treceți din timp într-o treaptă de viteză mai mică, în loc să folosiți doar frâna?

| | Deutsch | Română |
|---|---|---|
| **a** | Weil ein niedriger Gang den Kraftstoffverbrauch senkt und das der einzige Zweck ist | Deoarece o treaptă mai mică reduce consumul de combustibil și acesta este singurul scop |
| **b** ✅ | Weil dauerhaftes Bremsen bei hoher Last die Bremsen überhitzen und ihre Wirkung nachlassen kann | Deoarece frânarea continuă la sarcină mare poate supraîncălzi frânele și le poate reduce eficacitatea |
| **c** | Weil die Bremsen bei Gefällstrecken laut Vorschrift nicht benutzt werden dürfen | Deoarece frânele nu au voie, conform reglementărilor, să fie folosite pe pante |
| **d** | Weil ein niedriger Gang das Fahrzeug automatisch leichter macht | Deoarece o treaptă mai mică ușurează automat vehiculul |

**Erklärung (DE):** Bei langem, hoch belastetem Bremsen kann sich das Bremssystem so stark erhitzen, dass die Bremswirkung nachlässt ('Bremsfading'). Ein niedriger Gang nutzt die Motorbremswirkung und entlastet die Betriebsbremse.

**Erklärung (Română):** La o frânare îndelungată, puternic solicitată, sistemul de frânare se poate încălzi atât de puternic încât efectul de frânare scade (Bremsfading). O treaptă de viteză mai mică folosește efectul de frânare al motorului și degrevează frâna de serviciu.

**Reviewer notes:** 

---
