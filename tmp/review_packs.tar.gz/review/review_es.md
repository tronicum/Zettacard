# Zettacard translation review — Español (`es`)

Please check the **Español** against the German. You do not need German — judge whether the Español reads naturally
and whether the marked correct answer is genuinely the right one.

**What we most need to know:**

1. Does it read like a real person wrote it, or like a machine?
2. Is the ✅ answer actually correct, and are the other three clearly wrong?
3. German words are kept on purpose (`Zeichen 136`, `Vorfahrt`) because they appear on real road signs — is that helpful or confusing?
4. Anything that would confuse or mislead a learner.

---

## vorfahrt-01

**Deutsch:** An einer Kreuzung ohne Verkehrszeichen und ohne Ampel nähern sich zwei Fahrzeuge gleichzeitig. Wer hat Vorfahrt?

**Español:** En un cruce sin señales de tráfico y sin semáforo se acercan dos vehículos al mismo tiempo. ¿Quién tiene prioridad de paso?

| | Deutsch | Español |
|---|---|---|
| **a** | Wer zuerst an der Kreuzung ankommt | El vehículo más rápido |
| **b** ✅ | Das Fahrzeug von rechts | El vehículo que viene por la derecha |
| **c** | Das Fahrzeug von links | El vehículo más grande |
| **d** | Beide fahren gleichzeitig weiter, ohne sich abzustimmen | Quien toque la bocina primero |

**Erklärung (DE):** Ohne abweichende Beschilderung gilt die Grundregel 'rechts vor links'.

**Erklärung (Español):** Sin señalización que indique lo contrario, se aplica la regla básica de 'derecha antes que izquierda'.

**Reviewer notes:** 

---

## zeichen-04

**Deutsch:** Ein dreieckiges Warnschild mit spielenden Kindern (Zeichen 136) weist auf was hin?

**Español:** Una señal triangular de advertencia con niños jugando (señal 136) indica:

| | Deutsch | Español |
|---|---|---|
| **a** | Eine Schule ohne besondere Vorsicht nötig | Una escuela sin necesidad de especial precaución |
| **b** ✅ | Dass Kinder plötzlich auf die Straße laufen können | Posible aparición repentina de niños en la calzada |
| **c** | Ein Spielplatzverbot | Prohibición de zona de juegos |
| **d** | Ein Tempolimit von 30 km/h zwingend | Un límite obligatorio de 30 km/h |

**Erklärung (DE):** Das Schild warnt vor Kindern in der Nähe der Fahrbahn, z. B. bei Schulen oder Spielplätzen; erhöhte Vorsicht und Bremsbereitschaft sind geboten.

**Erklärung (Español):** La señal advierte de la presencia de niños cerca de la calzada, por ejemplo cerca de escuelas o parques infantiles; se requiere mayor precaución y disposición a frenar.

**Reviewer notes:** 

---

## zeichen-118

**Deutsch:** Was bedeutet dieses gelbe Ortsschild mit dem Namen der Ortschaft?

**Español:** ¿Qué significa este cartel amarillo de entrada con el nombre de la localidad?

| | Deutsch | Español |
|---|---|---|
| **a** ✅ | Ab hier beginnt eine geschlossene Ortschaft; innerorts gilt grundsätzlich Tempo 50. | A partir de aquí comienza un núcleo urbano; dentro de poblado rige por lo general 50 km/h. |
| **b** | Ab hier endet die geschlossene Ortschaft. | A partir de aquí termina el núcleo urbano. |
| **c** | Es zeigt zugleich das Ende einer Kraftfahrstraße an. | Se trata de una simple indicación de dirección sin valor legal. |
| **d** | Ab hier gilt eine Geschwindigkeitsbegrenzung von 30 km/h. | A partir de aquí rige un límite de velocidad de 30 km/h. |

**Erklärung (DE):** Zeichen 310 (Ortstafel, Vorderseite) markiert den Beginn einer geschlossenen Ortschaft; ohne andere Beschilderung gilt ab hier Tempo 50.

**Erklärung (Español):** La señal 310 (cartel de entrada a la ciudad, cara delantera) marca el comienzo de un núcleo urbano; sin otra señalización, a partir de aquí rige 50 km/h.

**Reviewer notes:** 

---

## zeichen-132

**Deutsch:** Unter einem Verkehrszeichen befindet sich ein weißes Zusatzzeichen mit der Aufschrift „Fußgänger“. Was bedeutet das?

**Español:** Bajo una señal de tráfico hay un panel adicional blanco con la inscripción «Fußgänger» (peatones). ¿Qué significa esto?

| | Deutsch | Español |
|---|---|---|
| **a** ✅ | Das Zusatzzeichen weist darauf hin, dass sich das Hauptzeichen (auch) auf Fußgänger bezieht. | El panel adicional indica que la señal principal se aplica también a los peatones. |
| **b** | Fußgänger sind von jeder Regelung durch das Hauptzeichen grundsätzlich ausgenommen. | Los peatones quedan en principio exentos de cualquier regulación de la señal principal. |
| **c** | Es handelt sich um einen Hinweis auf eine Fußgängerzone. | Se trata de una indicación de una zona peatonal. |
| **d** | Das Zusatzzeichen gilt nur für Rollstuhlfahrer, nicht für andere Fußgänger. | El panel adicional solo es válido para usuarios de silla de ruedas, no para el resto de peatones. |

**Erklärung (DE):** Das Zusatzzeichen 1010-53 „Fußgänger“ präzisiert den Geltungsbereich des darüber angebrachten Hauptzeichens: es macht deutlich, dass die Regelung auch Fußgänger einschließt, statt sich (wie ohne Zusatzzeichen oft angenommen) nur auf Fahrzeuge zu beziehen.

**Erklärung (Español):** El panel adicional 1010-53 «Fußgänger» precisa el ámbito de aplicación de la señal principal situada encima: aclara que la regulación también incluye a los peatones, en lugar de referirse únicamente a los vehículos, como suele suponerse cuando no hay panel adicional.

**Reviewer notes:** 

---

## gefahr-06

**Deutsch:** Was bedeutet die Faustregel 'halber Tacho' für den Sicherheitsabstand auf der Autobahn?

**Español:** ¿Qué significa la regla práctica de 'la mitad del velocímetro' para la distancia de seguridad en la autopista?

| | Deutsch | Español |
|---|---|---|
| **a** ✅ | Der Abstand in Metern soll mindestens der halben Geschwindigkeit in km/h entsprechen | La distancia en metros debe corresponder al menos a la mitad de la velocidad en km/h |
| **b** | Man soll nur halb so schnell fahren wie erlaubt | Se debe circular solo a la mitad de la velocidad permitida |
| **c** | Der Abstand darf höchstens die halbe Fahrzeuglänge betragen | La distancia puede ser como máximo la mitad de la longitud del vehículo |
| **d** | Man soll nach der Hälfte der Strecke eine Pause machen | Hay que hacer una pausa tras la mitad del trayecto |

**Erklärung (DE):** Bei 100 km/h wären das mindestens 50 Meter Abstand. Diese Faustregel ist einfach zu merken, ersetzt aber keine genauere Berechnung bei schlechten Bedingungen.

**Erklärung (Español):** A 100 km/h serían al menos 50 metros de distancia. Esta regla es fácil de recordar, pero no sustituye un cálculo más exacto en malas condiciones.

**Reviewer notes:** 

---

## verhalten-09

**Deutsch:** Wer im Auto muss laut Gesetz während der Fahrt angeschnallt sein?

**Español:** Según la ley, ¿quién en el coche debe llevar puesto el cinturón de seguridad durante la marcha?

| | Deutsch | Español |
|---|---|---|
| **a** | Nur der Fahrer | Solo el conductor |
| **b** | Nur die Personen auf den Vordersitzen | Solo las personas en los asientos delanteros |
| **c** ✅ | Alle Insassen auf allen Sitzplätzen mit Sicherheitsgurt | Todos los ocupantes en todos los asientos equipados con cinturón de seguridad |
| **d** | Nur Kinder unter zwölf Jahren | Solo los niños menores de doce años |

**Erklärung (DE):** Die Anschnallpflicht gilt für alle Insassen auf allen Sitzplätzen, die mit einem Sicherheitsgurt ausgestattet sind, also auch für Personen auf der Rückbank.

**Erklärung (Español):** La obligación de llevar el cinturón se aplica a todos los ocupantes en todos los asientos equipados con cinturón de seguridad, también a las personas en el asiento trasero.

**Reviewer notes:** 

---

## parken-01

**Deutsch:** Was unterscheidet 'Halten' von 'Parken'?

**Español:** ¿Qué diferencia hay entre 'detenerse' y 'aparcar'?

| | Deutsch | Español |
|---|---|---|
| **a** | Halten ist grundsätzlich verboten, Parken ist immer erlaubt | Detenerse está en general prohibido, aparcar siempre está permitido |
| **b** | Parken darf man nur mit eingeschaltetem Warnblinker | Solo se puede aparcar con las luces de emergencia encendidas |
| **c** ✅ | Parken liegt vor, wenn man länger als drei Minuten hält oder das Fahrzeug verlässt | Se considera aparcar cuando se permanece parado más de tres minutos o se abandona el vehículo |
| **d** | Halten ist nur nachts erlaubt | Detenerse solo está permitido de noche |

**Erklärung (DE):** Wer länger als drei Minuten hält oder das Fahrzeug verlässt, parkt im rechtlichen Sinn. Kürzeres Halten, zum Beispiel zum Ein- oder Aussteigen, zählt als Halten.

**Erklärung (Español):** Quien permanece parado más de tres minutos o abandona el vehículo está aparcando en sentido legal. Una parada más breve, por ejemplo para subir o bajar a alguien, cuenta como detención.

**Reviewer notes:** 

---

## autobahn-07

**Deutsch:** Auf welcher Seite darf auf der Autobahn normalerweise überholt werden?

**Español:** ¿Por qué lado se puede adelantar normalmente en la autopista?

| | Deutsch | Español |
|---|---|---|
| **a** | Auf der Seite mit dem geringeren Verkehr | Por el lado con menos tráfico |
| **b** ✅ | Nur auf der linken Seite | Solo por la izquierda |
| **c** | Auf beiden Seiten, je nach freier Spur | Por ambos lados, según el carril libre |
| **d** | Nur auf der rechten Seite | Solo por la derecha |

**Erklärung (DE):** Überholt werden darf grundsätzlich nur links. Rechtsüberholen ist auf der Autobahn nur erlaubt, wenn der Verkehr auf allen Fahrstreifen sich staut und langsamer fließt.

**Erklärung (Español):** Por norma general, solo se puede adelantar por la izquierda. Adelantar por la derecha en la autopista solo está permitido cuando el tráfico está congestionado en todos los carriles y circula más lento.

**Reviewer notes:** 

---

## umwelt-08

**Deutsch:** Woran erkennt man einen echten Winterreifen im Gegensatz zu einem reinen Sommerreifen?

**Español:** ¿Cómo se reconoce un auténtico neumático de invierno frente a uno puramente de verano?

| | Deutsch | Español |
|---|---|---|
| **a** ✅ | Am Alpine-Symbol (Bergpiktogramm mit Schneeflocke) auf der Reifenflanke | Por el símbolo alpino (pictograma de montaña con copo de nieve) en el flanco del neumático |
| **b** | Am M+S-Kürzel allein, unabhängig vom Herstellungsdatum des Reifens | Solo por las siglas M+S, independientemente de la fecha de fabricación del neumático |
| **c** | An besonders breiten Reifen, breite Reifen sind automatisch Winterreifen | Por neumáticos especialmente anchos; los neumáticos anchos son automáticamente de invierno |
| **d** | Daran, dass der Reifen als 'Ganzjahresreifen' verkauft wird | Por el hecho de que se venda como 'neumático de todo el año' |

**Erklärung (DE):** Das Alpine-Symbol zeigt, dass ein Reifen die Anforderungen an Wintertauglichkeit erfüllt. Das ältere M+S-Kürzel allein reicht seit einer Übergangsfrist nicht mehr für alle neu hergestellten Reifen aus.

**Erklärung (Español):** El símbolo alpino muestra que un neumático cumple los requisitos de aptitud para invierno. Las antiguas siglas M+S por sí solas ya no bastan, desde un período transitorio, para todos los neumáticos de nueva fabricación.

**Reviewer notes:** 

---

## erstehilfe-04

**Deutsch:** Was sollten Sie unmittelbar tun, sobald Sie nach einem Unfall Ihr Fahrzeug zum Stehen gebracht haben?

**Español:** ¿Qué debería hacer de inmediato en cuanto haya detenido su vehículo tras un accidente?

| | Deutsch | Español |
|---|---|---|
| **a** ✅ | Warnblinkanlage einschalten | Encender las luces de emergencia |
| **b** | Motor unnötig lange laufen lassen | Dejar el motor en marcha innecesariamente |
| **c** | Die Musik lauter stellen | Subir el volumen de la música |
| **d** | Sofort losfahren, um Platz zu machen | Arrancar de inmediato para dejar sitio |

**Erklärung (DE):** Der Warnblinker macht andere Verkehrsteilnehmer sofort auf die Gefahrenstelle aufmerksam.

**Erklärung (Español):** Las luces de emergencia alertan de inmediato a los demás usuarios de la vía sobre el punto de peligro.

**Reviewer notes:** 

---

## fahrtuechtigkeit-39

**Deutsch:** Warum ist es riskant, sich bei der Einschätzung der eigenen Fahrtüchtigkeit auf Erfahrungswerte wie 'ich vertrage viel' zu verlassen?

**Español:** ¿Por qué es arriesgado basarse en experiencias personales del tipo 'yo aguanto mucho' para valorar la propia capacidad de conducir?

| | Deutsch | Español |
|---|---|---|
| **a** ✅ | Eine hohe subjektive Alkoholtoleranz sagt nichts über die tatsächliche Beeinträchtigung von Reaktionsfähigkeit und Wahrnehmung aus | Una alta tolerancia subjetiva al alcohol no dice nada sobre la afectación real de la capacidad de reacción y la percepción |
| **b** | Wer viel verträgt, hat rechtlich automatisch höhere Promillegrenzen | Quien aguanta mucho tiene automáticamente límites de alcoholemia legales más altos |
| **c** | Erfahrungswerte sind die einzige zuverlässige Methode zur Einschätzung | Las experiencias personales son el único método fiable para valorar la situación |
| **d** | Alkoholtoleranz verhindert jede Art von Fahruntüchtigkeit vollständig | La tolerancia al alcohol impide por completo cualquier forma de incapacidad para conducir |

**Erklärung (DE):** Auch bei subjektiv hoher Alkoholtoleranz bleiben Reaktionsfähigkeit, Wahrnehmung und Urteilsvermögen objektiv beeinträchtigt - die gesetzlichen Grenzwerte gelten unabhängig davon.

**Erklärung (Español):** Incluso con una tolerancia subjetivamente alta al alcohol, la capacidad de reacción, la percepción y el juicio siguen estando objetivamente afectados; los límites legales rigen con independencia de ello.

**Reviewer notes:** 

---

## gefahr-40

**Deutsch:** Sie fahren mit einem voll beladenen Fahrzeug eine lange, steile Gefällstrecke hinunter. Warum sollten Sie rechtzeitig in einen niedrigeren Gang schalten, statt nur die Bremse zu nutzen?

**Español:** Conduce un vehículo completamente cargado por una bajada larga y pronunciada. ¿Por qué debería cambiar a tiempo a una marcha más baja en lugar de usar solo el freno?

| | Deutsch | Español |
|---|---|---|
| **a** | Weil ein niedriger Gang den Kraftstoffverbrauch senkt und das der einzige Zweck ist | Porque una marcha baja reduce el consumo de combustible y ese es el único propósito |
| **b** ✅ | Weil dauerhaftes Bremsen bei hoher Last die Bremsen überhitzen und ihre Wirkung nachlassen kann | Porque un frenado continuo con carga alta puede sobrecalentar los frenos y reducir su eficacia |
| **c** | Weil die Bremsen bei Gefällstrecken laut Vorschrift nicht benutzt werden dürfen | Porque, según la normativa, los frenos no pueden usarse en bajadas |
| **d** | Weil ein niedriger Gang das Fahrzeug automatisch leichter macht | Porque una marcha baja hace automáticamente más ligero el vehículo |

**Erklärung (DE):** Bei langem, hoch belastetem Bremsen kann sich das Bremssystem so stark erhitzen, dass die Bremswirkung nachlässt ('Bremsfading'). Ein niedriger Gang nutzt die Motorbremswirkung und entlastet die Betriebsbremse.

**Erklärung (Español):** Con un frenado prolongado y muy exigido, el sistema de frenos puede calentarse tanto que la eficacia de frenado disminuye ('fading' de frenos). Una marcha baja aprovecha el efecto de freno motor y alivia el freno de servicio.

**Reviewer notes:** 

---
