# Zettacard translation review — Українська (`uk`)

Please check the **Українська** against the German. You do not need German — judge whether the Українська reads naturally
and whether the marked correct answer is genuinely the right one.

**What we most need to know:**

1. Does it read like a real person wrote it, or like a machine?
2. Is the ✅ answer actually correct, and are the other three clearly wrong?
3. German words are kept on purpose (`Zeichen 136`, `Vorfahrt`) because they appear on real road signs — is that helpful or confusing?
4. Anything that would confuse or mislead a learner.

---

## vorfahrt-01

**Deutsch:** An einer Kreuzung ohne Verkehrszeichen und ohne Ampel nähern sich zwei Fahrzeuge gleichzeitig. Wer hat Vorfahrt?

**Українська:** На перехресті без дорожніх знаків і без світлофора одночасно наближаються два транспортні засоби. Хто має перевагу проїзду?

| | Deutsch | Українська |
|---|---|---|
| **a** | Wer zuerst an der Kreuzung ankommt | Швидший транспортний засіб |
| **b** ✅ | Das Fahrzeug von rechts | Транспортний засіб, що рухається справа |
| **c** | Das Fahrzeug von links | Більший транспортний засіб |
| **d** | Beide fahren gleichzeitig weiter, ohne sich abzustimmen | Той, хто першим посигналить |

**Erklärung (DE):** Ohne abweichende Beschilderung gilt die Grundregel 'rechts vor links'.

**Erklärung (Українська):** За відсутності інших знаків діє основне правило «перешкода справа».

**Reviewer notes:** 

---

## zeichen-04

**Deutsch:** Ein dreieckiges Warnschild mit spielenden Kindern (Zeichen 136) weist auf was hin?

**Українська:** Трикутний попереджувальний знак з граючими дітьми (знак 136) на що вказує?

| | Deutsch | Українська |
|---|---|---|
| **a** | Eine Schule ohne besondere Vorsicht nötig | На школу, де особлива обережність не потрібна |
| **b** ✅ | Dass Kinder plötzlich auf die Straße laufen können | На можливу раптову появу дітей на проїзній частині |
| **c** | Ein Spielplatzverbot | На заборону дитячого майданчика |
| **d** | Ein Tempolimit von 30 km/h zwingend | На обов'язкове обмеження швидкості 30 км/год |

**Erklärung (DE):** Das Schild warnt vor Kindern in der Nähe der Fahrbahn, z. B. bei Schulen oder Spielplätzen; erhöhte Vorsicht und Bremsbereitschaft sind geboten.

**Erklärung (Українська):** Знак попереджає про дітей поблизу проїзної частини, наприклад біля шкіл чи дитячих майданчиків; потрібні підвищена обережність і готовність до гальмування.

**Reviewer notes:** 

---

## zeichen-118

**Deutsch:** Was bedeutet dieses gelbe Ortsschild mit dem Namen der Ortschaft?

**Українська:** Що означає цей жовтий знак населеного пункту з його назвою?

| | Deutsch | Українська |
|---|---|---|
| **a** ✅ | Ab hier beginnt eine geschlossene Ortschaft; innerorts gilt grundsätzlich Tempo 50. | Звідси починається населений пункт; у межах населеного пункту, як правило, діє швидкість 50 км/год. |
| **b** | Ab hier endet die geschlossene Ortschaft. | Звідси закінчується населений пункт. |
| **c** | Es zeigt zugleich das Ende einer Kraftfahrstraße an. | Це лише вказівний знак без юридичного значення. |
| **d** | Ab hier gilt eine Geschwindigkeitsbegrenzung von 30 km/h. | Звідси діє обмеження швидкості 30 км/год. |

**Erklärung (DE):** Zeichen 310 (Ortstafel, Vorderseite) markiert den Beginn einer geschlossenen Ortschaft; ohne andere Beschilderung gilt ab hier Tempo 50.

**Erklärung (Українська):** Знак 310 (табличка населеного пункту, лицьовий бік) позначає початок населеного пункту; за відсутності іншого позначення звідси діє швидкість 50 км/год.

**Reviewer notes:** 

---

## zeichen-132

**Deutsch:** Unter einem Verkehrszeichen befindet sich ein weißes Zusatzzeichen mit der Aufschrift „Fußgänger“. Was bedeutet das?

**Українська:** Під дорожнім знаком розміщена біла додаткова табличка з написом «Fußgänger» (пішоходи). Що це означає?

| | Deutsch | Українська |
|---|---|---|
| **a** ✅ | Das Zusatzzeichen weist darauf hin, dass sich das Hauptzeichen (auch) auf Fußgänger bezieht. | Додаткова табличка вказує, що правило основного знака стосується (також) і пішоходів. |
| **b** | Fußgänger sind von jeder Regelung durch das Hauptzeichen grundsätzlich ausgenommen. | Пішоходи в принципі звільнені від будь-якого припису основного знака. |
| **c** | Es handelt sich um einen Hinweis auf eine Fußgängerzone. | Це вказівка на пішохідну зону. |
| **d** | Das Zusatzzeichen gilt nur für Rollstuhlfahrer, nicht für andere Fußgänger. | Додаткова табличка діє лише для осіб на візках, а не для решти пішоходів. |

**Erklärung (DE):** Das Zusatzzeichen 1010-53 „Fußgänger“ präzisiert den Geltungsbereich des darüber angebrachten Hauptzeichens: es macht deutlich, dass die Regelung auch Fußgänger einschließt, statt sich (wie ohne Zusatzzeichen oft angenommen) nur auf Fahrzeuge zu beziehen.

**Erklärung (Українська):** Додаткова табличка 1010-53 «Fußgänger» уточнює зону дії розміщеного над нею основного знака: вона чітко показує, що припис поширюється й на пішоходів, а не лише на транспортні засоби, як це часто припускають без такої таблички.

**Reviewer notes:** 

---

## gefahr-06

**Deutsch:** Was bedeutet die Faustregel 'halber Tacho' für den Sicherheitsabstand auf der Autobahn?

**Українська:** Що означає правило «половина спідометра» для безпечної дистанції на автомагістралі?

| | Deutsch | Українська |
|---|---|---|
| **a** ✅ | Der Abstand in Metern soll mindestens der halben Geschwindigkeit in km/h entsprechen | Дистанція в метрах повинна становити щонайменше половину швидкості в км/год |
| **b** | Man soll nur halb so schnell fahren wie erlaubt | Слід їхати вдвічі повільніше, ніж дозволено |
| **c** | Der Abstand darf höchstens die halbe Fahrzeuglänge betragen | Дистанція не повинна перевищувати половину довжини автомобіля |
| **d** | Man soll nach der Hälfte der Strecke eine Pause machen | Потрібно робити зупинку після проходження половини маршруту |

**Erklärung (DE):** Bei 100 km/h wären das mindestens 50 Meter Abstand. Diese Faustregel ist einfach zu merken, ersetzt aber keine genauere Berechnung bei schlechten Bedingungen.

**Erklärung (Українська):** При 100 км/год це означає щонайменше 50 метрів дистанції. Це правило легко запам'ятати, але воно не замінює точнішого розрахунку за поганих умов.

**Reviewer notes:** 

---

## verhalten-09

**Deutsch:** Wer im Auto muss laut Gesetz während der Fahrt angeschnallt sein?

**Українська:** Хто за законом зобов'язаний бути пристебнутим ременем безпеки під час руху автомобіля?

| | Deutsch | Українська |
|---|---|---|
| **a** | Nur der Fahrer | Лише водій |
| **b** | Nur die Personen auf den Vordersitzen | Лише пасажири на передніх сидіннях |
| **c** ✅ | Alle Insassen auf allen Sitzplätzen mit Sicherheitsgurt | Усі пасажири на всіх місцях, обладнаних ременем безпеки |
| **d** | Nur Kinder unter zwölf Jahren | Лише діти до дванадцяти років |

**Erklärung (DE):** Die Anschnallpflicht gilt für alle Insassen auf allen Sitzplätzen, die mit einem Sicherheitsgurt ausgestattet sind, also auch für Personen auf der Rückbank.

**Erklärung (Українська):** Обов'язок пристібатися ременем безпеки стосується всіх пасажирів на всіх місцях, обладнаних ременем безпеки, у тому числі й пасажирів на задньому сидінні.

**Reviewer notes:** 

---

## parken-01

**Deutsch:** Was unterscheidet 'Halten' von 'Parken'?

**Українська:** Чим відрізняється «зупинка» від «стоянки»?

| | Deutsch | Українська |
|---|---|---|
| **a** | Halten ist grundsätzlich verboten, Parken ist immer erlaubt | Зупинка загалом заборонена, стоянка завжди дозволена |
| **b** | Parken darf man nur mit eingeschaltetem Warnblinker | Стояти на стоянці можна лише з увімкненою аварійною сигналізацією |
| **c** ✅ | Parken liegt vor, wenn man länger als drei Minuten hält oder das Fahrzeug verlässt | Стоянкою вважається, якщо ви стоїте довше трьох хвилин або залишаєте автомобіль |
| **d** | Halten ist nur nachts erlaubt | Зупинка дозволена лише вночі |

**Erklärung (DE):** Wer länger als drei Minuten hält oder das Fahrzeug verlässt, parkt im rechtlichen Sinn. Kürzeres Halten, zum Beispiel zum Ein- oder Aussteigen, zählt als Halten.

**Erklärung (Українська):** Той, хто стоїть довше трьох хвилин або залишає автомобіль, у юридичному сенсі здійснює стоянку. Коротша зупинка, наприклад щоб хтось сів чи вийшов, вважається зупинкою.

**Reviewer notes:** 

---

## autobahn-07

**Deutsch:** Auf welcher Seite darf auf der Autobahn normalerweise überholt werden?

**Українська:** З якого боку зазвичай дозволено обгін на автомагістралі?

| | Deutsch | Українська |
|---|---|---|
| **a** | Auf der Seite mit dem geringeren Verkehr | З того боку, де менше руху |
| **b** ✅ | Nur auf der linken Seite | Лише з лівого боку |
| **c** | Auf beiden Seiten, je nach freier Spur | З обох боків, залежно від вільної смуги |
| **d** | Nur auf der rechten Seite | Лише з правого боку |

**Erklärung (DE):** Überholt werden darf grundsätzlich nur links. Rechtsüberholen ist auf der Autobahn nur erlaubt, wenn der Verkehr auf allen Fahrstreifen sich staut und langsamer fließt.

**Erklärung (Українська):** Обгін, як правило, дозволений лише зліва. Обгін справа на автомагістралі дозволений лише тоді, коли рух на всіх смугах уповільнений і затиснутий у затор.

**Reviewer notes:** 

---

## umwelt-08

**Deutsch:** Woran erkennt man einen echten Winterreifen im Gegensatz zu einem reinen Sommerreifen?

**Українська:** За чим можна розпізнати справжню зимову шину на відміну від суто літньої?

| | Deutsch | Українська |
|---|---|---|
| **a** ✅ | Am Alpine-Symbol (Bergpiktogramm mit Schneeflocke) auf der Reifenflanke | За альпійським символом (піктограма гори зі сніжинкою) на боковині шини |
| **b** | Am M+S-Kürzel allein, unabhängig vom Herstellungsdatum des Reifens | Лише за маркуванням M+S, незалежно від дати виготовлення шини |
| **c** | An besonders breiten Reifen, breite Reifen sind automatisch Winterreifen | За особливо широкими шинами, широкі шини автоматично є зимовими |
| **d** | Daran, dass der Reifen als 'Ganzjahresreifen' verkauft wird | За тим, що шина продається як «всесезонна» |

**Erklärung (DE):** Das Alpine-Symbol zeigt, dass ein Reifen die Anforderungen an Wintertauglichkeit erfüllt. Das ältere M+S-Kürzel allein reicht seit einer Übergangsfrist nicht mehr für alle neu hergestellten Reifen aus.

**Erklärung (Українська):** Альпійський символ показує, що шина відповідає вимогам щодо придатності для зими. Старе маркування M+S саме по собі після перехідного періоду вже недостатнє для всіх щойно виготовлених шин.

**Reviewer notes:** 

---

## erstehilfe-04

**Deutsch:** Was sollten Sie unmittelbar tun, sobald Sie nach einem Unfall Ihr Fahrzeug zum Stehen gebracht haben?

**Українська:** Що вам потрібно зробити негайно, як тільки ви зупинили свій автомобіль після аварії?

| | Deutsch | Українська |
|---|---|---|
| **a** ✅ | Warnblinkanlage einschalten | Увімкнути аварійну сигналізацію |
| **b** | Motor unnötig lange laufen lassen | Дати двигуну зайве довго попрацювати |
| **c** | Die Musik lauter stellen | Зробити музику гучнішою |
| **d** | Sofort losfahren, um Platz zu machen | Негайно поїхати, щоб звільнити місце |

**Erklärung (DE):** Der Warnblinker macht andere Verkehrsteilnehmer sofort auf die Gefahrenstelle aufmerksam.

**Erklärung (Українська):** Аварійна сигналізація негайно привертає увагу інших учасників руху до небезпечного місця.

**Reviewer notes:** 

---

## fahrtuechtigkeit-39

**Deutsch:** Warum ist es riskant, sich bei der Einschätzung der eigenen Fahrtüchtigkeit auf Erfahrungswerte wie 'ich vertrage viel' zu verlassen?

**Українська:** Чому ризиковано покладатися на власний досвід на кшталт «я багато витримую» при оцінці власної придатності до керування?

| | Deutsch | Українська |
|---|---|---|
| **a** ✅ | Eine hohe subjektive Alkoholtoleranz sagt nichts über die tatsächliche Beeinträchtigung von Reaktionsfähigkeit und Wahrnehmung aus | Висока суб'єктивна толерантність до алкоголю нічого не говорить про фактичне порушення здатності до реакції та сприйняття |
| **b** | Wer viel verträgt, hat rechtlich automatisch höhere Promillegrenzen | Хто багато витримує, той юридично автоматично має вищі межі проміле |
| **c** | Erfahrungswerte sind die einzige zuverlässige Methode zur Einschätzung | Особистий досвід — єдиний надійний метод оцінки |
| **d** | Alkoholtoleranz verhindert jede Art von Fahruntüchtigkeit vollständig | Толерантність до алкоголю повністю запобігає будь-якому виду непридатності до керування |

**Erklärung (DE):** Auch bei subjektiv hoher Alkoholtoleranz bleiben Reaktionsfähigkeit, Wahrnehmung und Urteilsvermögen objektiv beeinträchtigt - die gesetzlichen Grenzwerte gelten unabhängig davon.

**Erklärung (Українська):** Навіть при суб'єктивно високій толерантності до алкоголю здатність до реакції, сприйняття та розсудливість залишаються об'єктивно порушеними — законодавчі граничні значення діють незалежно від цього.

**Reviewer notes:** 

---

## gefahr-40

**Deutsch:** Sie fahren mit einem voll beladenen Fahrzeug eine lange, steile Gefällstrecke hinunter. Warum sollten Sie rechtzeitig in einen niedrigeren Gang schalten, statt nur die Bremse zu nutzen?

**Українська:** Ви їдете повністю завантаженим транспортним засобом довгим крутим спуском. Чому вам варто вчасно перемкнутися на нижчу передачу, замість того щоб використовувати лише гальма?

| | Deutsch | Українська |
|---|---|---|
| **a** | Weil ein niedriger Gang den Kraftstoffverbrauch senkt und das der einzige Zweck ist | Тому що нижча передача знижує витрату палива, і це єдина мета |
| **b** ✅ | Weil dauerhaftes Bremsen bei hoher Last die Bremsen überhitzen und ihre Wirkung nachlassen kann | Тому що тривале гальмування при великому навантаженні може перегріти гальма і знизити їх ефективність |
| **c** | Weil die Bremsen bei Gefällstrecken laut Vorschrift nicht benutzt werden dürfen | Тому що на спусках гальма, згідно з приписами, використовувати не можна |
| **d** | Weil ein niedriger Gang das Fahrzeug automatisch leichter macht | Тому що нижча передача автоматично робить транспортний засіб легшим |

**Erklärung (DE):** Bei langem, hoch belastetem Bremsen kann sich das Bremssystem so stark erhitzen, dass die Bremswirkung nachlässt ('Bremsfading'). Ein niedriger Gang nutzt die Motorbremswirkung und entlastet die Betriebsbremse.

**Erklärung (Українська):** При тривалому гальмуванні під високим навантаженням гальмівна система може настільки сильно нагрітися, що ефективність гальмування знижується («затухання гальм»). Нижча передача використовує гальмівну дію двигуна і розвантажує робочу гальмівну систему.

**Reviewer notes:** 

---
