# Zettacard translation review — Polski (`pl`)

Please check the **Polski** against the German. You do not need German — judge whether the Polski reads naturally
and whether the marked correct answer is genuinely the right one.

**What we most need to know:**

1. Does it read like a real person wrote it, or like a machine?
2. Is the ✅ answer actually correct, and are the other three clearly wrong?
3. German words are kept on purpose (`Zeichen 136`, `Vorfahrt`) because they appear on real road signs — is that helpful or confusing?
4. Anything that would confuse or mislead a learner.

---

## vorfahrt-01

**Deutsch:** An einer Kreuzung ohne Verkehrszeichen und ohne Ampel nähern sich zwei Fahrzeuge gleichzeitig. Wer hat Vorfahrt?

**Polski:** Na skrzyżowaniu bez znaków drogowych i bez sygnalizacji świetlnej zbliżają się jednocześnie dwa pojazdy. Kto ma pierwszeństwo?

| | Deutsch | Polski |
|---|---|---|
| **a** | Wer zuerst an der Kreuzung ankommt | Szybszy pojazd |
| **b** ✅ | Das Fahrzeug von rechts | Pojazd nadjeżdżający z prawej strony |
| **c** | Das Fahrzeug von links | Większy pojazd |
| **d** | Beide fahren gleichzeitig weiter, ohne sich abzustimmen | Ten, kto pierwszy zatrąbi |

**Erklärung (DE):** Ohne abweichende Beschilderung gilt die Grundregel 'rechts vor links'.

**Erklärung (Polski):** Jeśli nie ma innego oznakowania, obowiązuje podstawowa zasada „prawa strona ma pierwszeństwo”.

**Reviewer notes:** 

---

## zeichen-04

**Deutsch:** Ein dreieckiges Warnschild mit spielenden Kindern (Zeichen 136) weist auf was hin?

**Polski:** Trójkątny znak ostrzegawczy z bawiącymi się dziećmi (znak 136) ostrzega przed czym?

| | Deutsch | Polski |
|---|---|---|
| **a** | Eine Schule ohne besondere Vorsicht nötig | Szkołą, przy której nie trzeba zachowywać szczególnej ostrożności |
| **b** ✅ | Dass Kinder plötzlich auf die Straße laufen können | Możliwym nagłym pojawieniem się dzieci na jezdni |
| **c** | Ein Spielplatzverbot | Zakazem placu zabaw |
| **d** | Ein Tempolimit von 30 km/h zwingend | Obowiązkowym ograniczeniem prędkości do 30 km/h |

**Erklärung (DE):** Das Schild warnt vor Kindern in der Nähe der Fahrbahn, z. B. bei Schulen oder Spielplätzen; erhöhte Vorsicht und Bremsbereitschaft sind geboten.

**Erklärung (Polski):** Znak ostrzega przed dziećmi w pobliżu jezdni, np. przy szkołach lub placach zabaw; wymagana jest zwiększona ostrożność i gotowość do hamowania.

**Reviewer notes:** 

---

## zeichen-118

**Deutsch:** Was bedeutet dieses gelbe Ortsschild mit dem Namen der Ortschaft?

**Polski:** Co oznacza ta żółta tablica z nazwą miejscowości?

| | Deutsch | Polski |
|---|---|---|
| **a** ✅ | Ab hier beginnt eine geschlossene Ortschaft; innerorts gilt grundsätzlich Tempo 50. | Od tego miejsca zaczyna się obszar zabudowany; w terenie zabudowanym z zasady obowiązuje ograniczenie prędkości do 50 km/h. |
| **b** | Ab hier endet die geschlossene Ortschaft. | Od tego miejsca kończy się obszar zabudowany. |
| **c** | Es zeigt zugleich das Ende einer Kraftfahrstraße an. | Jednocześnie oznacza koniec drogi ekspresowej (Kraftfahrstraße). |
| **d** | Ab hier gilt eine Geschwindigkeitsbegrenzung von 30 km/h. | Od tego miejsca obowiązuje ograniczenie prędkości do 30 km/h. |

**Erklärung (DE):** Zeichen 310 (Ortstafel, Vorderseite) markiert den Beginn einer geschlossenen Ortschaft; ohne andere Beschilderung gilt ab hier Tempo 50.

**Erklärung (Polski):** Znak 310 (tablica miejscowości, strona przednia) oznacza początek obszaru zabudowanego; jeśli nie ma innego oznakowania, od tego miejsca obowiązuje prędkość 50 km/h.

**Reviewer notes:** 

---

## zeichen-132

**Deutsch:** Unter einem Verkehrszeichen befindet sich ein weißes Zusatzzeichen mit der Aufschrift „Fußgänger“. Was bedeutet das?

**Polski:** Pod znakiem drogowym znajduje się biała tabliczka dodatkowa z napisem „Fußgänger" (piesi). Co to oznacza?

| | Deutsch | Polski |
|---|---|---|
| **a** ✅ | Das Zusatzzeichen weist darauf hin, dass sich das Hauptzeichen (auch) auf Fußgänger bezieht. | Tabliczka dodatkowa wskazuje, że zasada znaku głównego dotyczy (również) pieszych. |
| **b** | Fußgänger sind von jeder Regelung durch das Hauptzeichen grundsätzlich ausgenommen. | Piesi są co do zasady wyłączeni spod każdej regulacji znaku głównego. |
| **c** | Es handelt sich um einen Hinweis auf eine Fußgängerzone. | Jest to wskazanie na strefę dla pieszych. |
| **d** | Das Zusatzzeichen gilt nur für Rollstuhlfahrer, nicht für andere Fußgänger. | Tabliczka dodatkowa obowiązuje wyłącznie osoby na wózkach inwalidzkich, a nie pozostałych pieszych. |

**Erklärung (DE):** Das Zusatzzeichen 1010-53 „Fußgänger“ präzisiert den Geltungsbereich des darüber angebrachten Hauptzeichens: es macht deutlich, dass die Regelung auch Fußgänger einschließt, statt sich (wie ohne Zusatzzeichen oft angenommen) nur auf Fahrzeuge zu beziehen.

**Erklärung (Polski):** Tabliczka dodatkowa 1010-53 „Fußgänger" doprecyzowuje zakres obowiązywania umieszczonego nad nią znaku głównego: wskazuje wyraźnie, że przepis obejmuje także pieszych, a nie odnosi się wyłącznie do pojazdów, jak często zakłada się bez takiej tabliczki.

**Reviewer notes:** 

---

## gefahr-06

**Deutsch:** Was bedeutet die Faustregel 'halber Tacho' für den Sicherheitsabstand auf der Autobahn?

**Polski:** Co oznacza reguła kciuka „połowa prędkościomierza” dotycząca bezpiecznego odstępu na autostradzie?

| | Deutsch | Polski |
|---|---|---|
| **a** ✅ | Der Abstand in Metern soll mindestens der halben Geschwindigkeit in km/h entsprechen | Odstęp w metrach powinien odpowiadać co najmniej połowie prędkości w km/h |
| **b** | Man soll nur halb so schnell fahren wie erlaubt | Trzeba jechać tylko z połową dozwolonej prędkości |
| **c** | Der Abstand darf höchstens die halbe Fahrzeuglänge betragen | Odstęp może wynosić co najwyżej połowę długości pojazdu |
| **d** | Man soll nach der Hälfte der Strecke eine Pause machen | Trzeba zrobić przerwę po przejechaniu połowy trasy |

**Erklärung (DE):** Bei 100 km/h wären das mindestens 50 Meter Abstand. Diese Faustregel ist einfach zu merken, ersetzt aber keine genauere Berechnung bei schlechten Bedingungen.

**Erklärung (Polski):** Przy 100 km/h byłoby to co najmniej 50 metrów odstępu. Ta reguła kciuka jest łatwa do zapamiętania, ale nie zastępuje dokładniejszego obliczenia przy złych warunkach.

**Reviewer notes:** 

---

## verhalten-09

**Deutsch:** Wer im Auto muss laut Gesetz während der Fahrt angeschnallt sein?

**Polski:** Kto zgodnie z przepisami musi być zapięty pasami podczas jazdy samochodem?

| | Deutsch | Polski |
|---|---|---|
| **a** | Nur der Fahrer | Tylko kierowca |
| **b** | Nur die Personen auf den Vordersitzen | Tylko osoby na przednich siedzeniach |
| **c** ✅ | Alle Insassen auf allen Sitzplätzen mit Sicherheitsgurt | Wszyscy pasażerowie na wszystkich siedzeniach wyposażonych w pasy bezpieczeństwa |
| **d** | Nur Kinder unter zwölf Jahren | Tylko dzieci poniżej dwunastego roku życia |

**Erklärung (DE):** Die Anschnallpflicht gilt für alle Insassen auf allen Sitzplätzen, die mit einem Sicherheitsgurt ausgestattet sind, also auch für Personen auf der Rückbank.

**Erklärung (Polski):** Obowiązek zapinania pasów dotyczy wszystkich pasażerów na wszystkich siedzeniach wyposażonych w pasy bezpieczeństwa, a więc również osób na tylnej kanapie.

**Reviewer notes:** 

---

## parken-01

**Deutsch:** Was unterscheidet 'Halten' von 'Parken'?

**Polski:** Czym różni się „zatrzymanie” od „postoju”?

| | Deutsch | Polski |
|---|---|---|
| **a** | Halten ist grundsätzlich verboten, Parken ist immer erlaubt | Zatrzymanie jest zasadniczo zabronione, postój jest zawsze dozwolony |
| **b** | Parken darf man nur mit eingeschaltetem Warnblinker | Postój jest dozwolony tylko z włączonymi światłami awaryjnymi |
| **c** ✅ | Parken liegt vor, wenn man länger als drei Minuten hält oder das Fahrzeug verlässt | O postoju mówimy, gdy zatrzymujemy się na dłużej niż trzy minuty lub opuszczamy pojazd |
| **d** | Halten ist nur nachts erlaubt | Zatrzymanie jest dozwolone tylko w nocy |

**Erklärung (DE):** Wer länger als drei Minuten hält oder das Fahrzeug verlässt, parkt im rechtlichen Sinn. Kürzeres Halten, zum Beispiel zum Ein- oder Aussteigen, zählt als Halten.

**Erklärung (Polski):** Kto zatrzymuje się na dłużej niż trzy minuty lub opuszcza pojazd, w rozumieniu prawnym parkuje. Krótsze zatrzymanie, na przykład aby kogoś wysadzić lub zabrać, liczy się jako zatrzymanie.

**Reviewer notes:** 

---

## autobahn-07

**Deutsch:** Auf welcher Seite darf auf der Autobahn normalerweise überholt werden?

**Polski:** Z której strony można normalnie wyprzedzać na autostradzie?

| | Deutsch | Polski |
|---|---|---|
| **a** | Auf der Seite mit dem geringeren Verkehr | Ze strony, gdzie jest mniejszy ruch |
| **b** ✅ | Nur auf der linken Seite | Tylko z lewej strony |
| **c** | Auf beiden Seiten, je nach freier Spur | Z obu stron, w zależności od wolnego pasa |
| **d** | Nur auf der rechten Seite | Tylko z prawej strony |

**Erklärung (DE):** Überholt werden darf grundsätzlich nur links. Rechtsüberholen ist auf der Autobahn nur erlaubt, wenn der Verkehr auf allen Fahrstreifen sich staut und langsamer fließt.

**Erklärung (Polski):** Wyprzedzać wolno zasadniczo tylko z lewej strony. Wyprzedzanie z prawej strony jest na autostradzie dozwolone tylko wtedy, gdy na wszystkich pasach ruchu tworzy się korek i ruch odbywa się wolniej.

**Reviewer notes:** 

---

## umwelt-08

**Deutsch:** Woran erkennt man einen echten Winterreifen im Gegensatz zu einem reinen Sommerreifen?

**Polski:** Po czym rozpoznać prawdziwą oponę zimową w odróżnieniu od czystej opony letniej?

| | Deutsch | Polski |
|---|---|---|
| **a** ✅ | Am Alpine-Symbol (Bergpiktogramm mit Schneeflocke) auf der Reifenflanke | Po symbolu alpejskim (piktogram góry ze śnieżynką) na boku opony |
| **b** | Am M+S-Kürzel allein, unabhängig vom Herstellungsdatum des Reifens | Po samym oznaczeniu M+S, niezależnie od daty produkcji opony |
| **c** | An besonders breiten Reifen, breite Reifen sind automatisch Winterreifen | Po szczególnie szerokich oponach, szerokie opony są automatycznie oponami zimowymi |
| **d** | Daran, dass der Reifen als 'Ganzjahresreifen' verkauft wird | Po tym, że opona jest sprzedawana jako „opona całoroczna” |

**Erklärung (DE):** Das Alpine-Symbol zeigt, dass ein Reifen die Anforderungen an Wintertauglichkeit erfüllt. Das ältere M+S-Kürzel allein reicht seit einer Übergangsfrist nicht mehr für alle neu hergestellten Reifen aus.

**Erklärung (Polski):** Symbol alpejski pokazuje, że opona spełnia wymagania dotyczące przydatności zimowej. Samo starsze oznaczenie M+S od zakończenia okresu przejściowego nie wystarcza już dla wszystkich nowo produkowanych opon.

**Reviewer notes:** 

---

## erstehilfe-04

**Deutsch:** Was sollten Sie unmittelbar tun, sobald Sie nach einem Unfall Ihr Fahrzeug zum Stehen gebracht haben?

**Polski:** Co powinni Państwo zrobić natychmiast po zatrzymaniu pojazdu po wypadku?

| | Deutsch | Polski |
|---|---|---|
| **a** ✅ | Warnblinkanlage einschalten | Włączyć światła awaryjne |
| **b** | Motor unnötig lange laufen lassen | Niepotrzebnie pozostawić silnik długo włączony |
| **c** | Die Musik lauter stellen | Zwiększyć głośność muzyki |
| **d** | Sofort losfahren, um Platz zu machen | Natychmiast odjechać, aby zrobić miejsce |

**Erklärung (DE):** Der Warnblinker macht andere Verkehrsteilnehmer sofort auf die Gefahrenstelle aufmerksam.

**Erklärung (Polski):** Światła awaryjne natychmiast zwracają uwagę innych uczestników ruchu na miejsce zagrożenia.

**Reviewer notes:** 

---

## fahrtuechtigkeit-39

**Deutsch:** Warum ist es riskant, sich bei der Einschätzung der eigenen Fahrtüchtigkeit auf Erfahrungswerte wie 'ich vertrage viel' zu verlassen?

**Polski:** Dlaczego ryzykowne jest poleganie przy ocenie własnej zdolności do prowadzenia pojazdu na doświadczeniu w rodzaju „dużo wytrzymuję”?

| | Deutsch | Polski |
|---|---|---|
| **a** ✅ | Eine hohe subjektive Alkoholtoleranz sagt nichts über die tatsächliche Beeinträchtigung von Reaktionsfähigkeit und Wahrnehmung aus | Wysoka subiektywna tolerancja na alkohol nic nie mówi o rzeczywistym ograniczeniu zdolności reakcji i percepcji |
| **b** | Wer viel verträgt, hat rechtlich automatisch höhere Promillegrenzen | Kto dużo wytrzymuje, ma prawnie automatycznie wyższe granice promilowe |
| **c** | Erfahrungswerte sind die einzige zuverlässige Methode zur Einschätzung | Doświadczenie osobiste to jedyna wiarygodna metoda oceny |
| **d** | Alkoholtoleranz verhindert jede Art von Fahruntüchtigkeit vollständig | Tolerancja na alkohol całkowicie zapobiega każdemu rodzajowi niezdolności do prowadzenia pojazdu |

**Erklärung (DE):** Auch bei subjektiv hoher Alkoholtoleranz bleiben Reaktionsfähigkeit, Wahrnehmung und Urteilsvermögen objektiv beeinträchtigt - die gesetzlichen Grenzwerte gelten unabhängig davon.

**Erklärung (Polski):** Nawet przy subiektywnie wysokiej tolerancji na alkohol zdolność reakcji, percepcja i zdolność osądu pozostają obiektywnie ograniczone - ustawowe granice obowiązują niezależnie od tego.

**Reviewer notes:** 

---

## gefahr-40

**Deutsch:** Sie fahren mit einem voll beladenen Fahrzeug eine lange, steile Gefällstrecke hinunter. Warum sollten Sie rechtzeitig in einen niedrigeren Gang schalten, statt nur die Bremse zu nutzen?

**Polski:** Jedziesz w pełni załadowanym pojazdem długim, stromym odcinkiem w dół. Dlaczego powinieneś odpowiednio wcześnie włączyć niższy bieg, zamiast korzystać wyłącznie z hamulca?

| | Deutsch | Polski |
|---|---|---|
| **a** | Weil ein niedriger Gang den Kraftstoffverbrauch senkt und das der einzige Zweck ist | Ponieważ niski bieg zmniejsza zużycie paliwa i to jedyny cel |
| **b** ✅ | Weil dauerhaftes Bremsen bei hoher Last die Bremsen überhitzen und ihre Wirkung nachlassen kann | Ponieważ długotrwałe hamowanie przy dużym obciążeniu może przegrzać hamulce i osłabić ich działanie |
| **c** | Weil die Bremsen bei Gefällstrecken laut Vorschrift nicht benutzt werden dürfen | Ponieważ na stromych zjazdach zgodnie z przepisami nie wolno korzystać z hamulców |
| **d** | Weil ein niedriger Gang das Fahrzeug automatisch leichter macht | Ponieważ niski bieg automatycznie zmniejsza masę pojazdu |

**Erklärung (DE):** Bei langem, hoch belastetem Bremsen kann sich das Bremssystem so stark erhitzen, dass die Bremswirkung nachlässt ('Bremsfading'). Ein niedriger Gang nutzt die Motorbremswirkung und entlastet die Betriebsbremse.

**Erklärung (Polski):** Przy długim, mocno obciążonym hamowaniu układ hamulcowy może się tak mocno rozgrzać, że skuteczność hamowania spada („zanikanie hamulców”). Niski bieg wykorzystuje hamowanie silnikiem i odciąża hamulec zasadniczy.

**Reviewer notes:** 

---
