# Zettacard translation review — English (`en`)

Please check the **English** against the German. You do not need German — judge whether the English reads naturally
and whether the marked correct answer is genuinely the right one.

**What we most need to know:**

1. Does it read like a real person wrote it, or like a machine?
2. Is the ✅ answer actually correct, and are the other three clearly wrong?
3. German words are kept on purpose (`Zeichen 136`, `Vorfahrt`) because they appear on real road signs — is that helpful or confusing?
4. Anything that would confuse or mislead a learner.

---

## vorfahrt-01

**Deutsch:** An einer Kreuzung ohne Verkehrszeichen und ohne Ampel nähern sich zwei Fahrzeuge gleichzeitig. Wer hat Vorfahrt?

**English:** At an intersection with no signs or traffic lights, two vehicles approach at the same time. Who has right of way?

| | Deutsch | English |
|---|---|---|
| **a** | Wer zuerst an der Kreuzung ankommt | Whoever reaches the intersection first |
| **b** ✅ | Das Fahrzeug von rechts | The vehicle coming from the right |
| **c** | Das Fahrzeug von links | The vehicle coming from the left |
| **d** | Beide fahren gleichzeitig weiter, ohne sich abzustimmen | Both keep driving at the same time, without giving way |

**Erklärung (DE):** Ohne abweichende Beschilderung gilt die Grundregel 'rechts vor links'.

**Erklärung (English):** Without signs stating otherwise, the basic rule 'right before left' applies.

**Reviewer notes:** 

---

## zeichen-04

**Deutsch:** Ein dreieckiges Warnschild mit spielenden Kindern (Zeichen 136) weist auf was hin?

**English:** A triangular warning sign showing playing children (Zeichen 136) warns of:

| | Deutsch | English |
|---|---|---|
| **a** | Eine Schule ohne besondere Vorsicht nötig | A school where no special caution is needed |
| **b** ✅ | Dass Kinder plötzlich auf die Straße laufen können | That children might suddenly run onto the road |
| **c** | Ein Spielplatzverbot | A ban on playgrounds |
| **d** | Ein Tempolimit von 30 km/h zwingend | A mandatory 30 km/h speed limit |

**Erklärung (DE):** Das Schild warnt vor Kindern in der Nähe der Fahrbahn, z. B. bei Schulen oder Spielplätzen; erhöhte Vorsicht und Bremsbereitschaft sind geboten.

**Erklärung (English):** The sign warns of children near the road, e.g. near schools or playgrounds; increased caution and readiness to brake are required.

**Reviewer notes:** 

---

## zeichen-118

**Deutsch:** Was bedeutet dieses gelbe Ortsschild mit dem Namen der Ortschaft?

**English:** What does this yellow town-name sign mean?

| | Deutsch | English |
|---|---|---|
| **a** ✅ | Ab hier beginnt eine geschlossene Ortschaft; innerorts gilt grundsätzlich Tempo 50. | A built-up area begins here; the general urban speed limit of 50 km/h applies from this point. |
| **b** | Ab hier endet die geschlossene Ortschaft. | The built-up area ends here. |
| **c** | Es zeigt zugleich das Ende einer Kraftfahrstraße an. | It simultaneously marks the end of a motor-vehicle-only road. |
| **d** | Ab hier gilt eine Geschwindigkeitsbegrenzung von 30 km/h. | A 30 km/h speed limit applies from this point. |

**Erklärung (DE):** Zeichen 310 (Ortstafel, Vorderseite) markiert den Beginn einer geschlossenen Ortschaft; ohne andere Beschilderung gilt ab hier Tempo 50.

**Erklärung (English):** Sign 310 (Ortstafel, front side) marks the start of a built-up area; unless signed otherwise, the general 50 km/h limit applies from this point.

**Reviewer notes:** 

---

## zeichen-132

**Deutsch:** Unter einem Verkehrszeichen befindet sich ein weißes Zusatzzeichen mit der Aufschrift „Fußgänger“. Was bedeutet das?

**English:** A white supplementary sign reading "Fußgänger" (pedestrians) is attached below a traffic sign. What does that mean?

| | Deutsch | English |
|---|---|---|
| **a** ✅ | Das Zusatzzeichen weist darauf hin, dass sich das Hauptzeichen (auch) auf Fußgänger bezieht. | The supplementary sign indicates that the main sign's rule also applies to pedestrians. |
| **b** | Fußgänger sind von jeder Regelung durch das Hauptzeichen grundsätzlich ausgenommen. | Pedestrians are generally exempt from whatever the main sign regulates. |
| **c** | Es handelt sich um einen Hinweis auf eine Fußgängerzone. | It's an indication of a pedestrian zone nearby. |
| **d** | Das Zusatzzeichen gilt nur für Rollstuhlfahrer, nicht für andere Fußgänger. | The supplementary sign only applies to wheelchair users, not other pedestrians. |

**Erklärung (DE):** Das Zusatzzeichen 1010-53 „Fußgänger“ präzisiert den Geltungsbereich des darüber angebrachten Hauptzeichens: es macht deutlich, dass die Regelung auch Fußgänger einschließt, statt sich (wie ohne Zusatzzeichen oft angenommen) nur auf Fahrzeuge zu beziehen.

**Erklärung (English):** The supplementary sign 1010-53 "Fußgänger" clarifies the scope of the main sign above it: it makes clear the rule also includes pedestrians, rather than applying only to vehicles as might otherwise be assumed.

**Reviewer notes:** 

---

## gefahr-06

**Deutsch:** Was bedeutet die Faustregel 'halber Tacho' für den Sicherheitsabstand auf der Autobahn?

**English:** What does the 'half your speedometer reading' rule of thumb mean for following distance on the motorway?

| | Deutsch | English |
|---|---|---|
| **a** ✅ | Der Abstand in Metern soll mindestens der halben Geschwindigkeit in km/h entsprechen | The distance in metres should be at least half your speed in km/h |
| **b** | Man soll nur halb so schnell fahren wie erlaubt | You should only drive at half the allowed speed |
| **c** | Der Abstand darf höchstens die halbe Fahrzeuglänge betragen | The distance may be at most half a vehicle length |
| **d** | Man soll nach der Hälfte der Strecke eine Pause machen | You should take a break after half the route |

**Erklärung (DE):** Bei 100 km/h wären das mindestens 50 Meter Abstand. Diese Faustregel ist einfach zu merken, ersetzt aber keine genauere Berechnung bei schlechten Bedingungen.

**Erklärung (English):** At 100 km/h that would be at least 50 metres of distance. This rule of thumb is easy to remember but does not replace a more careful calculation in poor conditions.

**Reviewer notes:** 

---

## verhalten-09

**Deutsch:** Wer im Auto muss laut Gesetz während der Fahrt angeschnallt sein?

**English:** By law, who in the car must wear a seatbelt while driving?

| | Deutsch | English |
|---|---|---|
| **a** | Nur der Fahrer | Only the driver |
| **b** | Nur die Personen auf den Vordersitzen | Only the people in the front seats |
| **c** ✅ | Alle Insassen auf allen Sitzplätzen mit Sicherheitsgurt | Every occupant on every seat that has a seatbelt |
| **d** | Nur Kinder unter zwölf Jahren | Only children under twelve |

**Erklärung (DE):** Die Anschnallpflicht gilt für alle Insassen auf allen Sitzplätzen, die mit einem Sicherheitsgurt ausgestattet sind, also auch für Personen auf der Rückbank.

**Erklärung (English):** The seatbelt requirement applies to every occupant on every seat fitted with a belt, including passengers in the back seats.

**Reviewer notes:** 

---

## parken-01

**Deutsch:** Was unterscheidet 'Halten' von 'Parken'?

**English:** What is the difference between 'stopping' (Halten) and 'parking' (Parken)?

| | Deutsch | English |
|---|---|---|
| **a** | Halten ist grundsätzlich verboten, Parken ist immer erlaubt | Stopping is generally forbidden, parking is always allowed |
| **b** | Parken darf man nur mit eingeschaltetem Warnblinker | You may only park with the hazard lights switched on |
| **c** ✅ | Parken liegt vor, wenn man länger als drei Minuten hält oder das Fahrzeug verlässt | It counts as parking if you stand still for more than three minutes or leave the vehicle |
| **d** | Halten ist nur nachts erlaubt | Stopping is only allowed at night |

**Erklärung (DE):** Wer länger als drei Minuten hält oder das Fahrzeug verlässt, parkt im rechtlichen Sinn. Kürzeres Halten, zum Beispiel zum Ein- oder Aussteigen, zählt als Halten.

**Erklärung (English):** Standing still for more than three minutes or leaving the vehicle counts legally as parking. Briefer stops, for example to let someone in or out, count as stopping.

**Reviewer notes:** 

---

## autobahn-07

**Deutsch:** Auf welcher Seite darf auf der Autobahn normalerweise überholt werden?

**English:** On which side may you normally overtake on the motorway?

| | Deutsch | English |
|---|---|---|
| **a** | Auf der Seite mit dem geringeren Verkehr | On whichever side has less traffic |
| **b** ✅ | Nur auf der linken Seite | Only on the left side |
| **c** | Auf beiden Seiten, je nach freier Spur | On either side, depending on which lane is free |
| **d** | Nur auf der rechten Seite | Only on the right side |

**Erklärung (DE):** Überholt werden darf grundsätzlich nur links. Rechtsüberholen ist auf der Autobahn nur erlaubt, wenn der Verkehr auf allen Fahrstreifen sich staut und langsamer fließt.

**Erklärung (English):** Overtaking is generally only allowed on the left. Overtaking on the right is only permitted on the motorway when traffic on all lanes is jammed and moving slowly.

**Reviewer notes:** 

---

## umwelt-08

**Deutsch:** Woran erkennt man einen echten Winterreifen im Gegensatz zu einem reinen Sommerreifen?

**English:** How do you recognize a genuine winter tyre as opposed to a pure summer tyre?

| | Deutsch | English |
|---|---|---|
| **a** ✅ | Am Alpine-Symbol (Bergpiktogramm mit Schneeflocke) auf der Reifenflanke | By the Alpine symbol (a mountain with a snowflake) on the tyre sidewall |
| **b** | Am M+S-Kürzel allein, unabhängig vom Herstellungsdatum des Reifens | By the M+S marking alone, regardless of when the tyre was made |
| **c** | An besonders breiten Reifen, breite Reifen sind automatisch Winterreifen | By especially wide tyres, since wide tyres are automatically winter tyres |
| **d** | Daran, dass der Reifen als 'Ganzjahresreifen' verkauft wird | By the fact that it is sold as an 'all-season tyre' |

**Erklärung (DE):** Das Alpine-Symbol zeigt, dass ein Reifen die Anforderungen an Wintertauglichkeit erfüllt. Das ältere M+S-Kürzel allein reicht seit einer Übergangsfrist nicht mehr für alle neu hergestellten Reifen aus.

**Erklärung (English):** The Alpine symbol shows that a tyre meets the requirements for winter suitability. Since a transition period ended, the older M+S marking alone is no longer sufficient for newly manufactured tyres.

**Reviewer notes:** 

---

## erstehilfe-04

**Deutsch:** Was sollten Sie unmittelbar tun, sobald Sie nach einem Unfall Ihr Fahrzeug zum Stehen gebracht haben?

**English:** What should you do immediately once you have stopped your vehicle after a crash?

| | Deutsch | English |
|---|---|---|
| **a** ✅ | Warnblinkanlage einschalten | Switch on the hazard warning lights |
| **b** | Motor unnötig lange laufen lassen | Leave the engine running unnecessarily |
| **c** | Die Musik lauter stellen | Turn the music up |
| **d** | Sofort losfahren, um Platz zu machen | Drive off immediately to make room |

**Erklärung (DE):** Der Warnblinker macht andere Verkehrsteilnehmer sofort auf die Gefahrenstelle aufmerksam.

**Erklärung (English):** Hazard lights immediately alert other road users to the danger spot.

**Reviewer notes:** 

---

## fahrtuechtigkeit-39

**Deutsch:** Warum ist es riskant, sich bei der Einschätzung der eigenen Fahrtüchtigkeit auf Erfahrungswerte wie 'ich vertrage viel' zu verlassen?

**English:** Why is it risky to rely on personal experience such as 'I can handle a lot' when judging your own fitness to drive?

| | Deutsch | English |
|---|---|---|
| **a** ✅ | Eine hohe subjektive Alkoholtoleranz sagt nichts über die tatsächliche Beeinträchtigung von Reaktionsfähigkeit und Wahrnehmung aus | A high subjective alcohol tolerance says nothing about the actual impairment of reaction ability and perception |
| **b** | Wer viel verträgt, hat rechtlich automatisch höhere Promillegrenzen | Anyone who can handle a lot automatically gets higher legal limits |
| **c** | Erfahrungswerte sind die einzige zuverlässige Methode zur Einschätzung | Personal experience is the only reliable way to assess this |
| **d** | Alkoholtoleranz verhindert jede Art von Fahruntüchtigkeit vollständig | Alcohol tolerance fully prevents any kind of unfitness to drive |

**Erklärung (DE):** Auch bei subjektiv hoher Alkoholtoleranz bleiben Reaktionsfähigkeit, Wahrnehmung und Urteilsvermögen objektiv beeinträchtigt - die gesetzlichen Grenzwerte gelten unabhängig davon.

**Erklärung (English):** Even with a subjectively high alcohol tolerance, reaction ability, perception, and judgement remain objectively impaired - the legal limits apply regardless.

**Reviewer notes:** 

---

## gefahr-40

**Deutsch:** Sie fahren mit einem voll beladenen Fahrzeug eine lange, steile Gefällstrecke hinunter. Warum sollten Sie rechtzeitig in einen niedrigeren Gang schalten, statt nur die Bremse zu nutzen?

**English:** You are driving a fully loaded vehicle down a long, steep downhill stretch. Why should you shift into a lower gear in good time instead of relying only on the brakes?

| | Deutsch | English |
|---|---|---|
| **a** | Weil ein niedriger Gang den Kraftstoffverbrauch senkt und das der einzige Zweck ist | Because a low gear reduces fuel consumption and that is the only purpose |
| **b** ✅ | Weil dauerhaftes Bremsen bei hoher Last die Bremsen überhitzen und ihre Wirkung nachlassen kann | Because continuous braking under heavy load can overheat the brakes and reduce their effectiveness |
| **c** | Weil die Bremsen bei Gefällstrecken laut Vorschrift nicht benutzt werden dürfen | Because regulations forbid using the brakes on downhill stretches |
| **d** | Weil ein niedriger Gang das Fahrzeug automatisch leichter macht | Because a low gear automatically makes the vehicle lighter |

**Erklärung (DE):** Bei langem, hoch belastetem Bremsen kann sich das Bremssystem so stark erhitzen, dass die Bremswirkung nachlässt ('Bremsfading'). Ein niedriger Gang nutzt die Motorbremswirkung und entlastet die Betriebsbremse.

**Erklärung (English):** Long, heavily loaded braking can overheat the brake system so much that braking power drops ('brake fade'). A low gear uses engine braking and relieves the service brakes.

**Reviewer notes:** 

---
