# Zettacard translation review — हिन्दी (`hi`)

Please check the **हिन्दी** against the German. You do not need German — judge whether the हिन्दी reads naturally
and whether the marked correct answer is genuinely the right one.

**What we most need to know:**

1. Does it read like a real person wrote it, or like a machine?
2. Is the ✅ answer actually correct, and are the other three clearly wrong?
3. German words are kept on purpose (`Zeichen 136`, `Vorfahrt`) because they appear on real road signs — is that helpful or confusing?
4. Anything that would confuse or mislead a learner.

---

## vorfahrt-01

**Deutsch:** An einer Kreuzung ohne Verkehrszeichen und ohne Ampel nähern sich zwei Fahrzeuge gleichzeitig. Wer hat Vorfahrt?

**हिन्दी:** बिना किसी ट्रैफिक साइन और बिना सिग्नल वाले चौराहे पर दो वाहन एक साथ पहुँचते हैं। किसे प्राथमिकता (Vorfahrt) मिलती है?

| | Deutsch | हिन्दी |
|---|---|---|
| **a** | Wer zuerst an der Kreuzung ankommt | जो वाहन तेज़ चल रहा हो |
| **b** ✅ | Das Fahrzeug von rechts | दाईं ओर से आने वाला वाहन |
| **c** | Das Fahrzeug von links | जो वाहन बड़ा हो |
| **d** | Beide fahren gleichzeitig weiter, ohne sich abzustimmen | जो पहले हॉर्न बजाए |

**Erklärung (DE):** Ohne abweichende Beschilderung gilt die Grundregel 'rechts vor links'.

**Erklärung (हिन्दी):** यदि कोई विशेष साइन न हो, तो मूल नियम 'दाएँ से पहले' (rechts vor links) लागू होता है।

**Reviewer notes:** 

---

## zeichen-04

**Deutsch:** Ein dreieckiges Warnschild mit spielenden Kindern (Zeichen 136) weist auf was hin?

**हिन्दी:** त्रिकोणीय चेतावनी साइन जिस पर खेलते बच्चे दिखाए गए हों (साइन 136), यह किस बारे में सचेत करता है?

| | Deutsch | हिन्दी |
|---|---|---|
| **a** | Eine Schule ohne besondere Vorsicht nötig | एक स्कूल जहाँ खास सावधानी की ज़रूरत नहीं |
| **b** ✅ | Dass Kinder plötzlich auf die Straße laufen können | सड़क पर अचानक बच्चों के आ जाने की संभावना |
| **c** | Ein Spielplatzverbot | खेल के मैदान पर प्रतिबंध |
| **d** | Ein Tempolimit von 30 km/h zwingend | अनिवार्य रूप से 30 किमी/घंटा की गति सीमा |

**Erklärung (DE):** Das Schild warnt vor Kindern in der Nähe der Fahrbahn, z. B. bei Schulen oder Spielplätzen; erhöhte Vorsicht und Bremsbereitschaft sind geboten.

**Erklärung (हिन्दी):** यह साइन सड़क के पास बच्चों (जैसे स्कूल या खेल के मैदान के पास) की चेतावनी देता है; अधिक सतर्कता और ब्रेक लगाने के लिए तैयार रहना ज़रूरी है।

**Reviewer notes:** 

---

## zeichen-118

**Deutsch:** Was bedeutet dieses gelbe Ortsschild mit dem Namen der Ortschaft?

**हिन्दी:** ऑर्ट्सचाफ्ट के नाम वाले इस पीले साइन का क्या मतलब है?

| | Deutsch | हिन्दी |
|---|---|---|
| **a** ✅ | Ab hier beginnt eine geschlossene Ortschaft; innerorts gilt grundsätzlich Tempo 50. | यहाँ से एक बसा हुआ इलाका शुरू होता है; शहर के भीतर आमतौर पर 50 किमी/घंटा की गति लागू होती है। |
| **b** | Ab hier endet die geschlossene Ortschaft. | यहाँ से बसा हुआ इलाका समाप्त होता है। |
| **c** | Es zeigt zugleich das Ende einer Kraftfahrstraße an. | यह बिना किसी कानूनी अर्थ वाली केवल एक दिशा-सूचना है। |
| **d** | Ab hier gilt eine Geschwindigkeitsbegrenzung von 30 km/h. | यहाँ से 30 किमी/घंटा की गति सीमा लागू होती है। |

**Erklärung (DE):** Zeichen 310 (Ortstafel, Vorderseite) markiert den Beginn einer geschlossenen Ortschaft; ohne andere Beschilderung gilt ab hier Tempo 50.

**Erklärung (हिन्दी):** Zeichen 310 (ऑर्ट्सटाफेल, सामने की तरफ) बसे हुए इलाके की शुरुआत को चिह्नित करता है; अलग साइन न होने पर यहाँ से 50 किमी/घंटा की गति लागू होती है।

**Reviewer notes:** 

---

## zeichen-132

**Deutsch:** Unter einem Verkehrszeichen befindet sich ein weißes Zusatzzeichen mit der Aufschrift „Fußgänger“. Was bedeutet das?

**हिन्दी:** एक ट्रैफिक साइन के नीचे 'Fußgänger' (पैदल यात्री) लिखा एक सफ़ेद सहायक साइन लगा है। इसका क्या अर्थ है?

| | Deutsch | हिन्दी |
|---|---|---|
| **a** ✅ | Das Zusatzzeichen weist darauf hin, dass sich das Hauptzeichen (auch) auf Fußgänger bezieht. | यह सहायक साइन बताता है कि मुख्य साइन पैदल यात्रियों पर भी (साथ ही) लागू होता है। |
| **b** | Fußgänger sind von jeder Regelung durch das Hauptzeichen grundsätzlich ausgenommen. | पैदल यात्री मुख्य साइन के किसी भी नियम से मूल रूप से मुक्त हैं। |
| **c** | Es handelt sich um einen Hinweis auf eine Fußgängerzone. | यह पैदल यात्री क्षेत्र (Fußgängerzone) की ओर संकेत है। |
| **d** | Das Zusatzzeichen gilt nur für Rollstuhlfahrer, nicht für andere Fußgänger. | यह सहायक साइन केवल व्हीलचेयर उपयोगकर्ताओं पर लागू होता है, अन्य पैदल यात्रियों पर नहीं। |

**Erklärung (DE):** Das Zusatzzeichen 1010-53 „Fußgänger“ präzisiert den Geltungsbereich des darüber angebrachten Hauptzeichens: es macht deutlich, dass die Regelung auch Fußgänger einschließt, statt sich (wie ohne Zusatzzeichen oft angenommen) nur auf Fahrzeuge zu beziehen.

**Erklärung (हिन्दी):** सहायक साइन 1010-53 'Fußgänger' ऊपर लगे मुख्य साइन के दायरे को स्पष्ट करता है: यह दर्शाता है कि नियम पैदल यात्रियों पर भी लागू होता है, न कि (जैसा सहायक साइन के बिना अक्सर माना जाता है) केवल वाहनों पर।

**Reviewer notes:** 

---

## gefahr-06

**Deutsch:** Was bedeutet die Faustregel 'halber Tacho' für den Sicherheitsabstand auf der Autobahn?

**हिन्दी:** मोटरवे पर सुरक्षित दूरी के लिए 'आधा स्पीडोमीटर' (halber Tacho) नियम का क्या अर्थ है?

| | Deutsch | हिन्दी |
|---|---|---|
| **a** ✅ | Der Abstand in Metern soll mindestens der halben Geschwindigkeit in km/h entsprechen | मीटर में दूरी कम से कम गति (किमी/घंटा) की आधी होनी चाहिए |
| **b** | Man soll nur halb so schnell fahren wie erlaubt | आपको अनुमत गति से केवल आधी गति पर चलना चाहिए |
| **c** | Der Abstand darf höchstens die halbe Fahrzeuglänge betragen | दूरी अधिकतम वाहन की आधी लंबाई जितनी हो सकती है |
| **d** | Man soll nach der Hälfte der Strecke eine Pause machen | आपको आधे रास्ते के बाद ब्रेक लेना चाहिए |

**Erklärung (DE):** Bei 100 km/h wären das mindestens 50 Meter Abstand. Diese Faustregel ist einfach zu merken, ersetzt aber keine genauere Berechnung bei schlechten Bedingungen.

**Erklärung (हिन्दी):** 100 किमी/घंटा पर यह कम से कम 50 मीटर की दूरी होगी। यह नियम याद रखने में आसान है, लेकिन खराब परिस्थितियों में सटीक गणना की जगह नहीं ले सकता।

**Reviewer notes:** 

---

## verhalten-09

**Deutsch:** Wer im Auto muss laut Gesetz während der Fahrt angeschnallt sein?

**हिन्दी:** कानून के अनुसार गाड़ी में कौन सीट बेल्ट लगाना अनिवार्य है, जब गाड़ी चल रही हो?

| | Deutsch | हिन्दी |
|---|---|---|
| **a** | Nur der Fahrer | केवल ड्राइवर |
| **b** | Nur die Personen auf den Vordersitzen | केवल आगे की सीटों पर बैठे लोग |
| **c** ✅ | Alle Insassen auf allen Sitzplätzen mit Sicherheitsgurt | सीट बेल्ट वाली हर सीट पर बैठे सभी यात्री |
| **d** | Nur Kinder unter zwölf Jahren | केवल बारह साल से कम उम्र के बच्चे |

**Erklärung (DE):** Die Anschnallpflicht gilt für alle Insassen auf allen Sitzplätzen, die mit einem Sicherheitsgurt ausgestattet sind, also auch für Personen auf der Rückbank.

**Erklärung (हिन्दी):** सीट बेल्ट लगाने की अनिवार्यता उन सभी सीटों पर बैठे यात्रियों पर लागू होती है जिनमें सीट बेल्ट लगी है, यानी पिछली सीट पर बैठे लोगों पर भी।

**Reviewer notes:** 

---

## parken-01

**Deutsch:** Was unterscheidet 'Halten' von 'Parken'?

**हिन्दी:** 'रुकना' (Halten) और 'पार्किंग' (Parken) में क्या फर्क है?

| | Deutsch | हिन्दी |
|---|---|---|
| **a** | Halten ist grundsätzlich verboten, Parken ist immer erlaubt | रुकना मूल रूप से वर्जित है, पार्किंग हमेशा अनुमत है |
| **b** | Parken darf man nur mit eingeschaltetem Warnblinker | पार्किंग केवल हैज़र्ड लाइट चालू रखने पर ही की जा सकती है |
| **c** ✅ | Parken liegt vor, wenn man länger als drei Minuten hält oder das Fahrzeug verlässt | अगर आप तीन मिनट से अधिक समय तक रुकें या गाड़ी छोड़ दें, तो इसे पार्किंग माना जाता है |
| **d** | Halten ist nur nachts erlaubt | रुकना केवल रात में अनुमत है |

**Erklärung (DE):** Wer länger als drei Minuten hält oder das Fahrzeug verlässt, parkt im rechtlichen Sinn. Kürzeres Halten, zum Beispiel zum Ein- oder Aussteigen, zählt als Halten.

**Erklärung (हिन्दी):** जो तीन मिनट से अधिक समय तक रुकता है या गाड़ी छोड़ देता है, वह कानूनी अर्थ में पार्क कर रहा है। छोटी अवधि के लिए रुकना, उदाहरण के लिए किसी को उतारने या चढ़ाने के लिए, 'रुकना' माना जाता है।

**Reviewer notes:** 

---

## autobahn-07

**Deutsch:** Auf welcher Seite darf auf der Autobahn normalerweise überholt werden?

**हिन्दी:** ऑटोबान पर सामान्यतः किस तरफ से ओवरटेक किया जा सकता है?

| | Deutsch | हिन्दी |
|---|---|---|
| **a** | Auf der Seite mit dem geringeren Verkehr | जिस तरफ यातायात कम हो |
| **b** ✅ | Nur auf der linken Seite | केवल बाईं ओर से |
| **c** | Auf beiden Seiten, je nach freier Spur | किसी भी तरफ से, जो लेन खाली हो उसके अनुसार |
| **d** | Nur auf der rechten Seite | केवल दाईं ओर से |

**Erklärung (DE):** Überholt werden darf grundsätzlich nur links. Rechtsüberholen ist auf der Autobahn nur erlaubt, wenn der Verkehr auf allen Fahrstreifen sich staut und langsamer fließt.

**Erklärung (हिन्दी):** ओवरटेक करने की अनुमति मूल रूप से केवल बाईं ओर से है। ऑटोबान पर दाईं ओर से ओवरटेक करना तभी अनुमत है जब सभी लेन में यातायात जाम हो और धीरे चल रहा हो।

**Reviewer notes:** 

---

## umwelt-08

**Deutsch:** Woran erkennt man einen echten Winterreifen im Gegensatz zu einem reinen Sommerreifen?

**हिन्दी:** एक असली विंटर टायर को सामान्य समर टायर से कैसे पहचाना जाता है?

| | Deutsch | हिन्दी |
|---|---|---|
| **a** ✅ | Am Alpine-Symbol (Bergpiktogramm mit Schneeflocke) auf der Reifenflanke | टायर के किनारे बने अल्पाइन चिह्न (पहाड़ की आकृति और स्नोफ्लेक) से |
| **b** | Am M+S-Kürzel allein, unabhängig vom Herstellungsdatum des Reifens | केवल M+S अक्षरों से, चाहे टायर कब बना हो |
| **c** | An besonders breiten Reifen, breite Reifen sind automatisch Winterreifen | खासतौर पर चौड़े टायरों से, चौड़े टायर अपने आप विंटर टायर नहीं होते |
| **d** | Daran, dass der Reifen als 'Ganzjahresreifen' verkauft wird | इस बात से कि टायर 'ऑल-सीज़न टायर' के रूप में बेचा गया है |

**Erklärung (DE):** Das Alpine-Symbol zeigt, dass ein Reifen die Anforderungen an Wintertauglichkeit erfüllt. Das ältere M+S-Kürzel allein reicht seit einer Übergangsfrist nicht mehr für alle neu hergestellten Reifen aus.

**Erklärung (हिन्दी):** अल्पाइन चिह्न दिखाता है कि टायर सर्दियों के लिए तय शर्तें पूरी करता है। पुराना M+S चिह्न अकेले, एक निश्चित समय-सीमा के बाद, सभी नए बने टायरों के लिए पर्याप्त नहीं रह गया है।

**Reviewer notes:** 

---

## erstehilfe-04

**Deutsch:** Was sollten Sie unmittelbar tun, sobald Sie nach einem Unfall Ihr Fahrzeug zum Stehen gebracht haben?

**हिन्दी:** दुर्घटना के बाद अपने वाहन को रोकते ही आपको तुरंत क्या करना चाहिए?

| | Deutsch | हिन्दी |
|---|---|---|
| **a** ✅ | Warnblinkanlage einschalten | हैज़र्ड लाइट चालू करना |
| **b** | Motor unnötig lange laufen lassen | इंजन को अनावश्यक रूप से लंबे समय तक चलने देना |
| **c** | Die Musik lauter stellen | संगीत तेज कर देना |
| **d** | Sofort losfahren, um Platz zu machen | जगह बनाने के लिए तुरंत आगे बढ़ जाना |

**Erklärung (DE):** Der Warnblinker macht andere Verkehrsteilnehmer sofort auf die Gefahrenstelle aufmerksam.

**Erklärung (हिन्दी):** हैज़र्ड लाइट तुरंत अन्य यातायात प्रतिभागियों का ध्यान खतरे की जगह की ओर आकर्षित करती है।

**Reviewer notes:** 

---

## fahrtuechtigkeit-39

**Deutsch:** Warum ist es riskant, sich bei der Einschätzung der eigenen Fahrtüchtigkeit auf Erfahrungswerte wie 'ich vertrage viel' zu verlassen?

**हिन्दी:** अपनी वाहन चलाने की योग्यता का आकलन करते समय 'मैं बहुत सहन कर सकता हूँ' जैसे अनुभव पर भरोसा करना जोखिमपूर्ण क्यों है?

| | Deutsch | हिन्दी |
|---|---|---|
| **a** ✅ | Eine hohe subjektive Alkoholtoleranz sagt nichts über die tatsächliche Beeinträchtigung von Reaktionsfähigkeit und Wahrnehmung aus | उच्च व्यक्तिपरक अल्कोहल सहनशीलता प्रतिक्रिया क्षमता और धारणा की वास्तविक कमी के बारे में कुछ नहीं बताती |
| **b** | Wer viel verträgt, hat rechtlich automatisch höhere Promillegrenzen | जो अधिक सहन कर सकता है, उसे कानूनी रूप से अपने आप उच्च प्रोमिल सीमा मिल जाती है |
| **c** | Erfahrungswerte sind die einzige zuverlässige Methode zur Einschätzung | अनुभव आकलन का एकमात्र विश्वसनीय तरीका है |
| **d** | Alkoholtoleranz verhindert jede Art von Fahruntüchtigkeit vollständig | अल्कोहल सहनशीलता हर प्रकार की अयोग्यता को पूरी तरह रोक देती है |

**Erklärung (DE):** Auch bei subjektiv hoher Alkoholtoleranz bleiben Reaktionsfähigkeit, Wahrnehmung und Urteilsvermögen objektiv beeinträchtigt - die gesetzlichen Grenzwerte gelten unabhängig davon.

**Erklärung (हिन्दी):** व्यक्तिपरक रूप से उच्च अल्कोहल सहनशीलता के बावजूद, प्रतिक्रिया क्षमता, धारणा और निर्णय क्षमता वस्तुनिष्ठ रूप से प्रभावित रहते हैं - कानूनी सीमाएँ इससे स्वतंत्र लागू होती हैं।

**Reviewer notes:** 

---

## gefahr-40

**Deutsch:** Sie fahren mit einem voll beladenen Fahrzeug eine lange, steile Gefällstrecke hinunter. Warum sollten Sie rechtzeitig in einen niedrigeren Gang schalten, statt nur die Bremse zu nutzen?

**हिन्दी:** आप पूरी तरह लदे वाहन के साथ एक लंबी, खड़ी ढलान से नीचे जा रहे हैं। केवल ब्रेक का उपयोग करने की बजाय आपको समय रहते नीचे गियर में क्यों बदलना चाहिए?

| | Deutsch | हिन्दी |
|---|---|---|
| **a** | Weil ein niedriger Gang den Kraftstoffverbrauch senkt und das der einzige Zweck ist | क्योंकि निचला गियर ईंधन की खपत कम करता है और यही इसका एकमात्र उद्देश्य है |
| **b** ✅ | Weil dauerhaftes Bremsen bei hoher Last die Bremsen überhitzen und ihre Wirkung nachlassen kann | क्योंकि भारी भार में लगातार ब्रेक लगाने से ब्रेक ज़्यादा गरम हो सकते हैं और उनका असर कम हो सकता है |
| **c** | Weil die Bremsen bei Gefällstrecken laut Vorschrift nicht benutzt werden dürfen | क्योंकि नियमों के अनुसार ढलान वाली सड़कों पर ब्रेक का इस्तेमाल नहीं किया जा सकता |
| **d** | Weil ein niedriger Gang das Fahrzeug automatisch leichter macht | क्योंकि निचला गियर वाहन को स्वतः हल्का बना देता है |

**Erklärung (DE):** Bei langem, hoch belastetem Bremsen kann sich das Bremssystem so stark erhitzen, dass die Bremswirkung nachlässt ('Bremsfading'). Ein niedriger Gang nutzt die Motorbremswirkung und entlastet die Betriebsbremse.

**Erklärung (हिन्दी):** लंबे समय तक भारी दबाव में ब्रेक लगाने से ब्रेक सिस्टम इतना गरम हो सकता है कि ब्रेकिंग की क्षमता कम हो जाए ('ब्रेक फेडिंग')। एक निचला गियर इंजन ब्रेकिंग का उपयोग करता है और सर्विस ब्रेक पर दबाव कम करता है।

**Reviewer notes:** 

---
