# Zettacard translation review — Türkçe (`tr`)

Please check the **Türkçe** against the German. You do not need German — judge whether the Türkçe reads naturally
and whether the marked correct answer is genuinely the right one.

**What we most need to know:**

1. Does it read like a real person wrote it, or like a machine?
2. Is the ✅ answer actually correct, and are the other three clearly wrong?
3. German words are kept on purpose (`Zeichen 136`, `Vorfahrt`) because they appear on real road signs — is that helpful or confusing?
4. Anything that would confuse or mislead a learner.

---

## vorfahrt-01

**Deutsch:** An einer Kreuzung ohne Verkehrszeichen und ohne Ampel nähern sich zwei Fahrzeuge gleichzeitig. Wer hat Vorfahrt?

**Türkçe:** İşaretsiz ve trafik ışığı olmayan bir kavşakta iki araç aynı anda yaklaşıyor. Geçiş hakkı kimindir?

| | Deutsch | Türkçe |
|---|---|---|
| **a** | Wer zuerst an der Kreuzung ankommt | Daha hızlı olan araç |
| **b** ✅ | Das Fahrzeug von rechts | Sağdan gelen araç |
| **c** | Das Fahrzeug von links | Daha büyük olan araç |
| **d** | Beide fahren gleichzeitig weiter, ohne sich abzustimmen | Kim önce korna çalarsa |

**Erklärung (DE):** Ohne abweichende Beschilderung gilt die Grundregel 'rechts vor links'.

**Erklärung (Türkçe):** Aksini belirten bir işaret yoksa 'sağdan gelene öncelik' temel kuralı geçerlidir.

**Reviewer notes:** 

---

## zeichen-04

**Deutsch:** Ein dreieckiges Warnschild mit spielenden Kindern (Zeichen 136) weist auf was hin?

**Türkçe:** Oynayan çocuk figürü bulunan üçgen uyarı levhası (Zeichen 136) neye işaret eder?

| | Deutsch | Türkçe |
|---|---|---|
| **a** | Eine Schule ohne besondere Vorsicht nötig | Özel bir dikkat gerektirmeyen bir okul |
| **b** ✅ | Dass Kinder plötzlich auf die Straße laufen können | Çocukların yola aniden çıkabileceği ihtimali |
| **c** | Ein Spielplatzverbot | Bir oyun alanı yasağı |
| **d** | Ein Tempolimit von 30 km/h zwingend | Zorunlu olarak 30 km/sa hız sınırı |

**Erklärung (DE):** Das Schild warnt vor Kindern in der Nähe der Fahrbahn, z. B. bei Schulen oder Spielplätzen; erhöhte Vorsicht und Bremsbereitschaft sind geboten.

**Erklärung (Türkçe):** Bu levha, yol kenarında okullar veya oyun alanları gibi çocukların bulunabileceği yerlerde uyarır; artan dikkat ve frene hazır olma gerekir.

**Reviewer notes:** 

---

## zeichen-118

**Deutsch:** Was bedeutet dieses gelbe Ortsschild mit dem Namen der Ortschaft?

**Türkçe:** Yerleşim yeri adı bulunan bu sarı şehir giriş levhası ne anlama gelir?

| | Deutsch | Türkçe |
|---|---|---|
| **a** ✅ | Ab hier beginnt eine geschlossene Ortschaft; innerorts gilt grundsätzlich Tempo 50. | Buradan itibaren kapalı bir yerleşim yeri başlar; şehir içinde temel olarak 50 km/sa hız geçerlidir. |
| **b** | Ab hier endet die geschlossene Ortschaft. | Buradan itibaren kapalı yerleşim yeri sona erer. |
| **c** | Es zeigt zugleich das Ende einer Kraftfahrstraße an. | Bu, hukuki bir anlamı olmayan sadece bir yön göstergesidir. |
| **d** | Ab hier gilt eine Geschwindigkeitsbegrenzung von 30 km/h. | Buradan itibaren 30 km/sa hız sınırı geçerlidir. |

**Erklärung (DE):** Zeichen 310 (Ortstafel, Vorderseite) markiert den Beginn einer geschlossenen Ortschaft; ohne andere Beschilderung gilt ab hier Tempo 50.

**Erklärung (Türkçe):** Zeichen 310 (şehir giriş levhası, ön yüz), kapalı bir yerleşim yerinin başlangıcını işaretler; başka bir levha olmadığı sürece buradan itibaren 50 km/sa geçerlidir.

**Reviewer notes:** 

---

## zeichen-132

**Deutsch:** Unter einem Verkehrszeichen befindet sich ein weißes Zusatzzeichen mit der Aufschrift „Fußgänger“. Was bedeutet das?

**Türkçe:** Bir trafik işaretinin altında „Fußgänger" (yayalar) yazılı beyaz bir ek levha bulunuyor. Bu ne anlama gelir?

| | Deutsch | Türkçe |
|---|---|---|
| **a** ✅ | Das Zusatzzeichen weist darauf hin, dass sich das Hauptzeichen (auch) auf Fußgänger bezieht. | Ek levha, ana işaretteki kuralın yayalar için de geçerli olduğunu belirtir. |
| **b** | Fußgänger sind von jeder Regelung durch das Hauptzeichen grundsätzlich ausgenommen. | Yayalar, ana işaretin getirdiği her düzenlemeden prensip olarak muaftır. |
| **c** | Es handelt sich um einen Hinweis auf eine Fußgängerzone. | Bu, bir yaya bölgesine yapılan bir işarettir. |
| **d** | Das Zusatzzeichen gilt nur für Rollstuhlfahrer, nicht für andere Fußgänger. | Ek levha yalnızca tekerlekli sandalye kullananlar için geçerlidir, diğer yayalar için değil. |

**Erklärung (DE):** Das Zusatzzeichen 1010-53 „Fußgänger“ präzisiert den Geltungsbereich des darüber angebrachten Hauptzeichens: es macht deutlich, dass die Regelung auch Fußgänger einschließt, statt sich (wie ohne Zusatzzeichen oft angenommen) nur auf Fahrzeuge zu beziehen.

**Erklärung (Türkçe):** 1010-53 „Fußgänger" ek levhası, üzerinde bulunduğu ana işaretin kapsamını netleştirir: kuralın yalnızca araçlara değil, yayalara da uygulandığını açıkça gösterir.

**Reviewer notes:** 

---

## gefahr-06

**Deutsch:** Was bedeutet die Faustregel 'halber Tacho' für den Sicherheitsabstand auf der Autobahn?

**Türkçe:** Otoyolda takip mesafesi için 'yarım hız göstergesi' kuralı ne anlama gelir?

| | Deutsch | Türkçe |
|---|---|---|
| **a** ✅ | Der Abstand in Metern soll mindestens der halben Geschwindigkeit in km/h entsprechen | Metre cinsinden mesafe, km/s cinsinden hızın en az yarısı kadar olmalıdır |
| **b** | Man soll nur halb so schnell fahren wie erlaubt | Sadece izin verilen hızın yarısında gitmelisiniz |
| **c** | Der Abstand darf höchstens die halbe Fahrzeuglänge betragen | Mesafe en fazla aracın yarı uzunluğu kadar olabilir |
| **d** | Man soll nach der Hälfte der Strecke eine Pause machen | Yolun yarısından sonra mola vermelisiniz |

**Erklärung (DE):** Bei 100 km/h wären das mindestens 50 Meter Abstand. Diese Faustregel ist einfach zu merken, ersetzt aber keine genauere Berechnung bei schlechten Bedingungen.

**Erklärung (Türkçe):** 100 km/s'de bu en az 50 metre mesafe demektir. Bu kural akılda tutması kolaydır, ancak kötü koşullarda daha dikkatli bir hesaplamanın yerini tutmaz.

**Reviewer notes:** 

---

## verhalten-09

**Deutsch:** Wer im Auto muss laut Gesetz während der Fahrt angeschnallt sein?

**Türkçe:** Yasaya göre araçta sürüş sırasında kim emniyet kemeri takmalıdır?

| | Deutsch | Türkçe |
|---|---|---|
| **a** | Nur der Fahrer | Sadece sürücü |
| **b** | Nur die Personen auf den Vordersitzen | Sadece ön koltuktaki kişiler |
| **c** ✅ | Alle Insassen auf allen Sitzplätzen mit Sicherheitsgurt | Emniyet kemeri bulunan tüm koltuklardaki tüm yolcular |
| **d** | Nur Kinder unter zwölf Jahren | Sadece on iki yaşın altındaki çocuklar |

**Erklärung (DE):** Die Anschnallpflicht gilt für alle Insassen auf allen Sitzplätzen, die mit einem Sicherheitsgurt ausgestattet sind, also auch für Personen auf der Rückbank.

**Erklärung (Türkçe):** Emniyet kemeri takma zorunluluğu, emniyet kemeriyle donatılmış tüm koltuklardaki tüm yolcular için geçerlidir, yani arka koltuktaki kişiler için de.

**Reviewer notes:** 

---

## parken-01

**Deutsch:** Was unterscheidet 'Halten' von 'Parken'?

**Türkçe:** 'Durma' (Halten) ile 'park etme' (Parken) arasındaki fark nedir?

| | Deutsch | Türkçe |
|---|---|---|
| **a** | Halten ist grundsätzlich verboten, Parken ist immer erlaubt | Durma esasen yasaktır, park etme her zaman serbesttir |
| **b** | Parken darf man nur mit eingeschaltetem Warnblinker | Park etmeye sadece dörtlü flaşörler açıkken izin verilir |
| **c** ✅ | Parken liegt vor, wenn man länger als drei Minuten hält oder das Fahrzeug verlässt | Üç dakikadan uzun süre durulduğunda veya araç terk edildiğinde park etme söz konusudur |
| **d** | Halten ist nur nachts erlaubt | Durma sadece geceleri serbesttir |

**Erklärung (DE):** Wer länger als drei Minuten hält oder das Fahrzeug verlässt, parkt im rechtlichen Sinn. Kürzeres Halten, zum Beispiel zum Ein- oder Aussteigen, zählt als Halten.

**Erklärung (Türkçe):** Üç dakikadan uzun süre duran veya aracı terk eden kişi hukuki anlamda park etmiş sayılır. Örneğin birini indirmek/bindirmek için yapılan daha kısa duraklamalar durma sayılır.

**Reviewer notes:** 

---

## autobahn-07

**Deutsch:** Auf welcher Seite darf auf der Autobahn normalerweise überholt werden?

**Türkçe:** Otoyolda normalde hangi taraftan sollama yapılabilir?

| | Deutsch | Türkçe |
|---|---|---|
| **a** | Auf der Seite mit dem geringeren Verkehr | Trafiğin daha az olduğu taraftan |
| **b** ✅ | Nur auf der linken Seite | Sadece sol taraftan |
| **c** | Auf beiden Seiten, je nach freier Spur | Boş şeride göre her iki taraftan |
| **d** | Nur auf der rechten Seite | Sadece sağ taraftan |

**Erklärung (DE):** Überholt werden darf grundsätzlich nur links. Rechtsüberholen ist auf der Autobahn nur erlaubt, wenn der Verkehr auf allen Fahrstreifen sich staut und langsamer fließt.

**Erklärung (Türkçe):** Sollama esas olarak sadece soldan yapılabilir. Sağdan sollama, otoyolda ancak tüm şeritlerde trafik sıkışık ve yavaş akıyorsa izin verilir.

**Reviewer notes:** 

---

## umwelt-08

**Deutsch:** Woran erkennt man einen echten Winterreifen im Gegensatz zu einem reinen Sommerreifen?

**Türkçe:** Gerçek bir kış lastiği, sadece yaz lastiğinden nasıl ayırt edilir?

| | Deutsch | Türkçe |
|---|---|---|
| **a** ✅ | Am Alpine-Symbol (Bergpiktogramm mit Schneeflocke) auf der Reifenflanke | Lastik yan yüzeyindeki Alpine sembolünden (kar tanesi olan dağ piktogramı) |
| **b** | Am M+S-Kürzel allein, unabhängig vom Herstellungsdatum des Reifens | Lastiğin üretim tarihinden bağımsız olarak sadece M+S kısaltmasından |
| **c** | An besonders breiten Reifen, breite Reifen sind automatisch Winterreifen | Özellikle geniş lastiklerden; geniş lastikler otomatik olarak kış lastiğidir |
| **d** | Daran, dass der Reifen als 'Ganzjahresreifen' verkauft wird | Lastiğin 'dört mevsim lastiği' olarak satılmasından |

**Erklärung (DE):** Das Alpine-Symbol zeigt, dass ein Reifen die Anforderungen an Wintertauglichkeit erfüllt. Das ältere M+S-Kürzel allein reicht seit einer Übergangsfrist nicht mehr für alle neu hergestellten Reifen aus.

**Erklärung (Türkçe):** Alpine sembolü, bir lastiğin kış koşullarına uygunluk gereksinimlerini karşıladığını gösterir. Bir geçiş süresinin sona ermesinden bu yana, sadece eski M+S kısaltması yeni üretilen lastikler için artık yeterli değildir.

**Reviewer notes:** 

---

## erstehilfe-04

**Deutsch:** Was sollten Sie unmittelbar tun, sobald Sie nach einem Unfall Ihr Fahrzeug zum Stehen gebracht haben?

**Türkçe:** Bir kazadan sonra aracınızı durdurur durdurmaz hemen ne yapmalısınız?

| | Deutsch | Türkçe |
|---|---|---|
| **a** ✅ | Warnblinkanlage einschalten | Dörtlü flaşörleri açmak |
| **b** | Motor unnötig lange laufen lassen | Motoru gereksiz yere uzun süre çalışır bırakmak |
| **c** | Die Musik lauter stellen | Müziği açmak |
| **d** | Sofort losfahren, um Platz zu machen | Yer açmak için hemen yola devam etmek |

**Erklärung (DE):** Der Warnblinker macht andere Verkehrsteilnehmer sofort auf die Gefahrenstelle aufmerksam.

**Erklärung (Türkçe):** Dörtlü flaşörler diğer trafik katılımcılarını tehlike noktasına anında dikkat çeker.

**Reviewer notes:** 

---

## fahrtuechtigkeit-39

**Deutsch:** Warum ist es riskant, sich bei der Einschätzung der eigenen Fahrtüchtigkeit auf Erfahrungswerte wie 'ich vertrage viel' zu verlassen?

**Türkçe:** Kendi sürüş yeterliliğinizi değerlendirirken 'çok içkiye dayanıklıyım' gibi tecrübeye dayalı değerlere güvenmek neden risklidir?

| | Deutsch | Türkçe |
|---|---|---|
| **a** ✅ | Eine hohe subjektive Alkoholtoleranz sagt nichts über die tatsächliche Beeinträchtigung von Reaktionsfähigkeit und Wahrnehmung aus | Yüksek öznel alkol toleransı, tepki verme yeteneği ve algının gerçekte ne kadar bozulduğu hakkında hiçbir şey söylemez |
| **b** | Wer viel verträgt, hat rechtlich automatisch höhere Promillegrenzen | Çok içkiye dayanıklı olan biri, hukuken otomatik olarak daha yüksek promil sınırlarına sahip olur |
| **c** | Erfahrungswerte sind die einzige zuverlässige Methode zur Einschätzung | Tecrübeye dayalı değerler, değerlendirme için tek güvenilir yöntemdir |
| **d** | Alkoholtoleranz verhindert jede Art von Fahruntüchtigkeit vollständig | Alkol toleransı her türlü sürüş yetersizliğini tamamen önler |

**Erklärung (DE):** Auch bei subjektiv hoher Alkoholtoleranz bleiben Reaktionsfähigkeit, Wahrnehmung und Urteilsvermögen objektiv beeinträchtigt - die gesetzlichen Grenzwerte gelten unabhängig davon.

**Erklärung (Türkçe):** Öznel olarak yüksek alkol toleransı olsa bile tepki verme yeteneği, algı ve muhakeme gücü nesnel olarak bozulmuş kalır - yasal sınır değerleri bundan bağımsız olarak geçerlidir.

**Reviewer notes:** 

---

## gefahr-40

**Deutsch:** Sie fahren mit einem voll beladenen Fahrzeug eine lange, steile Gefällstrecke hinunter. Warum sollten Sie rechtzeitig in einen niedrigeren Gang schalten, statt nur die Bremse zu nutzen?

**Türkçe:** Tam yüklü bir araçla uzun, dik bir iniş yolunda gidiyorsunuz. Sadece freni kullanmak yerine neden zamanında düşük vitese geçmelisiniz?

| | Deutsch | Türkçe |
|---|---|---|
| **a** | Weil ein niedriger Gang den Kraftstoffverbrauch senkt und das der einzige Zweck ist | Çünkü düşük vites yakıt tüketimini azaltır ve tek amaç budur |
| **b** ✅ | Weil dauerhaftes Bremsen bei hoher Last die Bremsen überhitzen und ihre Wirkung nachlassen kann | Çünkü ağır yük altında sürekli fren yapmak frenleri aşırı ısıtabilir ve etkilerini azaltabilir |
| **c** | Weil die Bremsen bei Gefällstrecken laut Vorschrift nicht benutzt werden dürfen | Çünkü yönetmeliğe göre iniş yollarında fren kullanılamaz |
| **d** | Weil ein niedriger Gang das Fahrzeug automatisch leichter macht | Çünkü düşük vites aracı otomatik olarak hafifletir |

**Erklärung (DE):** Bei langem, hoch belastetem Bremsen kann sich das Bremssystem so stark erhitzen, dass die Bremswirkung nachlässt ('Bremsfading'). Ein niedriger Gang nutzt die Motorbremswirkung und entlastet die Betriebsbremse.

**Erklärung (Türkçe):** Uzun süre ağır yükle fren yapmak, fren sistemini o kadar ısıtabilir ki fren etkisi azalır ('fren solması'). Düşük vites, motor freni etkisinden yararlanır ve ana freni rahatlatır.

**Reviewer notes:** 

---
