# Zettacard translation review — العربية (MSA) (`ar`)

Please check the **العربية (MSA)** against the German. You do not need German — judge whether the العربية (MSA) reads naturally
and whether the marked correct answer is genuinely the right one.

**What we most need to know:**

1. Does it read like a real person wrote it, or like a machine?
2. Is the ✅ answer actually correct, and are the other three clearly wrong?
3. German words are kept on purpose (`Zeichen 136`, `Vorfahrt`) because they appear on real road signs — is that helpful or confusing?
4. Anything that would confuse or mislead a learner.

---

## vorfahrt-01

**Deutsch:** An einer Kreuzung ohne Verkehrszeichen und ohne Ampel nähern sich zwei Fahrzeuge gleichzeitig. Wer hat Vorfahrt?

**العربية (MSA):** عند تقاطع بدون إشارات مرور وبدون إشارة ضوئية، تقترب سيارتان في نفس الوقت. لمن حق الأولوية؟

| | Deutsch | العربية (MSA) |
|---|---|---|
| **a** | Wer zuerst an der Kreuzung ankommt | السيارة الأسرع |
| **b** ✅ | Das Fahrzeug von rechts | السيارة القادمة من اليمين |
| **c** | Das Fahrzeug von links | السيارة الأكبر حجمًا |
| **d** | Beide fahren gleichzeitig weiter, ohne sich abzustimmen | من يضغط على البوق أولًا |

**Erklärung (DE):** Ohne abweichende Beschilderung gilt die Grundregel 'rechts vor links'.

**Erklärung (العربية (MSA)):** في حال عدم وجود لافتات مخالفة، تُطبَّق القاعدة الأساسية 'اليمين قبل اليسار'.

**Reviewer notes:** 

---

## zeichen-04

**Deutsch:** Ein dreieckiges Warnschild mit spielenden Kindern (Zeichen 136) weist auf was hin?

**العربية (MSA):** لافتة تحذيرية مثلثة بها رسم لأطفال يلعبون (الإشارة رقم 136) تُشير إلى ماذا؟

| | Deutsch | العربية (MSA) |
|---|---|---|
| **a** | Eine Schule ohne besondere Vorsicht nötig | مدرسة لا تحتاج إلى حذر خاص |
| **b** ✅ | Dass Kinder plötzlich auf die Straße laufen können | احتمال ظهور أطفال فجأة على الطريق |
| **c** | Ein Spielplatzverbot | منع اللعب في مكان مخصص |
| **d** | Ein Tempolimit von 30 km/h zwingend | حد سرعة إلزامي بواقع 30 كم/س |

**Erklärung (DE):** Das Schild warnt vor Kindern in der Nähe der Fahrbahn, z. B. bei Schulen oder Spielplätzen; erhöhte Vorsicht und Bremsbereitschaft sind geboten.

**Erklärung (العربية (MSA)):** تُحذِّر اللافتة من وجود أطفال بالقرب من الطريق، مثل قرب المدارس أو الملاعب؛ يجب توخي حذر أكبر والاستعداد للفرملة.

**Reviewer notes:** 

---

## zeichen-118

**Deutsch:** Was bedeutet dieses gelbe Ortsschild mit dem Namen der Ortschaft?

**العربية (MSA):** ماذا تعني لوحة اسم البلدة الصفراء هذه التي تحمل اسم البلدة؟

| | Deutsch | العربية (MSA) |
|---|---|---|
| **a** ✅ | Ab hier beginnt eine geschlossene Ortschaft; innerorts gilt grundsätzlich Tempo 50. | من هنا تبدأ منطقة سكنية مأهولة (بلدة)؛ داخل البلدة تسري السرعة القصوى 50 كم/سا من حيث المبدأ. |
| **b** | Ab hier endet die geschlossene Ortschaft. | من هنا تنتهي المنطقة السكنية المأهولة. |
| **c** | Es zeigt zugleich das Ende einer Kraftfahrstraße an. | الأمر يتعلق بلوحة إرشادية بحتة دون أي دلالة قانونية. |
| **d** | Ab hier gilt eine Geschwindigkeitsbegrenzung von 30 km/h. | من هنا تسري سرعة قصوى قدرها 30 كم/سا. |

**Erklärung (DE):** Zeichen 310 (Ortstafel, Vorderseite) markiert den Beginn einer geschlossenen Ortschaft; ohne andere Beschilderung gilt ab hier Tempo 50.

**Erklärung (العربية (MSA)):** تُحدد Zeichen 310 (لوحة اسم البلدة، الوجه الأمامي) بداية منطقة سكنية مأهولة؛ وبدون لافتات أخرى تسري من هنا السرعة القصوى 50 كم/سا.

**Reviewer notes:** 

---

## zeichen-132

**Deutsch:** Unter einem Verkehrszeichen befindet sich ein weißes Zusatzzeichen mit der Aufschrift „Fußgänger“. Was bedeutet das?

**العربية (MSA):** توجد أسفل إشارة مرور لافتة إضافية بيضاء كُتب عليها „Fußgänger" (المشاة). ماذا يعني ذلك؟

| | Deutsch | العربية (MSA) |
|---|---|---|
| **a** ✅ | Das Zusatzzeichen weist darauf hin, dass sich das Hauptzeichen (auch) auf Fußgänger bezieht. | تشير اللافتة الإضافية إلى أن قاعدة الإشارة الرئيسية تنطبق (أيضًا) على المشاة. |
| **b** | Fußgänger sind von jeder Regelung durch das Hauptzeichen grundsätzlich ausgenommen. | المشاة مستثنون مبدئيًا من أي تنظيم تفرضه الإشارة الرئيسية. |
| **c** | Es handelt sich um einen Hinweis auf eine Fußgängerzone. | إنها إشارة تدل على وجود منطقة مشاة. |
| **d** | Das Zusatzzeichen gilt nur für Rollstuhlfahrer, nicht für andere Fußgänger. | تسري اللافتة الإضافية على مستخدمي الكراسي المتحركة فقط، وليس على بقية المشاة. |

**Erklärung (DE):** Das Zusatzzeichen 1010-53 „Fußgänger“ präzisiert den Geltungsbereich des darüber angebrachten Hauptzeichens: es macht deutlich, dass die Regelung auch Fußgänger einschließt, statt sich (wie ohne Zusatzzeichen oft angenommen) nur auf Fahrzeuge zu beziehen.

**Erklärung (العربية (MSA)):** توضّح اللافتة الإضافية 1010-53 „Fußgänger" نطاق سريان الإشارة الرئيسية المثبتة فوقها: فهي تبيّن أن القاعدة تشمل المشاة أيضًا، بدلًا من أن تقتصر على المركبات كما قد يُفترض بدونها.

**Reviewer notes:** 

---

## gefahr-06

**Deutsch:** Was bedeutet die Faustregel 'halber Tacho' für den Sicherheitsabstand auf der Autobahn?

**العربية (MSA):** ماذا تعني القاعدة التقريبية 'نصف قراءة عداد السرعة' بالنسبة للمسافة الأمنة على الطريق السريع؟

| | Deutsch | العربية (MSA) |
|---|---|---|
| **a** ✅ | Der Abstand in Metern soll mindestens der halben Geschwindigkeit in km/h entsprechen | يجب أن تكون المسافة بالمتر مساوية على الأقل لنصف السرعة بالكيلومتر في الساعة |
| **b** | Man soll nur halb so schnell fahren wie erlaubt | يجب القيادة بنصف السرعة المسموح بها فقط |
| **c** | Der Abstand darf höchstens die halbe Fahrzeuglänge betragen | لا يجوز أن تتجاوز المسافة نصف طول المركبة |
| **d** | Man soll nach der Hälfte der Strecke eine Pause machen | يجب أخذ استراحة بعد قطع نصف المسافة |

**Erklärung (DE):** Bei 100 km/h wären das mindestens 50 Meter Abstand. Diese Faustregel ist einfach zu merken, ersetzt aber keine genauere Berechnung bei schlechten Bedingungen.

**Erklärung (العربية (MSA)):** عند سرعة 100 كم/س، تكون المسافة اللازمة 50 مترًا على الأقل. هذه القاعدة التقريبية سهلة التذكر، لكنها لا تُغني عن حساب أدق في الظروف السيئة.

**Reviewer notes:** 

---

## verhalten-09

**Deutsch:** Wer im Auto muss laut Gesetz während der Fahrt angeschnallt sein?

**العربية (MSA):** من في السيارة يجب عليه بموجب القانون ربط حزام الأمان أثناء القيادة؟

| | Deutsch | العربية (MSA) |
|---|---|---|
| **a** | Nur der Fahrer | السائق فقط |
| **b** | Nur die Personen auf den Vordersitzen | الأشخاص الجالسون في المقاعد الأمامية فقط |
| **c** ✅ | Alle Insassen auf allen Sitzplätzen mit Sicherheitsgurt | جميع الركاب في جميع المقاعد المزودة بحزام أمان |
| **d** | Nur Kinder unter zwölf Jahren | الأطفال دون سن الثانية عشرة فقط |

**Erklärung (DE):** Die Anschnallpflicht gilt für alle Insassen auf allen Sitzplätzen, die mit einem Sicherheitsgurt ausgestattet sind, also auch für Personen auf der Rückbank.

**Erklärung (العربية (MSA)):** ينطبق إلزام ربط الحزام على جميع الركاب في جميع المقاعد المزودة بحزام أمان، أي أيضًا على الأشخاص الجالسين في المقعد الخلفي.

**Reviewer notes:** 

---

## parken-01

**Deutsch:** Was unterscheidet 'Halten' von 'Parken'?

**العربية (MSA):** ما الفرق بين 'التوقف المؤقت' و'الوقوف'؟

| | Deutsch | العربية (MSA) |
|---|---|---|
| **a** | Halten ist grundsätzlich verboten, Parken ist immer erlaubt | التوقف المؤقت ممنوع بشكل أساسي، والوقوف مسموح دائمًا |
| **b** | Parken darf man nur mit eingeschaltetem Warnblinker | لا يجوز الوقوف إلا مع تشغيل إشارات التحذير |
| **c** ✅ | Parken liegt vor, wenn man länger als drei Minuten hält oder das Fahrzeug verlässt | يُعتبر وقوفًا إذا بقيت متوقفًا لأكثر من ثلاث دقائق أو غادرت المركبة |
| **d** | Halten ist nur nachts erlaubt | التوقف المؤقت مسموح به فقط ليلاً |

**Erklärung (DE):** Wer länger als drei Minuten hält oder das Fahrzeug verlässt, parkt im rechtlichen Sinn. Kürzeres Halten, zum Beispiel zum Ein- oder Aussteigen, zählt als Halten.

**Erklärung (العربية (MSA)):** من يبقى متوقفًا لأكثر من ثلاث دقائق أو يغادر المركبة، يُعتبر واقفًا بالمعنى القانوني. أما التوقف الأقصر، مثلًا لركوب أو نزول شخص، فيُعتبر توقفًا مؤقتًا.

**Reviewer notes:** 

---

## autobahn-07

**Deutsch:** Auf welcher Seite darf auf der Autobahn normalerweise überholt werden?

**العربية (MSA):** من أي جانب يُسمح عادةً بالتجاوز على الطريق السريع؟

| | Deutsch | العربية (MSA) |
|---|---|---|
| **a** | Auf der Seite mit dem geringeren Verkehr | من الجانب الذي تكون فيه حركة المرور أقل |
| **b** ✅ | Nur auf der linken Seite | فقط من الجانب الأيسر |
| **c** | Auf beiden Seiten, je nach freier Spur | من كلا الجانبين، بحسب المسار الخالي |
| **d** | Nur auf der rechten Seite | فقط من الجانب الأيمن |

**Erklärung (DE):** Überholt werden darf grundsätzlich nur links. Rechtsüberholen ist auf der Autobahn nur erlaubt, wenn der Verkehr auf allen Fahrstreifen sich staut und langsamer fließt.

**Erklärung (العربية (MSA)):** التجاوز مسموح به بشكل أساسي فقط من الجانب الأيسر. التجاوز من اليمين مسموح به على الطريق السريع فقط عندما تكون حركة المرور مزدحمة في جميع المسارات وتسير ببطء.

**Reviewer notes:** 

---

## umwelt-08

**Deutsch:** Woran erkennt man einen echten Winterreifen im Gegensatz zu einem reinen Sommerreifen?

**العربية (MSA):** كيف تُميّز الإطار الشتوي الحقيقي عن الإطار الصيفي البحت؟

| | Deutsch | العربية (MSA) |
|---|---|---|
| **a** ✅ | Am Alpine-Symbol (Bergpiktogramm mit Schneeflocke) auf der Reifenflanke | من خلال رمز جبال الألب (رسم جبل مع رقاقة ثلج) على جانب الإطار |
| **b** | Am M+S-Kürzel allein, unabhängig vom Herstellungsdatum des Reifens | من خلال رمز M+S فقط، بصرف النظر عن تاريخ تصنيع الإطار |
| **c** | An besonders breiten Reifen, breite Reifen sind automatisch Winterreifen | من خلال الإطارات العريضة بشكل خاص، فالإطارات العريضة تُعتبر تلقائيًا إطارات شتوية |
| **d** | Daran, dass der Reifen als 'Ganzjahresreifen' verkauft wird | من خلال بيعه على أنه 'إطار لجميع الفصول' |

**Erklärung (DE):** Das Alpine-Symbol zeigt, dass ein Reifen die Anforderungen an Wintertauglichkeit erfüllt. Das ältere M+S-Kürzel allein reicht seit einer Übergangsfrist nicht mehr für alle neu hergestellten Reifen aus.

**Erklärung (العربية (MSA)):** يُظهر رمز جبال الألب أن الإطار يستوفي متطلبات الملاءمة الشتوية. رمز M+S القديم وحده لم يعد كافيًا لجميع الإطارات المصنّعة حديثًا بعد فترة انتقالية.

**Reviewer notes:** 

---

## erstehilfe-04

**Deutsch:** Was sollten Sie unmittelbar tun, sobald Sie nach einem Unfall Ihr Fahrzeug zum Stehen gebracht haben?

**العربية (MSA):** ما الذي ينبغي عليكم فعله فورًا بمجرد إيقاف مركبتكم بعد وقوع حادث؟

| | Deutsch | العربية (MSA) |
|---|---|---|
| **a** ✅ | Warnblinkanlage einschalten | تشغيل أضواء الطوارئ (الوماضة) |
| **b** | Motor unnötig lange laufen lassen | ترك المحرك يعمل لفترة أطول من اللازم |
| **c** | Die Musik lauter stellen | رفع صوت الموسيقى |
| **d** | Sofort losfahren, um Platz zu machen | الانطلاق فورًا لإفساح المكان |

**Erklärung (DE):** Der Warnblinker macht andere Verkehrsteilnehmer sofort auf die Gefahrenstelle aufmerksam.

**Erklärung (العربية (MSA)):** أضواء الطوارئ تلفت انتباه مستخدمي الطريق الآخرين فورًا إلى نقطة الخطر.

**Reviewer notes:** 

---

## fahrtuechtigkeit-39

**Deutsch:** Warum ist es riskant, sich bei der Einschätzung der eigenen Fahrtüchtigkeit auf Erfahrungswerte wie 'ich vertrage viel' zu verlassen?

**العربية (MSA):** لماذا من الخطير الاعتماد على خبرة شخصية مثل 'أنا أتحمّل الكثير' عند تقييم لياقتكم الخاصة للقيادة؟

| | Deutsch | العربية (MSA) |
|---|---|---|
| **a** ✅ | Eine hohe subjektive Alkoholtoleranz sagt nichts über die tatsächliche Beeinträchtigung von Reaktionsfähigkeit und Wahrnehmung aus | التحمل الذاتي المرتفع للكحول لا يقول شيئًا عن الضعف الفعلي في القدرة على رد الفعل والإدراك |
| **b** | Wer viel verträgt, hat rechtlich automatisch höhere Promillegrenzen | من يتحمل الكثير يحصل قانونيًا تلقائيًا على حدود أعلى لكحول الدم |
| **c** | Erfahrungswerte sind die einzige zuverlässige Methode zur Einschätzung | الخبرة الشخصية هي الطريقة الوحيدة الموثوقة للتقييم |
| **d** | Alkoholtoleranz verhindert jede Art von Fahruntüchtigkeit vollständig | التحمل الكحولي يمنع تمامًا أي شكل من أشكال عدم اللياقة للقيادة |

**Erklärung (DE):** Auch bei subjektiv hoher Alkoholtoleranz bleiben Reaktionsfähigkeit, Wahrnehmung und Urteilsvermögen objektiv beeinträchtigt - die gesetzlichen Grenzwerte gelten unabhängig davon.

**Erklärung (العربية (MSA)):** حتى مع تحمل ذاتي مرتفع للكحول، تبقى القدرة على رد الفعل والإدراك والحكم متأثرة موضوعيًا - وتسري الحدود القانونية بغض النظر عن ذلك.

**Reviewer notes:** 

---

## gefahr-40

**Deutsch:** Sie fahren mit einem voll beladenen Fahrzeug eine lange, steile Gefällstrecke hinunter. Warum sollten Sie rechtzeitig in einen niedrigeren Gang schalten, statt nur die Bremse zu nutzen?

**العربية (MSA):** أنت تقود مركبة محمّلة بالكامل نازلًا منحدرًا طويلًا وشديدًا. لماذا ينبغي عليك التحول إلى نقل أدنى في الوقت المناسب بدلًا من الاعتماد على المكابح فقط؟

| | Deutsch | العربية (MSA) |
|---|---|---|
| **a** | Weil ein niedriger Gang den Kraftstoffverbrauch senkt und das der einzige Zweck ist | لأن النقل المنخفض يقلل استهلاك الوقود، وهذا هو الغرض الوحيد. |
| **b** ✅ | Weil dauerhaftes Bremsen bei hoher Last die Bremsen überhitzen und ihre Wirkung nachlassen kann | لأن الفرملة المستمرة تحت حمولة عالية يمكن أن تُسخّن المكابح وتُضعف فعاليتها. |
| **c** | Weil die Bremsen bei Gefällstrecken laut Vorschrift nicht benutzt werden dürfen | لأنه لا يجوز استخدام المكابح على المنحدرات وفقًا للتعليمات. |
| **d** | Weil ein niedriger Gang das Fahrzeug automatisch leichter macht | لأن النقل المنخفض يجعل المركبة أخف تلقائيًا. |

**Erklärung (DE):** Bei langem, hoch belastetem Bremsen kann sich das Bremssystem so stark erhitzen, dass die Bremswirkung nachlässt ('Bremsfading'). Ein niedriger Gang nutzt die Motorbremswirkung und entlastet die Betriebsbremse.

**Erklärung (العربية (MSA)):** عند الفرملة المطولة تحت حمولة عالية، يمكن أن يسخن نظام الفرامل بشدة إلى درجة تضعف فعالية الفرملة (ما يُسمى "تلاشي الفرامل"). يستخدم النقل المنخفض تأثير فرملة المحرك ويُخفف الحمل عن الفرامل التشغيلية.

**Reviewer notes:** 

---
