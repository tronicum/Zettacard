# Zettacard translation review — 简体中文 (`zh`)

Please check the **简体中文** against the German. You do not need German — judge whether the 简体中文 reads naturally
and whether the marked correct answer is genuinely the right one.

**What we most need to know:**

1. Does it read like a real person wrote it, or like a machine?
2. Is the ✅ answer actually correct, and are the other three clearly wrong?
3. German words are kept on purpose (`Zeichen 136`, `Vorfahrt`) because they appear on real road signs — is that helpful or confusing?
4. Anything that would confuse or mislead a learner.

---

## vorfahrt-01

**Deutsch:** An einer Kreuzung ohne Verkehrszeichen und ohne Ampel nähern sich zwei Fahrzeuge gleichzeitig. Wer hat Vorfahrt?

**简体中文:** 在一个没有交通标志也没有红绿灯的路口,两辆车同时驶近。谁有优先通行权?

| | Deutsch | 简体中文 |
|---|---|---|
| **a** | Wer zuerst an der Kreuzung ankommt | 速度较快的车辆 |
| **b** ✅ | Das Fahrzeug von rechts | 从右侧驶来的车辆 |
| **c** | Das Fahrzeug von links | 体积较大的车辆 |
| **d** | Beide fahren gleichzeitig weiter, ohne sich abzustimmen | 先按喇叭的一方 |

**Erklärung (DE):** Ohne abweichende Beschilderung gilt die Grundregel 'rechts vor links'.

**Erklärung (简体中文):** 如果没有其他标志规定,适用“右方优先”的基本规则。

**Reviewer notes:** 

---

## zeichen-04

**Deutsch:** Ein dreieckiges Warnschild mit spielenden Kindern (Zeichen 136) weist auf was hin?

**简体中文:** 一个三角形警示标志,画有正在玩耍的儿童(标志136),提示什么?

| | Deutsch | 简体中文 |
|---|---|---|
| **a** | Eine Schule ohne besondere Vorsicht nötig | 附近有学校,但无需特别小心 |
| **b** ✅ | Dass Kinder plötzlich auf die Straße laufen können | 儿童可能突然出现在车道上 |
| **c** | Ein Spielplatzverbot | 禁止设置游乐场 |
| **d** | Ein Tempolimit von 30 km/h zwingend | 强制限速30公里/小时 |

**Erklärung (DE):** Das Schild warnt vor Kindern in der Nähe der Fahrbahn, z. B. bei Schulen oder Spielplätzen; erhöhte Vorsicht und Bremsbereitschaft sind geboten.

**Erklärung (简体中文):** 该标志警示附近有儿童出现的可能,例如靠近学校或游乐场;应格外小心并做好随时刹车的准备。

**Reviewer notes:** 

---

## zeichen-118

**Deutsch:** Was bedeutet dieses gelbe Ortsschild mit dem Namen der Ortschaft?

**简体中文:** 这个标有地名的黄色地名标志是什么意思?

| | Deutsch | 简体中文 |
|---|---|---|
| **a** ✅ | Ab hier beginnt eine geschlossene Ortschaft; innerorts gilt grundsätzlich Tempo 50. | 从此处起进入建成区(市区);市区内原则上限速50公里/小时。 |
| **b** | Ab hier endet die geschlossene Ortschaft. | 从此处起建成区(市区)结束。 |
| **c** | Es zeigt zugleich das Ende einer Kraftfahrstraße an. | 它同时表示机动车专用道路(Kraftfahrstraße)的终点。 |
| **d** | Ab hier gilt eine Geschwindigkeitsbegrenzung von 30 km/h. | 从此处起适用30公里/小时限速。 |

**Erklärung (DE):** Zeichen 310 (Ortstafel, Vorderseite) markiert den Beginn einer geschlossenen Ortschaft; ohne andere Beschilderung gilt ab hier Tempo 50.

**Erklärung (简体中文):** Zeichen 310(地名标志正面)标示建成区(市区)的起点;若无其他标志规定,自此处起适用50公里/小时的一般限速。

**Reviewer notes:** 

---

## zeichen-132

**Deutsch:** Unter einem Verkehrszeichen befindet sich ein weißes Zusatzzeichen mit der Aufschrift „Fußgänger“. Was bedeutet das?

**简体中文:** 在某个交通标志下方有一个白色附加标志,上面写着“Fußgänger”(行人)字样。这是什么意思?

| | Deutsch | 简体中文 |
|---|---|---|
| **a** ✅ | Das Zusatzzeichen weist darauf hin, dass sich das Hauptzeichen (auch) auf Fußgänger bezieht. | 该附加标志说明,上方的主标志(也)适用于行人。 |
| **b** | Fußgänger sind von jeder Regelung durch das Hauptzeichen grundsätzlich ausgenommen. | 行人原则上不受主标志所规定内容的约束。 |
| **c** | Es handelt sich um einen Hinweis auf eine Fußgängerzone. | 这是指示行人专用区的标志。 |
| **d** | Das Zusatzzeichen gilt nur für Rollstuhlfahrer, nicht für andere Fußgänger. | 该附加标志仅适用于轮椅使用者,不适用于其他行人。 |

**Erklärung (DE):** Das Zusatzzeichen 1010-53 „Fußgänger“ präzisiert den Geltungsbereich des darüber angebrachten Hauptzeichens: es macht deutlich, dass die Regelung auch Fußgänger einschließt, statt sich (wie ohne Zusatzzeichen oft angenommen) nur auf Fahrzeuge zu beziehen.

**Erklärung (简体中文):** 附加标志1010-53“Fußgänger”(行人)明确了上方主标志的适用范围:它表明该规定也包括行人在内,而不是像没有该附加标志时人们通常以为的那样只针对车辆。

**Reviewer notes:** 

---

## gefahr-06

**Deutsch:** Was bedeutet die Faustregel 'halber Tacho' für den Sicherheitsabstand auf der Autobahn?

**简体中文:** 在高速公路上,“半个时速”这一经验法则对安全跟车距离意味着什么?

| | Deutsch | 简体中文 |
|---|---|---|
| **a** ✅ | Der Abstand in Metern soll mindestens der halben Geschwindigkeit in km/h entsprechen | 以米为单位的距离至少应等于以公里/小时为单位的车速的一半 |
| **b** | Man soll nur halb so schnell fahren wie erlaubt | 行驶速度应只有允许限速的一半 |
| **c** | Der Abstand darf höchstens die halbe Fahrzeuglänge betragen | 距离最多只能是半个车长 |
| **d** | Man soll nach der Hälfte der Strecke eine Pause machen | 行驶到一半路程时应休息一次 |

**Erklärung (DE):** Bei 100 km/h wären das mindestens 50 Meter Abstand. Diese Faustregel ist einfach zu merken, ersetzt aber keine genauere Berechnung bei schlechten Bedingungen.

**Erklärung (简体中文):** 以100公里/小时的车速为例,应至少保持50米的距离。这条经验法则便于记忆,但在恶劣条件下不能替代更精确的计算。

**Reviewer notes:** 

---

## verhalten-09

**Deutsch:** Wer im Auto muss laut Gesetz während der Fahrt angeschnallt sein?

**简体中文:** 根据法律规定，车内哪些人在行驶过程中必须系安全带？

| | Deutsch | 简体中文 |
|---|---|---|
| **a** | Nur der Fahrer | 只有驾驶员 |
| **b** | Nur die Personen auf den Vordersitzen | 只有前排乘客 |
| **c** ✅ | Alle Insassen auf allen Sitzplätzen mit Sicherheitsgurt | 所有配备安全带的座位上的所有乘员 |
| **d** | Nur Kinder unter zwölf Jahren | 只有十二岁以下的儿童 |

**Erklärung (DE):** Die Anschnallpflicht gilt für alle Insassen auf allen Sitzplätzen, die mit einem Sicherheitsgurt ausgestattet sind, also auch für Personen auf der Rückbank.

**Erklärung (简体中文):** 系安全带的义务适用于所有配备安全带座位上的全部乘员，包括后排乘客。

**Reviewer notes:** 

---

## parken-01

**Deutsch:** Was unterscheidet 'Halten' von 'Parken'?

**简体中文:** “停车（Halten）”和“停放（Parken）”有什么区别？

| | Deutsch | 简体中文 |
|---|---|---|
| **a** | Halten ist grundsätzlich verboten, Parken ist immer erlaubt | “停车”原则上是被禁止的，“停放”则始终被允许 |
| **b** | Parken darf man nur mit eingeschaltetem Warnblinker | 只有打开双闪才可以停放 |
| **c** ✅ | Parken liegt vor, wenn man länger als drei Minuten hält oder das Fahrzeug verlässt | 停留时间超过三分钟，或者驾驶者离开了车辆，就构成“停放” |
| **d** | Halten ist nur nachts erlaubt | “停车”只允许在夜间进行 |

**Erklärung (DE):** Wer länger als drei Minuten hält oder das Fahrzeug verlässt, parkt im rechtlichen Sinn. Kürzeres Halten, zum Beispiel zum Ein- oder Aussteigen, zählt als Halten.

**Erklärung (简体中文):** 停留时间超过三分钟，或者驾驶者离开车辆，从法律角度看即构成“停放”。较短暂的停留，例如上下车，则算作“停车”。

**Reviewer notes:** 

---

## autobahn-07

**Deutsch:** Auf welcher Seite darf auf der Autobahn normalerweise überholt werden?

**简体中文:** 在高速公路上，通常允许在哪一侧超车？

| | Deutsch | 简体中文 |
|---|---|---|
| **a** | Auf der Seite mit dem geringeren Verkehr | 车流较少的那一侧 |
| **b** ✅ | Nur auf der linken Seite | 只能在左侧 |
| **c** | Auf beiden Seiten, je nach freier Spur | 两侧都可以，取决于哪个车道空着 |
| **d** | Nur auf der rechten Seite | 只能在右侧 |

**Erklärung (DE):** Überholt werden darf grundsätzlich nur links. Rechtsüberholen ist auf der Autobahn nur erlaubt, wenn der Verkehr auf allen Fahrstreifen sich staut und langsamer fließt.

**Erklärung (简体中文):** 原则上只允许在左侧超车。只有当所有车道的车流都堵塞并且行驶缓慢时，才允许在高速公路上从右侧超车。

**Reviewer notes:** 

---

## umwelt-08

**Deutsch:** Woran erkennt man einen echten Winterreifen im Gegensatz zu einem reinen Sommerreifen?

**简体中文:** 如何辨别真正的冬季轮胎与纯夏季轮胎?

| | Deutsch | 简体中文 |
|---|---|---|
| **a** ✅ | Am Alpine-Symbol (Bergpiktogramm mit Schneeflocke) auf der Reifenflanke | 看轮胎侧面是否有雪花山峰图标(Alpine标志) |
| **b** | Am M+S-Kürzel allein, unabhängig vom Herstellungsdatum des Reifens | 只看M+S标记,而不管轮胎的生产日期 |
| **c** | An besonders breiten Reifen, breite Reifen sind automatisch Winterreifen | 看轮胎是否特别宽,宽轮胎自动就是冬季轮胎 |
| **d** | Daran, dass der Reifen als 'Ganzjahresreifen' verkauft wird | 看轮胎是否被标示为“全季轮胎”出售 |

**Erklärung (DE):** Das Alpine-Symbol zeigt, dass ein Reifen die Anforderungen an Wintertauglichkeit erfüllt. Das ältere M+S-Kürzel allein reicht seit einer Übergangsfrist nicht mehr für alle neu hergestellten Reifen aus.

**Erklärung (简体中文):** 雪花山峰图标表明该轮胎符合冬季性能的要求。自过渡期之后,仅有较旧的M+S标记已不足以满足所有新生产轮胎的要求。

**Reviewer notes:** 

---

## erstehilfe-04

**Deutsch:** Was sollten Sie unmittelbar tun, sobald Sie nach einem Unfall Ihr Fahrzeug zum Stehen gebracht haben?

**简体中文:** 事故后一旦把车停下,您应立即做什么?

| | Deutsch | 简体中文 |
|---|---|---|
| **a** ✅ | Warnblinkanlage einschalten | 打开危险警示灯 |
| **b** | Motor unnötig lange laufen lassen | 让发动机不必要地长时间运转 |
| **c** | Die Musik lauter stellen | 把音乐调大声 |
| **d** | Sofort losfahren, um Platz zu machen | 立即开走以腾出空间 |

**Erklärung (DE):** Der Warnblinker macht andere Verkehrsteilnehmer sofort auf die Gefahrenstelle aufmerksam.

**Erklärung (简体中文):** 危险警示灯能立即提醒其他交通参与者注意危险地点。

**Reviewer notes:** 

---

## fahrtuechtigkeit-39

**Deutsch:** Warum ist es riskant, sich bei der Einschätzung der eigenen Fahrtüchtigkeit auf Erfahrungswerte wie 'ich vertrage viel' zu verlassen?

**简体中文:** 为什么依赖“我的酒量很好”这样的经验来判断自己是否适合驾驶是有风险的?

| | Deutsch | 简体中文 |
|---|---|---|
| **a** ✅ | Eine hohe subjektive Alkoholtoleranz sagt nichts über die tatsächliche Beeinträchtigung von Reaktionsfähigkeit und Wahrnehmung aus | 主观上较高的酒精耐受度并不能说明反应能力和知觉的实际受损程度 |
| **b** | Wer viel verträgt, hat rechtlich automatisch höhere Promillegrenzen | 酒量好的人在法律上会自动获得更高的限值 |
| **c** | Erfahrungswerte sind die einzige zuverlässige Methode zur Einschätzung | 经验值是判断这一点唯一可靠的方法 |
| **d** | Alkoholtoleranz verhindert jede Art von Fahruntüchtigkeit vollständig | 酒精耐受度能完全防止任何形式的驾驶不适宜 |

**Erklärung (DE):** Auch bei subjektiv hoher Alkoholtoleranz bleiben Reaktionsfähigkeit, Wahrnehmung und Urteilsvermögen objektiv beeinträchtigt - die gesetzlichen Grenzwerte gelten unabhängig davon.

**Erklärung (简体中文):** 即使主观上酒精耐受度较高,反应能力、知觉和判断力在客观上仍会受到损害——法定限值与此无关,依然适用。

**Reviewer notes:** 

---

## gefahr-40

**Deutsch:** Sie fahren mit einem voll beladenen Fahrzeug eine lange, steile Gefällstrecke hinunter. Warum sollten Sie rechtzeitig in einen niedrigeren Gang schalten, statt nur die Bremse zu nutzen?

**简体中文:** 您驾驶一辆满载的车辆下一段又长又陡的下坡路。为什么应及时挂入低挡,而不是仅依靠刹车?

| | Deutsch | 简体中文 |
|---|---|---|
| **a** | Weil ein niedriger Gang den Kraftstoffverbrauch senkt und das der einzige Zweck ist | 因为低挡能降低油耗,这是唯一目的 |
| **b** ✅ | Weil dauerhaftes Bremsen bei hoher Last die Bremsen überhitzen und ihre Wirkung nachlassen kann | 因为在高负荷下持续刹车会使刹车过热,导致制动效果下降 |
| **c** | Weil die Bremsen bei Gefällstrecken laut Vorschrift nicht benutzt werden dürfen | 因为按规定下坡路段不得使用刹车 |
| **d** | Weil ein niedriger Gang das Fahrzeug automatisch leichter macht | 因为低挡会自动使车辆变轻 |

**Erklärung (DE):** Bei langem, hoch belastetem Bremsen kann sich das Bremssystem so stark erhitzen, dass die Bremswirkung nachlässt ('Bremsfading'). Ein niedriger Gang nutzt die Motorbremswirkung und entlastet die Betriebsbremse.

**Erklärung (简体中文):** 长时间高负荷刹车会使制动系统过热,导致制动效果下降(即“刹车热衰退”)。挂低挡可以利用发动机制动作用,减轻行车制动系统的负担。

**Reviewer notes:** 

---
