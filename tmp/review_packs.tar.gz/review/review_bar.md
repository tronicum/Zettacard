# Zettacard translation review — Boarisch (`bar`)

Please check the **Boarisch** against the German. You do not need German — judge whether the Boarisch reads naturally
and whether the marked correct answer is genuinely the right one.

**What we most need to know:**

1. Does it read like a real person wrote it, or like a machine?
2. Is the ✅ answer actually correct, and are the other three clearly wrong?
3. German words are kept on purpose (`Zeichen 136`, `Vorfahrt`) because they appear on real road signs — is that helpful or confusing?
4. Anything that would confuse or mislead a learner.

---

## vorfahrt-01

**Deutsch:** An einer Kreuzung ohne Verkehrszeichen und ohne Ampel nähern sich zwei Fahrzeuge gleichzeitig. Wer hat Vorfahrt?

**Boarisch:** An oana Kreizung ohne Verkehrszeichen und ohne Ampel nähern se se zwoa Fahrzeig gleichzeitig. Wer hod Vorfahrt?

| | Deutsch | Boarisch |
|---|---|---|
| **a** | Wer zuerst an der Kreuzung ankommt | Wer zerscht bei da Kreizung ankimmt |
| **b** ✅ | Das Fahrzeug von rechts | Des Fahrzeig von rechts |
| **c** | Das Fahrzeug von links | Des Fahrzeig von links |
| **d** | Beide fahren gleichzeitig weiter, ohne sich abzustimmen | Boade fahrn gleichzeitig weida, ohne se obzstimma |

**Erklärung (DE):** Ohne abweichende Beschilderung gilt die Grundregel 'rechts vor links'.

**Erklärung (Boarisch):** Ohne obweichende Beschilderung gilt de Grundregel 'rechts vor links'.

**Reviewer notes:** 

---

## zeichen-04

**Deutsch:** Ein dreieckiges Warnschild mit spielenden Kindern (Zeichen 136) weist auf was hin?

**Boarisch:** A dreieckiges Warnschuid mit spuinde Kinda (Zeichen 136) weist auf wos hi?

| | Deutsch | Boarisch |
|---|---|---|
| **a** | Eine Schule ohne besondere Vorsicht nötig | A Schui ohne bsondere Vorsicht nötig |
| **b** ✅ | Dass Kinder plötzlich auf die Straße laufen können | Dass Kinda plötzlich auf de Stroß laffa kenna |
| **c** | Ein Spielplatzverbot | A Spuiplatzverbot |
| **d** | Ein Tempolimit von 30 km/h zwingend | A Tempolimit von 30 km/h zwingend |

**Erklärung (DE):** Das Schild warnt vor Kindern in der Nähe der Fahrbahn, z. B. bei Schulen oder Spielplätzen; erhöhte Vorsicht und Bremsbereitschaft sind geboten.

**Erklärung (Boarisch):** Des Schuid warnt vor Kinda in da Nähe vo da Fahrbahn, z. B. bei Schuin oder Spuiplätz; erhöhte Vorsicht und Bremsbereitschaft san gebotn.

**Reviewer notes:** 

---

## zeichen-118

**Deutsch:** Was bedeutet dieses gelbe Ortsschild mit dem Namen der Ortschaft?

**Boarisch:** Wos bedeitet des gelbe Ortsschuid mit dem Nama vo da Ortschaft?

| | Deutsch | Boarisch |
|---|---|---|
| **a** ✅ | Ab hier beginnt eine geschlossene Ortschaft; innerorts gilt grundsätzlich Tempo 50. | Ab do fangt a gschlossene Ortschaft an; innerorts geit grundsätzlich Tempo 50. |
| **b** | Ab hier endet die geschlossene Ortschaft. | Ab do endet de gschlossene Ortschaft. |
| **c** | Es zeigt zugleich das Ende einer Kraftfahrstraße an. | Es zoagt zugleich des Ende vo ana Kraftfahrstroß an. |
| **d** | Ab hier gilt eine Geschwindigkeitsbegrenzung von 30 km/h. | Ab do geit a Gschwindigkeitsbegrenzung vo 30 km/h. |

**Erklärung (DE):** Zeichen 310 (Ortstafel, Vorderseite) markiert den Beginn einer geschlossenen Ortschaft; ohne andere Beschilderung gilt ab hier Tempo 50.

**Erklärung (Boarisch):** Zeichen 310 (Ortstafel, Vorderseite) markiert den Beginn vo ana gschlossenen Ortschaft; ohne andere Beschilderung geit ab do Tempo 50.

**Reviewer notes:** 

---

## zeichen-132

**Deutsch:** Unter einem Verkehrszeichen befindet sich ein weißes Zusatzzeichen mit der Aufschrift „Fußgänger“. Was bedeutet das?

**Boarisch:** Unter am Verkehrszeichen is a weißes Zusatzzeichen mit da Aufschrift „Fußgänger“. Wos bedeitet des?

| | Deutsch | Boarisch |
|---|---|---|
| **a** ✅ | Das Zusatzzeichen weist darauf hin, dass sich das Hauptzeichen (auch) auf Fußgänger bezieht. | Des Zusatzzeichen weist drauf hin, dass si des Hauptzeichen (aa) auf Fußgänger bezieht. |
| **b** | Fußgänger sind von jeder Regelung durch das Hauptzeichen grundsätzlich ausgenommen. | Fußgänger san vo jeda Regelung durch des Hauptzeichen grundsätzlich ausgnomma. |
| **c** | Es handelt sich um einen Hinweis auf eine Fußgängerzone. | Es is a Hinweis auf a Fußgängerzone. |
| **d** | Das Zusatzzeichen gilt nur für Rollstuhlfahrer, nicht für andere Fußgänger. | Des Zusatzzeichen geit bloß für Rollstuihlfahrer, ned für andere Fußgänger. |

**Erklärung (DE):** Das Zusatzzeichen 1010-53 „Fußgänger“ präzisiert den Geltungsbereich des darüber angebrachten Hauptzeichens: es macht deutlich, dass die Regelung auch Fußgänger einschließt, statt sich (wie ohne Zusatzzeichen oft angenommen) nur auf Fahrzeuge zu beziehen.

**Erklärung (Boarisch):** Des Zusatzzeichen 1010-53 „Fußgänger“ präzisiert den Geltungsbereich vom drüba obrochtn Hauptzeichen: es macht deutlich, dass de Regelung aa Fußgänger einschließt, statt si (wia ohne Zusatzzeichen oft ognomma wird) bloß auf Fahrzeig zum beziehn.

**Reviewer notes:** 

---

## gefahr-06

**Deutsch:** Was bedeutet die Faustregel 'halber Tacho' für den Sicherheitsabstand auf der Autobahn?

**Boarisch:** Wos bedeit de Faustregel 'halber Tacho' fia'n Sicherheitsabstand auf da Autobahn?

| | Deutsch | Boarisch |
|---|---|---|
| **a** ✅ | Der Abstand in Metern soll mindestens der halben Geschwindigkeit in km/h entsprechen | Da Obstand in Meter soi mindestns da hoibn Gschwindigkeit in km/h entsprechn |
| **b** | Man soll nur halb so schnell fahren wie erlaubt | Ma soi bloß hoib so schnö fahrn wia erlaubt |
| **c** | Der Abstand darf höchstens die halbe Fahrzeuglänge betragen | Da Obstand derf höchstens de hoibe Fahrzeiglänge betrogn |
| **d** | Man soll nach der Hälfte der Strecke eine Pause machen | Ma soi noch da Hälfte vo da Strecken a Pause macha |

**Erklärung (DE):** Bei 100 km/h wären das mindestens 50 Meter Abstand. Diese Faustregel ist einfach zu merken, ersetzt aber keine genauere Berechnung bei schlechten Bedingungen.

**Erklärung (Boarisch):** Bei 100 km/h warad des mindestens 50 Meter Obstand. Dia Faustregel is einfach zum merka, ersetzt owa koa genauere Berechnung bei schlechte Bedingungen.

**Reviewer notes:** 

---

## verhalten-09

**Deutsch:** Wer im Auto muss laut Gesetz während der Fahrt angeschnallt sein?

**Boarisch:** Wer im Auto muas laut Gsetz während da Fahrt ogschnoit sei?

| | Deutsch | Boarisch |
|---|---|---|
| **a** | Nur der Fahrer | Bloß da Fahrer |
| **b** | Nur die Personen auf den Vordersitzen | Bloß de Personen auf de Vordersitz |
| **c** ✅ | Alle Insassen auf allen Sitzplätzen mit Sicherheitsgurt | Olle Insassen auf olle Sitzplätz mit Sicherheitsgurt |
| **d** | Nur Kinder unter zwölf Jahren | Bloß Kinda unta zwöif Jahr |

**Erklärung (DE):** Die Anschnallpflicht gilt für alle Insassen auf allen Sitzplätzen, die mit einem Sicherheitsgurt ausgestattet sind, also auch für Personen auf der Rückbank.

**Erklärung (Boarisch):** D'Anschnallpflicht gilt für olle Insassen auf olle Sitzplätz, wo mit am Sicherheitsgurt ausgstatt san, also aa für Personen auf da Rückbank.

**Reviewer notes:** 

---

## parken-01

**Deutsch:** Was unterscheidet 'Halten' von 'Parken'?

**Boarisch:** Wos unterscheidet 'Halten' vo 'Parken'?

| | Deutsch | Boarisch |
|---|---|---|
| **a** | Halten ist grundsätzlich verboten, Parken ist immer erlaubt | Halten is grundsätzlich verbotn, Parken is oiwei erlaabt |
| **b** | Parken darf man nur mit eingeschaltetem Warnblinker | Parken derf ma bloß mit eingschaltetem Warnblinker |
| **c** ✅ | Parken liegt vor, wenn man länger als drei Minuten hält oder das Fahrzeug verlässt | Parken liegt vor, wenn ma länger ois drei Minutn hoit oder's Fahrzeig verlasst |
| **d** | Halten ist nur nachts erlaubt | Halten is bloß nachts erlaabt |

**Erklärung (DE):** Wer länger als drei Minuten hält oder das Fahrzeug verlässt, parkt im rechtlichen Sinn. Kürzeres Halten, zum Beispiel zum Ein- oder Aussteigen, zählt als Halten.

**Erklärung (Boarisch):** Wer länger ois drei Minutn hoit oder's Fahrzeig verlasst, parkt im rechtlichn Sinn. Kürzeres Halten, zum Beispui zum Ei- oder Aussteign, zöhlt ois Halten.

**Reviewer notes:** 

---

## autobahn-07

**Deutsch:** Auf welcher Seite darf auf der Autobahn normalerweise überholt werden?

**Boarisch:** Auf welcher Seitn derf auf da Autobahn normalerweis übaholt wern?

| | Deutsch | Boarisch |
|---|---|---|
| **a** | Auf der Seite mit dem geringeren Verkehr | Auf da Seitn mit'm geringern Verkehr |
| **b** ✅ | Nur auf der linken Seite | Bloß auf da linken Seitn |
| **c** | Auf beiden Seiten, je nach freier Spur | Auf beide Seitn, je noch freier Spur |
| **d** | Nur auf der rechten Seite | Bloß auf da rechten Seitn |

**Erklärung (DE):** Überholt werden darf grundsätzlich nur links. Rechtsüberholen ist auf der Autobahn nur erlaubt, wenn der Verkehr auf allen Fahrstreifen sich staut und langsamer fließt.

**Erklärung (Boarisch):** Übaholt wern derf grundsätzlich bloß links. Rechtsübaholn is auf da Autobahn bloß erlaabt, wenn si da Verkehr auf olle Fahrstreifen staut und langsamer fließt.

**Reviewer notes:** 

---

## umwelt-08

**Deutsch:** Woran erkennt man einen echten Winterreifen im Gegensatz zu einem reinen Sommerreifen?

**Boarisch:** Woran erkennt ma an echt'n Winterreifn im Gegensatz zu am reinen Sommerreifn?

| | Deutsch | Boarisch |
|---|---|---|
| **a** ✅ | Am Alpine-Symbol (Bergpiktogramm mit Schneeflocke) auf der Reifenflanke | Am Alpine-Symbol (Bergpiktogramm mit Schneeflockn) auf da Reifnflank |
| **b** | Am M+S-Kürzel allein, unabhängig vom Herstellungsdatum des Reifens | Am M+S-Kürzel alloa, unabhängig vom Herstellungsdatum vom Reifn |
| **c** | An besonders breiten Reifen, breite Reifen sind automatisch Winterreifen | An bsonders breite Reifn, breite Reifn san automatisch Winterreifn |
| **d** | Daran, dass der Reifen als 'Ganzjahresreifen' verkauft wird | Daran, dass da Reifn als 'Ganzjahresreifen' verkauft werd |

**Erklärung (DE):** Das Alpine-Symbol zeigt, dass ein Reifen die Anforderungen an Wintertauglichkeit erfüllt. Das ältere M+S-Kürzel allein reicht seit einer Übergangsfrist nicht mehr für alle neu hergestellten Reifen aus.

**Erklärung (Boarisch):** Des Alpine-Symbol zoagt, dass a Reifn de Anforderungen an d'Wintertauglichkeit erfüllt. Des ältere M+S-Kürzel alloa reicht seit ana Übergangsfrist nimma für olle neu hergstellte Reifn aus.

**Reviewer notes:** 

---

## erstehilfe-04

**Deutsch:** Was sollten Sie unmittelbar tun, sobald Sie nach einem Unfall Ihr Fahrzeug zum Stehen gebracht haben?

**Boarisch:** Wos sollt'n Sie unmittelbar toa, sobold Sie noch am Unfoi Eahna Fahrzeig zum Stengan bracht hom?

| | Deutsch | Boarisch |
|---|---|---|
| **a** ✅ | Warnblinkanlage einschalten | Warnblinkanlage eischoitn |
| **b** | Motor unnötig lange laufen lassen | Motor unnötig lang laffa lossn |
| **c** | Die Musik lauter stellen | De Musi lauter stelln |
| **d** | Sofort losfahren, um Platz zu machen | Sofort losfahrn, um Platz z mocha |

**Erklärung (DE):** Der Warnblinker macht andere Verkehrsteilnehmer sofort auf die Gefahrenstelle aufmerksam.

**Erklärung (Boarisch):** Da Warnblinker mocht andere Verkehrsteilnehmer sofort auf de Gfoahrnstej aufmerksam.

**Reviewer notes:** 

---

## fahrtuechtigkeit-39

**Deutsch:** Warum ist es riskant, sich bei der Einschätzung der eigenen Fahrtüchtigkeit auf Erfahrungswerte wie 'ich vertrage viel' zu verlassen?

**Boarisch:** Warum is es riskant, se bei da Einschätzung vo da eigenen Fahrtüchtigkeit auf Erfahrungswert wia 'i vertrog vui' z verlossn?

| | Deutsch | Boarisch |
|---|---|---|
| **a** ✅ | Eine hohe subjektive Alkoholtoleranz sagt nichts über die tatsächliche Beeinträchtigung von Reaktionsfähigkeit und Wahrnehmung aus | A hohe subjektive Alkoholtoleranz sogt nix über de tatsächliche Beeinträchtigung vo Reaktionsfähigkeit und Wahrnehmung aus |
| **b** | Wer viel verträgt, hat rechtlich automatisch höhere Promillegrenzen | Wer vui verträgt, hot rechtlich automatisch höhere Promillegrenzn |
| **c** | Erfahrungswerte sind die einzige zuverlässige Methode zur Einschätzung | Erfahrungswert san de oanzige zuverlässige Methode zur Einschätzung |
| **d** | Alkoholtoleranz verhindert jede Art von Fahruntüchtigkeit vollständig | Alkoholtoleranz verhindert jede Ort vo Fahruntüchtigkeit vollständig |

**Erklärung (DE):** Auch bei subjektiv hoher Alkoholtoleranz bleiben Reaktionsfähigkeit, Wahrnehmung und Urteilsvermögen objektiv beeinträchtigt - die gesetzlichen Grenzwerte gelten unabhängig davon.

**Erklärung (Boarisch):** Aa bei subjektiv hoher Alkoholtoleranz bleim Reaktionsfähigkeit, Wahrnehmung und Urteilsvermögn objektiv beeinträchtigt - de gsetzlichn Grenzwert gelten unabhängig davo.

**Reviewer notes:** 

---

## gefahr-40

**Deutsch:** Sie fahren mit einem voll beladenen Fahrzeug eine lange, steile Gefällstrecke hinunter. Warum sollten Sie rechtzeitig in einen niedrigeren Gang schalten, statt nur die Bremse zu nutzen?

**Boarisch:** Sie fahrn mit am voi beladenen Fahrzeig a lange, steile Gfällstreckn owe. Warum soitn Sie rechtzeitig in an niadrigern Gang schoitn, statt bloß de Bremsn zum nutzn?

| | Deutsch | Boarisch |
|---|---|---|
| **a** | Weil ein niedriger Gang den Kraftstoffverbrauch senkt und das der einzige Zweck ist | Weil a niadriger Gang den Kraftstoffverbrauch senkt und des der oanzige Zweck is |
| **b** ✅ | Weil dauerhaftes Bremsen bei hoher Last die Bremsen überhitzen und ihre Wirkung nachlassen kann | Weil dauerhaftes Bremsn bei hoher Last de Bremsn überhitzn und ihre Wirkung nochlossn ko |
| **c** | Weil die Bremsen bei Gefällstrecken laut Vorschrift nicht benutzt werden dürfen | Weil de Bremsn bei Gfällstreckn laut Vorschrift ned benutzt werdn derfn |
| **d** | Weil ein niedriger Gang das Fahrzeug automatisch leichter macht | Weil a niadriger Gang des Fahrzeig automatisch leichter macht |

**Erklärung (DE):** Bei langem, hoch belastetem Bremsen kann sich das Bremssystem so stark erhitzen, dass die Bremswirkung nachlässt ('Bremsfading'). Ein niedriger Gang nutzt die Motorbremswirkung und entlastet die Betriebsbremse.

**Erklärung (Boarisch):** Bei langem, hoch belastetem Bremsn ko sich des Bremssystem so stark erhitzn, dass de Bremswirkung nochlosst ('Bremsfading'). A niadriger Gang nutzt de Motorbremswirkung und entlastet de Betriebsbremse.

**Reviewer notes:** 

---
