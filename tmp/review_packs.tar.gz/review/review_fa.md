# Zettacard translation review — فارسی (`fa`)

Please check the **فارسی** against the German. You do not need German — judge whether the فارسی reads naturally
and whether the marked correct answer is genuinely the right one.

**What we most need to know:**

1. Does it read like a real person wrote it, or like a machine?
2. Is the ✅ answer actually correct, and are the other three clearly wrong?
3. German words are kept on purpose (`Zeichen 136`, `Vorfahrt`) because they appear on real road signs — is that helpful or confusing?
4. Anything that would confuse or mislead a learner.

---

## vorfahrt-01

**Deutsch:** An einer Kreuzung ohne Verkehrszeichen und ohne Ampel nähern sich zwei Fahrzeuge gleichzeitig. Wer hat Vorfahrt?

**فارسی:** در یک تقاطع بدون تابلوی راهنمایی و بدون چراغ راهنما، دو خودرو همزمان به تقاطع نزدیک می‌شوند. حق تقدم با کیست؟

| | Deutsch | فارسی |
|---|---|---|
| **a** | Wer zuerst an der Kreuzung ankommt | هر کس زودتر به تقاطع برسد |
| **b** ✅ | Das Fahrzeug von rechts | خودرویی که از سمت راست می‌آید |
| **c** | Das Fahrzeug von links | خودرویی که از سمت چپ می‌آید |
| **d** | Beide fahren gleichzeitig weiter, ohne sich abzustimmen | هر دو بدون هماهنگی همزمان به حرکت ادامه می‌دهند |

**Erklärung (DE):** Ohne abweichende Beschilderung gilt die Grundregel 'rechts vor links'.

**Erklärung (فارسی):** در صورت نبود تابلوی متفاوت، قاعده‌ی پایه‌ی «راست بر چپ مقدم است» اعمال می‌شود.

**Reviewer notes:** 

---

## zeichen-04

**Deutsch:** Ein dreieckiges Warnschild mit spielenden Kindern (Zeichen 136) weist auf was hin?

**فارسی:** یک تابلوی هشدار مثلثی با تصویر کودکان در حال بازی (Zeichen 136) به چه چیزی اشاره دارد؟

| | Deutsch | فارسی |
|---|---|---|
| **a** | Eine Schule ohne besondere Vorsicht nötig | مدرسه‌ای که نیازی به احتیاط ویژه ندارد |
| **b** ✅ | Dass Kinder plötzlich auf die Straße laufen können | اینکه ممکن است کودکان ناگهان به داخل خیابان بدوند |
| **c** | Ein Spielplatzverbot | ممنوعیت زمین بازی |
| **d** | Ein Tempolimit von 30 km/h zwingend | محدودیت سرعت اجباری 30 کیلومتر بر ساعت |

**Erklärung (DE):** Das Schild warnt vor Kindern in der Nähe der Fahrbahn, z. B. bei Schulen oder Spielplätzen; erhöhte Vorsicht und Bremsbereitschaft sind geboten.

**Erklärung (فارسی):** این تابلو نسبت به حضور کودکان در نزدیکی جاده هشدار می‌دهد، مثلاً نزدیک مدارس یا زمین‌های بازی؛ احتیاط بیشتر و آمادگی برای ترمز لازم است.

**Reviewer notes:** 

---

## zeichen-118

**Deutsch:** Was bedeutet dieses gelbe Ortsschild mit dem Namen der Ortschaft?

**فارسی:** این تابلوی زرد ورودی شهر (Ortsschild) با نام محل به چه معناست؟

| | Deutsch | فارسی |
|---|---|---|
| **a** ✅ | Ab hier beginnt eine geschlossene Ortschaft; innerorts gilt grundsätzlich Tempo 50. | از این‌جا یک منطقه مسکونی بسته (geschlossene Ortschaft) آغاز می‌شود؛ در داخل شهر اصولاً سرعت 50 کیلومتر بر ساعت اعمال می‌شود. |
| **b** | Ab hier endet die geschlossene Ortschaft. | از این‌جا منطقه مسکونی بسته پایان می‌یابد. |
| **c** | Es zeigt zugleich das Ende einer Kraftfahrstraße an. | هم‌زمان پایان یک Kraftfahrstraße را نیز نشان می‌دهد. |
| **d** | Ab hier gilt eine Geschwindigkeitsbegrenzung von 30 km/h. | از این‌جا محدودیت سرعت 30 کیلومتر بر ساعت اعمال می‌شود. |

**Erklärung (DE):** Zeichen 310 (Ortstafel, Vorderseite) markiert den Beginn einer geschlossenen Ortschaft; ohne andere Beschilderung gilt ab hier Tempo 50.

**Erklärung (فارسی):** Zeichen 310 (تابلوی ورودی شهر، روی جلو) آغاز یک منطقه مسکونی بسته را مشخص می‌کند؛ بدون علامت دیگری، از این‌جا سرعت 50 کیلومتر بر ساعت اعمال می‌شود.

**Reviewer notes:** 

---

## zeichen-132

**Deutsch:** Unter einem Verkehrszeichen befindet sich ein weißes Zusatzzeichen mit der Aufschrift „Fußgänger“. Was bedeutet das?

**فارسی:** زیر یک تابلوی راهنمایی، یک تابلوی الحاقی سفید با نوشته «Fußgänger» (عابر پیاده) قرار دارد. این به چه معناست؟

| | Deutsch | فارسی |
|---|---|---|
| **a** ✅ | Das Zusatzzeichen weist darauf hin, dass sich das Hauptzeichen (auch) auf Fußgänger bezieht. | تابلوی الحاقی نشان می‌دهد که تابلوی اصلی (نیز) به عابران پیاده مربوط می‌شود. |
| **b** | Fußgänger sind von jeder Regelung durch das Hauptzeichen grundsätzlich ausgenommen. | عابران پیاده اصولاً از هر مقرراتی که تابلوی اصلی وضع می‌کند مستثنی هستند. |
| **c** | Es handelt sich um einen Hinweis auf eine Fußgängerzone. | این اشاره‌ای به یک منطقه پیاده است. |
| **d** | Das Zusatzzeichen gilt nur für Rollstuhlfahrer, nicht für andere Fußgänger. | تابلوی الحاقی فقط برای افراد ویلچرنشین اعمال می‌شود، نه سایر عابران پیاده. |

**Erklärung (DE):** Das Zusatzzeichen 1010-53 „Fußgänger“ präzisiert den Geltungsbereich des darüber angebrachten Hauptzeichens: es macht deutlich, dass die Regelung auch Fußgänger einschließt, statt sich (wie ohne Zusatzzeichen oft angenommen) nur auf Fahrzeuge zu beziehen.

**Erklärung (فارسی):** تابلوی الحاقی 1010-53 «Fußgänger» محدوده اعمال تابلوی اصلی نصب‌شده بالای آن را روشن می‌کند: مشخص می‌کند که این مقررات شامل عابران پیاده نیز می‌شود، به جای آن‌که (چنان‌که بدون تابلوی الحاقی اغلب فرض می‌شود) فقط به خودروها مربوط باشد.

**Reviewer notes:** 

---

## gefahr-06

**Deutsch:** Was bedeutet die Faustregel 'halber Tacho' für den Sicherheitsabstand auf der Autobahn?

**فارسی:** قاعده‌ی سرانگشتی «نصف سرعت‌سنج» برای فاصله‌ی ایمنی در Autobahn به چه معناست؟

| | Deutsch | فارسی |
|---|---|---|
| **a** ✅ | Der Abstand in Metern soll mindestens der halben Geschwindigkeit in km/h entsprechen | فاصله بر حسب متر باید حداقل برابر با نصف سرعت بر حسب کیلومتر بر ساعت باشد |
| **b** | Man soll nur halb so schnell fahren wie erlaubt | باید فقط با نصف سرعت مجاز رانندگی کرد |
| **c** | Der Abstand darf höchstens die halbe Fahrzeuglänge betragen | فاصله نباید بیشتر از نصف طول خودرو باشد |
| **d** | Man soll nach der Hälfte der Strecke eine Pause machen | باید بعد از نیمی از مسیر یک استراحت کرد |

**Erklärung (DE):** Bei 100 km/h wären das mindestens 50 Meter Abstand. Diese Faustregel ist einfach zu merken, ersetzt aber keine genauere Berechnung bei schlechten Bedingungen.

**Erklärung (فارسی):** در سرعت 100 کیلومتر بر ساعت، این مقدار حداقل 50 متر فاصله می‌شود. این قاعده‌ی سرانگشتی به‌سادگی قابل‌یادآوری است، اما جایگزین محاسبه‌ی دقیق‌تر در شرایط بد نمی‌شود.

**Reviewer notes:** 

---

## verhalten-09

**Deutsch:** Wer im Auto muss laut Gesetz während der Fahrt angeschnallt sein?

**فارسی:** طبق قانون، چه کسانی در خودرو باید هنگام رانندگی کمربند ببندند؟

| | Deutsch | فارسی |
|---|---|---|
| **a** | Nur der Fahrer | فقط راننده |
| **b** | Nur die Personen auf den Vordersitzen | فقط افراد روی صندلی‌های جلو |
| **c** ✅ | Alle Insassen auf allen Sitzplätzen mit Sicherheitsgurt | همه سرنشینان در همه صندلی‌های مجهز به کمربند ایمنی |
| **d** | Nur Kinder unter zwölf Jahren | فقط کودکان زیر دوازده سال |

**Erklärung (DE):** Die Anschnallpflicht gilt für alle Insassen auf allen Sitzplätzen, die mit einem Sicherheitsgurt ausgestattet sind, also auch für Personen auf der Rückbank.

**Erklärung (فارسی):** الزام بستن کمربند برای همه سرنشینان در همه صندلی‌هایی که مجهز به کمربند ایمنی هستند اعمال می‌شود، یعنی برای افراد روی صندلی عقب نیز.

**Reviewer notes:** 

---

## parken-01

**Deutsch:** Was unterscheidet 'Halten' von 'Parken'?

**فارسی:** «Halten» (توقف کوتاه) چه تفاوتی با «Parken» (پارک کردن) دارد؟

| | Deutsch | فارسی |
|---|---|---|
| **a** | Halten ist grundsätzlich verboten, Parken ist immer erlaubt | Halten اصولاً ممنوع است، Parken همیشه مجاز است |
| **b** | Parken darf man nur mit eingeschaltetem Warnblinker | Parken فقط با روشن بودن چراغ‌های خطر مجاز است |
| **c** ✅ | Parken liegt vor, wenn man länger als drei Minuten hält oder das Fahrzeug verlässt | اگر بیش از سه دقیقه توقف کنید یا خودرو را ترک کنید، Parken محسوب می‌شود |
| **d** | Halten ist nur nachts erlaubt | Halten فقط در شب مجاز است |

**Erklärung (DE):** Wer länger als drei Minuten hält oder das Fahrzeug verlässt, parkt im rechtlichen Sinn. Kürzeres Halten, zum Beispiel zum Ein- oder Aussteigen, zählt als Halten.

**Erklärung (فارسی):** کسی که بیش از سه دقیقه توقف کند یا خودرو را ترک کند، از نظر حقوقی در حال Parken است. توقف کوتاه‌تر، مثلاً برای سوار یا پیاده شدن، به‌عنوان Halten محسوب می‌شود.

**Reviewer notes:** 

---

## autobahn-07

**Deutsch:** Auf welcher Seite darf auf der Autobahn normalerweise überholt werden?

**فارسی:** در Autobahn معمولاً سبقت گرفتن از کدام سمت مجاز است؟

| | Deutsch | فارسی |
|---|---|---|
| **a** | Auf der Seite mit dem geringeren Verkehr | از سمتی که ترافیک کمتری دارد |
| **b** ✅ | Nur auf der linken Seite | فقط از سمت چپ |
| **c** | Auf beiden Seiten, je nach freier Spur | از هر دو سمت، بسته به خط خالی |
| **d** | Nur auf der rechten Seite | فقط از سمت راست |

**Erklärung (DE):** Überholt werden darf grundsätzlich nur links. Rechtsüberholen ist auf der Autobahn nur erlaubt, wenn der Verkehr auf allen Fahrstreifen sich staut und langsamer fließt.

**Erklärung (فارسی):** سبقت گرفتن اصولاً فقط از سمت چپ مجاز است. سبقت از سمت راست در Autobahn فقط زمانی مجاز است که ترافیک در همه خط‌ها متراکم و کندتر در حال حرکت باشد.

**Reviewer notes:** 

---

## umwelt-08

**Deutsch:** Woran erkennt man einen echten Winterreifen im Gegensatz zu einem reinen Sommerreifen?

**فارسی:** لاستیک زمستانی واقعی را در مقایسه با لاستیک صرفاً تابستانی از چه چیزی می‌توان تشخیص داد؟

| | Deutsch | فارسی |
|---|---|---|
| **a** ✅ | Am Alpine-Symbol (Bergpiktogramm mit Schneeflocke) auf der Reifenflanke | از نماد Alpine-Symbol (تصویر کوه با دانه برف) روی دیواره لاستیک |
| **b** | Am M+S-Kürzel allein, unabhängig vom Herstellungsdatum des Reifens | فقط از حروف اختصاری M+S، صرف‌نظر از تاریخ تولید لاستیک |
| **c** | An besonders breiten Reifen, breite Reifen sind automatisch Winterreifen | از لاستیک‌های بسیار پهن، لاستیک پهن به‌طور خودکار زمستانی است |
| **d** | Daran, dass der Reifen als 'Ganzjahresreifen' verkauft wird | از اینکه لاستیک به‌عنوان «لاستیک چهارفصل» فروخته می‌شود |

**Erklärung (DE):** Das Alpine-Symbol zeigt, dass ein Reifen die Anforderungen an Wintertauglichkeit erfüllt. Das ältere M+S-Kürzel allein reicht seit einer Übergangsfrist nicht mehr für alle neu hergestellten Reifen aus.

**Erklärung (فارسی):** نماد Alpine-Symbol نشان می‌دهد که لاستیک الزامات مناسب بودن برای زمستان را برآورده می‌کند. حروف اختصاری قدیمی‌تر M+S به‌تنهایی از پایان یک دوره انتقالی برای همه لاستیک‌های تازه‌تولید کافی نیست.

**Reviewer notes:** 

---

## erstehilfe-04

**Deutsch:** Was sollten Sie unmittelbar tun, sobald Sie nach einem Unfall Ihr Fahrzeug zum Stehen gebracht haben?

**فارسی:** بلافاصله پس از اینکه خودروی خود را پس از تصادف متوقف کردید، چه کاری باید انجام دهید؟

| | Deutsch | فارسی |
|---|---|---|
| **a** ✅ | Warnblinkanlage einschalten | روشن کردن چراغ چهارراهنما |
| **b** | Motor unnötig lange laufen lassen | روشن گذاشتن بی‌مورد و طولانی موتور |
| **c** | Die Musik lauter stellen | بلندتر کردن صدای موسیقی |
| **d** | Sofort losfahren, um Platz zu machen | بلافاصله حرکت کردن برای خالی کردن جا |

**Erklärung (DE):** Der Warnblinker macht andere Verkehrsteilnehmer sofort auf die Gefahrenstelle aufmerksam.

**Erklärung (فارسی):** چراغ چهارراهنما بلافاصله توجه سایر کاربران راه را به نقطه خطر جلب می‌کند.

**Reviewer notes:** 

---

## fahrtuechtigkeit-39

**Deutsch:** Warum ist es riskant, sich bei der Einschätzung der eigenen Fahrtüchtigkeit auf Erfahrungswerte wie 'ich vertrage viel' zu verlassen?

**فارسی:** چرا اتکا به تجربیاتی مانند «من تحمل زیادی دارم» برای ارزیابی توانایی رانندگی خود پرخطر است؟

| | Deutsch | فارسی |
|---|---|---|
| **a** ✅ | Eine hohe subjektive Alkoholtoleranz sagt nichts über die tatsächliche Beeinträchtigung von Reaktionsfähigkeit und Wahrnehmung aus | تحمل ذهنی بالای الکل هیچ اطلاعاتی درباره اختلال واقعی توانایی واکنش و ادراک نمی‌دهد |
| **b** | Wer viel verträgt, hat rechtlich automatisch höhere Promillegrenzen | کسی که تحمل زیادی دارد، از نظر حقوقی به‌طور خودکار حدود مجاز بالاتری دارد |
| **c** | Erfahrungswerte sind die einzige zuverlässige Methode zur Einschätzung | تجربیات شخصی تنها روش قابل اعتماد برای ارزیابی است |
| **d** | Alkoholtoleranz verhindert jede Art von Fahruntüchtigkeit vollständig | تحمل الکل به‌طور کامل از هرگونه ناتوانی در رانندگی جلوگیری می‌کند |

**Erklärung (DE):** Auch bei subjektiv hoher Alkoholtoleranz bleiben Reaktionsfähigkeit, Wahrnehmung und Urteilsvermögen objektiv beeinträchtigt - die gesetzlichen Grenzwerte gelten unabhängig davon.

**Erklärung (فارسی):** حتی در صورت تحمل ذهنی بالای الکل، توانایی واکنش، ادراک و قضاوت به‌طور عینی مختل باقی می‌مانند - حدود قانونی مستقل از این موضوع اعمال می‌شوند.

**Reviewer notes:** 

---

## gefahr-40

**Deutsch:** Sie fahren mit einem voll beladenen Fahrzeug eine lange, steile Gefällstrecke hinunter. Warum sollten Sie rechtzeitig in einen niedrigeren Gang schalten, statt nur die Bremse zu nutzen?

**فارسی:** شما با یک خودروی کاملاً بارگیری‌شده از یک سراشیبی طولانی و تند پایین می‌روید. چرا باید به‌موقع به دنده پایین‌تر تغییر دهید، به‌جای اینکه فقط از ترمز استفاده کنید؟

| | Deutsch | فارسی |
|---|---|---|
| **a** | Weil ein niedriger Gang den Kraftstoffverbrauch senkt und das der einzige Zweck ist | زیرا دنده پایین مصرف سوخت را کاهش می‌دهد و این تنها هدف است |
| **b** ✅ | Weil dauerhaftes Bremsen bei hoher Last die Bremsen überhitzen und ihre Wirkung nachlassen kann | زیرا ترمز مداوم تحت بار سنگین می‌تواند ترمزها را داغ کند و کارایی آنها را کاهش دهد |
| **c** | Weil die Bremsen bei Gefällstrecken laut Vorschrift nicht benutzt werden dürfen | زیرا استفاده از ترمز در سراشیبی‌ها طبق مقررات ممنوع است |
| **d** | Weil ein niedriger Gang das Fahrzeug automatisch leichter macht | زیرا دنده پایین به‌طور خودکار خودرو را سبک‌تر می‌کند |

**Erklärung (DE):** Bei langem, hoch belastetem Bremsen kann sich das Bremssystem so stark erhitzen, dass die Bremswirkung nachlässt ('Bremsfading'). Ein niedriger Gang nutzt die Motorbremswirkung und entlastet die Betriebsbremse.

**Erklärung (فارسی):** در صورت ترمز طولانی‌مدت و پرفشار، سیستم ترمز می‌تواند به‌قدری داغ شود که کارایی ترمز کاهش یابد («Bremsfading»). دنده پایین از اثر ترمز موتور استفاده می‌کند و ترمز اصلی را کم‌بار می‌کند.

**Reviewer notes:** 

---
