# Zettacard translation brief — READ THIS FIRST

You are translating questions from the official German driving-licence theory exam
(or German workplace-compliance modules) into a target language.

## Where the work happens
Use the **`Bash` tool** (cloud container). Do NOT use `mcp__remote-devices__device_bash` —
it is wedged and every call fails. Scratch scripts go in `~/bar/scratch/` (`~` is `/root`),
never the sandboxed scratchpad (a parallel job had one silently overwritten there).

## Input / output shape
Input: a JSON ARRAY of items
  `{"id","topic","correct":["b"],"question","options":{"a".."d"},"explanation"}`
Output: a JSON OBJECT keyed by id
  `{"<id>": {"question","options":{"a".."d"},"explanation"}}`
Same ids, same option keys, nothing empty, and NO `correct`/`topic` in the output.
Write with `json.dump(..., ensure_ascii=False, indent=1)`. Write incrementally after each
batch of ~15 so partial work survives if you are cut off.

## Register
The reader is an adult learner in Germany, often a recent arrival, preparing for the
official exam. Use the standard written form of the target language, formal-neutral,
plain and clear. This text also feeds text-to-speech, so favour sentences that read
aloud cleanly. Avoid literary flourish and avoid slang.

## KEEP THESE IN GERMAN, UNTRANSLATED
The learner meets these exact words on real German road signs and in the official exam.
Keep them verbatim (in Latin script even inside right-to-left or non-Latin text):
`Zeichen NNN`, `Ortstafel`, `Vorfahrt`, `Vorfahrtstraße`, `Autobahn`, `Kraftfahrstraße`,
`Warnblinkanlage`, `Andreaskreuz`, `Bahnübergang`, `Rettungsgasse`,
`Reißverschlussverfahren`, `Alpine-Symbol`, `M+S`, `Mofa frei`, `Anlieger frei`,
`Umweltzone`, `StVO`, `Bußgeld`, `Fahrerlaubnis`, `Bremsfading`, `Aquaplaning`,
`Ladungssicherung`, `Zurrgurt`, `Stützlast`, `Probezeit`, `Flensburg`, `MPU`.
For compliance modules also keep: `DSGVO`, `BDSG`, `KI-VO`/`AI Act`, `NIS2`, `HinSchG`,
all `Art. NN` / `§ NN` references, `Anbieter`, `Betreiber`, `Verantwortlicher`,
`Auftragsverarbeiter`.
Gloss a non-obvious term ONCE per question in parentheses, e.g. `Vorfahrt (right of way)`.
`Promille` may be rendered in the target language where that reads better aloud — the
numeric value must stay exact.

## NUMBERS ARE SAFETY-CRITICAL
Every numeral, sign number, speed, distance, weight, tread depth, deadline,
blood-alcohol limit and § / Art. reference must match the German EXACTLY, keeping the
German decimal comma (0,5 not 0.5) and thousands dot (1.500). Never convert units.
Use Western digits unless your specific job prompt says otherwise.

## CORRECTNESS — the rules that matter most
1. The option letter listed in `correct` must STILL be the right answer after translation.
   Never reorder or swap options. Never change `correct`.
2. Translate the MEANING faithfully. Do not improve, shorten, or add explanation.
3. Polarity must survive exactly: must / must not, allowed / prohibited, has right of way /
   must yield, may / shall. A single flipped negation is a safety defect.
4. Distractors (the wrong options) must stay clearly WRONG, and must not become true or
   become a paraphrase of the correct option.

## THE DISTRACTOR CONVENTION — read twice
This project DELIBERATELY uses non-literal distractors. A wrong option worded completely
differently from the German distractor is CORRECT BEHAVIOUR, not an error. You may render
a distractor freely if that reads better in the target language, as long as it stays
clearly wrong. Do not force literal equivalence on distractors.

## DO NOT REPAIR THE SOURCE
If a German source string looks truncated, garbled or wrong, translate it faithfully as-is
and REPORT it. Completing or fixing source content is out of scope for a translator.

## VALIDATE BEFORE REPORTING — print the result
- output has exactly the input's ids, no missing or extra
- option keys match the input per question
- no empty question / option / explanation
- target-language script present in every entry
- every numeral in the German appears in the translation
If a short option is legitimately near-identical to the German (a bare number like
"750 kg", or a kept German term), LEAVE IT and report it — never reword something just to
look different.

## HARD RULES
- NEVER run any git command, not even read-only.
- Write only to the single output file your job names. Touch nothing else.
- Translate every item. No sampling, no placeholders, no "TODO".
- Be honest in your report: flag ids where you were unsure, and say plainly if you are not
  a native speaker of the target language.

## REPORT
Keep it SHORT: count translated, validation output, German terms kept and how glossed,
near-identical strings deliberately left alone, and ids flagged for a native reviewer.
